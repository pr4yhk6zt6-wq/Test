# 06 — Installation Guide (iPhone A only)

Nothing in this guide touches iPhone B.

## A. Prerequisites check (rule 24 fields)

1. Install & run diagnostics FIRST (one of):
   - **Shell (no toolchain)**: copy `tools/aidiag-standalone.sh` to A (AirDrop/Filza/SSH), run as root:
     `sh aidiag-standalone.sh` → prints + saves `aidiag-report.txt`.
   - **Deb (preferred, includes IOKit BT walk)**: install `artifacts/com.research.idiag_0.2.0_iphoneos-arm64.deb` via Filza/Sileo, then (as root):
     `/var/jb/usr/bin/idiag` (rootless) or `/usr/bin/idiag` (rootful).
   Send the output back so the UNKNOWNs in docs/01 close.

## B. ControllerA.app via TrollStore (Phase-1 artifact)

1. Transfer `artifacts/ControllerA.ipa` to A.
2. Open **TrollStore** → `+` → pick the IPA → install.
3. Launch **ControllerA** from home screen. Expected: landscape controller UI, status line shows `UDP idle · pkts 0`.

TrollStore support on iOS 15.8.x: yes (supported range 14.0–16.6.1) [E1]. The IPA is ldid-fake-signed, which is the normal TrollStore distribution form.

## C. Tools/daemon debs via the jailbreak bootstrap (Phase-2/3 artifacts)

- Rootless (palera1n rootless / Dopamine): install the `.deb` with Filza ("Install") or Sileo → lands under `/var/jb/usr/bin/`.
- Rootful: same via Filza/Sileo → `/usr/bin/`.
- Run daemon shell (self-test only, null transport):
  `/var/jb/usr/bin/ds4bridged` — expected log: `self-test done: state=3 reports≈250 bytes≈15000`.
  This proves the on-device build; it is **not** yet a controller path (docs/05 §Phase-3).

## D. Lab latency instrument (optional, EXTERNAL env — not part of shipped system)

On any PC on the same Wi-Fi: `make -C src/ds4bridge tools/udp_echo && ./tools/udp_echo 37564`.
In ControllerA: UDP → set PC IP : 37564 → status bar shows live RTT (requirement 27 mechanics).

## Upgrading / crash-log collection (after bug report round 1)

1. TrollStore → install the new `ControllerA.ipa` (0.3.1, build 4) over the old one.
   What changed: crash fix (characteristics now served without cached values), watchdog 15 s (state resolution on this device takes ~5-6 s — that is normal), UI: buttons are round + labeled + diamond layout now.
2. Tap **BLE** → the v2 probe prints: `CBManager.authorization (pre-init)`, both managers' states (PM + CM cross-check), and a 6 s verdict if still stuck. Screenshot the whole log.
3. Pull the real crash log of the v1 crash (as root):
   `/var/jb/usr/bin/idiag -c`   → lists ControllerA/SpringBoard .ips, prints newest backtrace, saves copy to /var/mobile/Library/idiag-latest-crash.txt
   (shell-only alternative: `sh tools/aidiag-standalone.sh crash`)
4. Permission-storage audit (as root): `/var/jb/usr/bin/idiag -p`
5. Also check: Settings → Privacy & Security → Bluetooth — does ControllerA appear? Toggle Bluetooth off/on, then tap BLE again.

## Uninstall

TrollStore → ControllerA → uninstall; remove debs via Sileo. No system files are modified by any artifact.
