# 01 — Device Information Audit (rule 0 / 0.1)

Status labels: **KNOWN** (confirmed), **UNKNOWN** (must come from the device via `idiag` / `aidiag-standalone.sh`), **INFERRED** (logical constraint from known facts, labeled — not a device reading).

## iPhone A — Controller device

| Item | Status | Value / Note |
|---|---|---|
| Role | KNOWN | Controller device (only modifiable device) |
| iOS version | KNOWN | 15.8.8 |
| Jailbroken | KNOWN | YES (user-confirmed) |
| Install mechanism | KNOWN | TrollStore already installed (user-confirmed) |
| System modification | KNOWN | Allowed |
| Model / Model Identifier | UNKNOWN | `hw.machine`, `hw.model` → run `idiag` (deb) or `tools/aidiag-standalone.sh` |
| Build number | UNKNOWN | `kern.osversion` → `idiag` |
| CPU architecture | INFERRED + UNKNOWN | **arm64 (A8–A11) highly likely**: TrollStore install on 15.8.x arm64e (A12+) exists via TrollInstallerX [E1, E2], but the public jailbreaks that cover iOS 15.8.x are checkm8-based palera1n (A8–A11) or Dopamine [E2, E11]. Confirm via `hw.cpusubtype` (1=arm64, 2=arm64e) |
| Jailbreak implementation/version | UNKNOWN | Candidates: palera1n (rootless/rootful, semi-tethered, checkm8), Dopamine (semi-untethered). Detect via markers in `idiag` [E2, E11] |
| Rootless / Rootful | UNKNOWN | `/var/jb` present ⇒ rootless. Determines .deb install paths |
| Package manager | UNKNOWN | Sileo/Zebra + dpkg (Procursus) expected on either jailbreak; verify in `idiag` |
| Bluetooth chip | UNKNOWN | `idiag` v0.3: IOKit walk + **BlueTool-embedded firmware token scan** (iOS ≥13.6 keeps .hcd inside BlueTool [E14]) + `/dev/uart.bluetooth`/`/dev/btreset` presence. Determines InternalBlue-class patch feasibility [E7, E14–E16] |
| Kernel/SEP info | UNKNOWN | `idiag` dumps `kern.*`; SEP not expected to be relevant (A11 caveat: passcode must be disabled while jailbroken on palera1n [E2]) |
| Available entitlements | PARTIALLY KNOWN | TrollStore grants arbitrary entitlements + permasigned install [E1]; exact set used: none beyond public APIs in Phase 1 |
| IOKit/HID access | UNKNOWN | Requires root (jailbreak) — verify with `idiag` IOKit section |
| Tweak injection capability | UNKNOWN | ElleKit/Substrate presence check in `idiag` [E2] |
| Daemon execution capability | INFERRED (conditional) | If rootful or rootless-with-launchd (both palera1n modes support daemons via bootstrap) → YES; verify by installing `com.research.ds4bridged` and launching |
| BT Classic HID *device role* | UNKNOWN | THE critical open capability. No public/private API known; requires chip-level work (research track) |

## iPhone B — Game device

| Item | Status | Value / Note |
|---|---|---|
| Role | KNOWN | Game device, stock, unmodified — hard boundary |
| iOS version | KNOWN | 27 (released 2026-09-14 [E12]) |
| Model / build | UNKNOWN | Not needed for architecture (no software ships for B); record during testing (rule 24) |
| Controller compatibility | EXTERNAL EVIDENCE ONLY | Current Apple documentation still lists DualShock 4 / DualSense / Edge / Access as supported [E3]; Xbox + Nintendo Switch controllers supported since iOS 13–16 [E4, E10]. **B itself NOT TESTED** |
| BLE HID gamepad acceptance | EXTERNAL EVIDENCE (negative) | Generic BLE HID gamepads pair but do not surface in GameController.framework on iOS/macOS per developer reports [E5] |

## Required vs Optional for feasibility

- **Required before Phase-3 commitment**: A's `hw.machine` (→ BT chip), jailbreak type + rootless/rootful, IOKit/BT access as root.
- **Optional for Phase-1/2**: exact build number, SEP details, tweak injection (not used by Phase 1/2).
