# STATUS (rule 32)

## FORMAL STATUS: `PARTIAL`

### Why not SUCCESS
Rule 31 requires end-to-end proof on the real devices (A as controller recognized by B, game receives input, all inputs work). **No hardware test has been run** — the build environment has no iPhones. Everything on-device is labeled NOT RUN / NOT VERIFIED.

### Why not PROVEN BLOCKED
At least one technical path remains open under the constraints:
- Phase-3 (BT Classic HID device role on A, DS4 identity) — UNKNOWN capability, concrete falsifiable experiment ladder defined; supporting evidence: DS4 still supported by current iOS [E3], HID device role implementable on capable BT controllers [E8], Broadcom firmware patching precedents [E7].
- Residual BLE identity track (Joy-Con-shaped) — open pending captures [E4/E5].
PROVEN BLOCKED would require evidence that A's BT chip/stack forecloses all of these — that evidence does not exist yet.

### Requirement scoreboard (rule 31 A–M)

| Req | Description | State |
|---|---|---|
| A | Only A modified | MET by design (no artifact targets B) |
| B | A = iOS 15.8.8 | user-confirmed, device NOT VERIFIED |
| C | A installs app via TrollStore per architecture | artifact ready (BUILD VERIFIED), install NOT RUN |
| D | B = iOS 27 stock | user-confirmed, device NOT VERIFIED |
| E | No companion app on B | MET by design |
| F | No game modification | MET by design (universal controller identity, no per-game code) |
| G | No hardware bridge | MET by design |
| H | No PC/Mac/Pi in shipped system | MET (PC used only as labeled lab instrument for latency tooling) |
| I | A connects to B as controller | NOT ACHIEVED (Phase-3 gate) |
| J | iOS on B recognizes controller | NOT ACHIEVED |
| K | Native game receives input | NOT ACHIEVED |
| L | Required inputs complete | MET at protocol/UI level (unit-tested), on-device NOT RUN |
| M | Results match stated environment | enforced by labeling (EXTERNAL/LOCAL/ON-DEVICE) |

### Session-2 advances (Phase-3 frontier pushed without hardware)
- Research: **internalblued/BlueTool/uart.bluetooth/Frankenstein/joycontrol** evidence added (E14–E17) — HCI access on jailbroken UART-Broadcom iPhones is published prior art; Phase-3 ladder revised (docs/12).
- Built + tested: **SDP responder** (ServiceSearchAttribute + continuation, byte-level tests), **HOGP/Joy-Con GATT DB builder**, **ds4lab** BlueZ lab backend (compiles; runtime needs BT dongle — NOT TESTED).
- idiag v0.3: BlueTool/dev-node/internalblued audit + BlueTool firmware-token chip scan.
- Unit tests: 54/54 PASS.

### Session-3 (first REAL-DEVICE round — bug report triage)
- **ON-DEVICE evidence E18** (iPhone A, iOS 15.8.8): TrollStore install of ControllerA **works**; UI + UDP transport healthy; BLE probe v1: state stuck Unknown, no prompt, crash → fixed bugs shipped (uds format string), probe v2 instrumentation + in-app crash journal + idiag v0.4 (`-c` .ips collector, `-p` BT-permission audit).
- Acceptance scoreboard updates: **B (A iOS 15.8.8) VERIFIED**, **C (TrollStore install) VERIFIED**; I/J/K unchanged (NOT ACHIEVED).
- Formal status unchanged: PARTIAL (I/J/K still open; Phase-3 gate).

### Session-4 (crash root-caused on device — hypothesis correction)
- E19: probe v2 log disproves H1/H2/H3 (daemon/TCC fine, auth=allowed, PM reaches poweredOn after ~5-6 s). The v1/v2 crash was OUR bug: cached value + write permission on characteristic 2A4E → NSInternalInconsistencyException at addService.
- Fixed in 0.3.1: all characteristics value:nil + dynamic read serving; watchdog 15 s; UI geometry fixes (buttons were square/unlabeled because radius+font were computed on the zero init frame — now in layoutSubviews; ABXY now a proper diamond; brighter controls).
- Next device round is DECISIVE for the BLE public-API question: 0.3.1 will actually attempt the 0x1812 publish (E6 verdict on-device).
- Formal status unchanged: PARTIAL.

### Session-5 (decisive BLE verdict on device — track closed correctly)
- **E20**: 0x1812 publish refused (CBError 8) ON DEVICE under full entitlements → **BLE public-API HID track = PROVEN BLOCKED** (rule 12 satisfied). The earlier v0.3.1 log line "ACCEPTED" was our messaging bug (wrong branch text) — fixed in v0.3.2.
- Probe-2 custom service + advertising works → awaiting user report whether iPhone B sees "ControllerA" (pure visibility evidence, T3d).
- Architecture consequence: Phase-3 proceeds on the **chip-level HCI track only** (docs/12 G1–G5) — which this block never affected (it lives inside CoreBluetooth).
- Scoreboard: B, C VERIFIED; I/J/K NOT ACHIEVED; formal status **PARTIAL**.

### Session-6 (G3 host stack: HCI/L2CAP device-role engine — sandbox-verified)
- Wrote + PASSED the HCI-over-X host stack for the chip-level track: hci_transport.h (hci_io_t iface + TCP backend), hci_reader.c (stream framer 0x01/0x02/0x04), hci_link.c (reset → Read Local Version → L2CAP ConnReq/Rsp → ConfReq/Rsp both directions → HID interrupt channel; local CIDs from 0x40; PB=10 ACL TX; Broadcom/Cypress/CSR version mapping).
- New mock-controller test (tests/test_hci.c): scripted fake BT controller drives the engine end-to-end — PSM 17/19 channel-up, hiddev → CONNECTED, byte-exact ACL TX of the 0x11 report (A1 11 80 00 00 A1...), plus TCP loopback with byte-split frames. **70/70 PASS** (54 prior + 16 new), 0 flakes in 10 runs. Bugs found & fixed by the tests themselves before any device contact: EVT code lives in the HCI header (not payload), Command Complete return-param offsets, ACL dlen must be 4+l2len, L2CAP item parsing off-by-2s.
- This follows the user's standing rule: maximum sandbox validation before any device artifact. ControllerA.ipa v0.3.2 stays FINAL; nothing new to install this round.
- G3 on-device still NOT RUN — needs the iOS-side HCI transport (BlueTool/internalblued TCP bridge per G2, or /dev/uart.bluetooth io). Kill criteria unchanged (docs/12).
- Formal status: PARTIAL (B, C VERIFIED; I/J/K NOT ACHIEVED).

### Build verification summary (LOCAL evidence, E13)
- ds4bridge unit tests: **70/70 PASS** (host Linux x86_64; 41 base + HCI/L2CAP suite)
- ControllerA.ipa: arm64 Mach-O, minos 15.0, ldid-signed — BUILD VERIFIED / RUNTIME UNVERIFIED
- idiag deb, ds4bridged deb (rootless): BUILD VERIFIED
- UDP echo mechanics on loopback: 200/200, 0 loss — mechanics only, not a latency claim

### Next actions (in order)
1. Run `aidiag`/`idiag` on A → close UNKNOWNs (chip, jb type, rootless/rootful).
2. T1–T3 (app install, input/latency, BLE probe evidence).
3. T4/T5 control experiments (real DS4 → B; ESP32 DS4 emulator → B).
4. Phase-3 ladder on A per docs/05 §G3.2, recording every attempt in docs/09.

### Session-6b (user asked to "fix" CBError 8 — E21 reopen attempt built)
- Honest position: the block cannot be fixed at the app/API level (E20). BUT E20 only ever
  tested the SHORT UUID spelling; external evidence (Bluetouch on App Store, HemiPad 2026,
  gist 2024) says modern iOS accepts the LONG spelling 00001812-0000-1000-8000-00805F9B34FB;
  iOS 7/8 blocked both -> on 15.8.8 UNKNOWN (docs/13).
- Built: ProbeBLE.ipa v0.1.0 (SEPARATE app; ControllerA v0.3.2 untouched/FINAL) — T1-T6
  one-install matrix. BUILD VERIFIED sandbox, NOT RUN. Zero-install store-app pre-test
  checklist also shipped (tools/ble-longform-zeroinstall-test.sh).
- Theos env had to be re-bootstrapped this session (.cache is not snapshotted): L1ghtmann
  llvm clang 11.1.0 + iPhoneOS14.5.sdk + ldid 2.1.5 — same versions as before.
- Formal status: PARTIAL. Awaiting device round: idiag (G1), BlueTool (G2), T3d, E21 probe
  (ProbeBLE install optional — zero-install path available).

### Session-6c (E21 executed on device — block is SHORT-FORM-ONLY, BLE track reopening)
- User ran ProbeBLE on A: T1/T4 short-form → CBError 8 (E20 reproduced); T2/T3 LONG-form →
  OK published (full HOGP live), repeated. **H-E21a CONFIRMED on iOS 15.8.8.**
- A live central (id 38BA17A2-…, MTU 524) SUBSCRIBED to the input report repeatedly —
  an HID-host GATT flow already ran against A; identity UNKNOWN (log has no peer name).
- No reinstall needed: decisive next test runs on the SAME ProbeBLE install (T3→T5,
  pair from B's stock Bluetooth, watch for the probe's auto-wiggling input on B, T6 copy).
- If B shows ProbeBLE and it behaves as a gamepad → merge into ControllerA v0.4.0
  (long-form HOGP + existing gamepad UI) → BLE route primary again. HCI/G-track = fallback.
- Formal status: PARTIAL → trend positive; still awaiting B-side verdict + G1/G2/T3d.

### Session-6d (E21b: Android sees ProbeBLE, iPhone 11 doesn't)
- Peripheral side CONFIRMED working (Android finds the advertised long-form 0x1812 device).
- Apple central invisibility suspected (matches X4). Same-iCloud hypothesis H-E21e = unlikely,
  disprovable with one different-account iPhone scan (T-E21b). SUBSCRIBED events reattributed
  to the Android scanner app (MTU 524).
- Next asks (batched, zero install): Android AD contents + pair behavior (T-E21a);
  one different-account iPhone scan (T-E21b). If Apple filter holds on iOS 27 -> G-track
  becomes the only path to B; BLE route remains valid for Android/PC hosts.
- Formal status: PARTIAL.

### Session-6e (E21c: "phone" classification -> BLE public-API verdict finalized)
- Android: name changes, type stays phone -> identity fields unreachable from CB.
  BLE public-API track = PROVEN INSUFFICIENT for controller identity (FINAL, docs/13).
- Architecture now single-path to iPhone B: chip-level HCI (docs/12 G1-G5); host side
  done + tested (70/70). Gate evidence still outstanding from device: G1 idiag chip
  audit, G2 BlueTool `hci cmd 0x2018` smoke, plus earlier T3d (now moot for BLE;
  still useful as B-side record).
- Formal status: PARTIAL (B/C verified; I/J/K pending G-track feasibility).

### Session-6f (G1 kick-off: no /var/jb found -> pivot to idiagTS)
- User (Filza): /var/jb absent on A -> "A jailbroken" premise UNVERIFIED (H-jb1/2/3 in docs/09).
- Built idiagTS.ipa v0.1.0 (TrollStore audit app; sysctls, jb/TrollStore markers, /dev probes
  incl. real open() attempt on /dev/uart.bluetooth, BlueTool/bluetoothd presence, limited IOKit).
  BUILD VERIFIED sandbox; NOT RUN. Explicit-height log view (ProbeBLE lesson applied).
- Theos now reproducibly bootstrappable: tools/bootstrap-theos.sh (clang 11.1.0 + SDK 14.5 +
  ldid 2.1.5 + vendor submodules; run at session start because .cache is not snapshotted).
- Awaiting: idiagTS report + model name + which jb app (if any). G2/G3 pending G1 result.
- Formal status: PARTIAL.

### Session-6g (idiagTS v0.1.0 black screen -> root-caused -> v0.1.1)
- Root cause: UIApplicationMain arg-4 must be the app-delegate class; v0.1.0 passed the
  view controller -> no window -> black screen. Fixed in v0.1.1 build 2 (clean rebuild,
  binary + entitlements + version verified inside the ipa). Same install method (TrollStore).
- Bootstrap script hardened (sandbox env presets THEOS=/home/user/theos; script now forces
  .cache/theos and pulls vendor submodules; stale-binary packaging caught and prevented).
- Awaiting: idiagTS v0.1.1 RUN AUDIT report + device model + jb-app presence.
- Formal status: PARTIAL.

### Session-6h (G1 EXECUTED + CLOSED — biggest premise correction of the project)
- idiagTS v0.1.1 report: iPhone A = **iPhone 7 (A10, checkm8), iOS 15.8.8 (19H422)**.
- NO jailbreak has EVER been on this device (all markers absent; user confirms no jb app).
  All previous device evidence = TrollStore apps only. Scoreboard premise corrected.
- /dev/uart.bluetooth EXISTS (mode 666) but open() = EBUSY (held by bluetoothd) —
  with root+jb: kill btd -> open -> hci_io_uart = the G3 transport. BlueTool 9.7MB present.
- G1 VERDICT: SUCCESS. Next gate G1.5: palera1n (rootless) on this checkm8 device.
- Formal status: PARTIAL; identity UNKNOWNs now CLOSED.

### Session-6i (JAILBREAK LIVE — G1 closed, G1.6 runbook issued)
- User jailbroke the device. Report: /var/jb=YES + /var/jb/basebin=YES (palera1n marker).
  User said "Dopamine" but Dopamine cannot run on 15.8.8 and does not create basebin —
  the tool is palera1n-family; semi-tethered semantics noted (PC needed after power-off).
- Built: btiotest 0.1.0 (rootless CLI: open /dev/uart.bluetooth, optional HCI Reset write,
  hexdump reply, detects Command Complete) + hci_io_uart.c backend (socketpair-tested).
  ds4bridge tests now 75/75 PASS. artifacts/com.research.btiotest_0.1.0 deb = BUILD VERIFIED.
- Issued G1.6 runbook (tools/idiag-g1/G16-runbook-postjb.md): full idiag as root (chip ID),
  EBUSY-clearing ladder (BT off / killall bluetoothd / launchctl stop), BlueTool 0x2018 smoke.
- Awaiting: outputs. If open()+Reset->CommandComplete => G3 direct transport proven on device.
- Formal status: PARTIAL, trend positive.

### Session-6j (detailed .deb install guide)
- User asked for detailed install steps (saw 3 debs, only 2 needed). Added
  tools/idiag-g1/G16-deb-install-steps.md: file inventory (idiag+btiotest now,
  ds4bridged explicitly NOT yet), Files-app zip extraction, placement under
  /var/mobile/Documents, Filza tap-Install path, dpkg alternative, verification
  via /var/jb/usr/bin listing, --force-reinstall note.
- Awaiting: idiag root output + btiotest ladder results.

### Session-6k (G1.6 first run — chip IDENTIFIED, benign misses, exact commands issued)
- debs installed OK. idiag full (root): chip = Broadcom BCM4350/BCM4345C1-class UART
  (BlueTool firmware tokens Pinotnoir/Albarossa/Olympic-Hans) = the InternalBlue UART
  class per E14 -> G1 chip question CLOSED; hci_link Broadcom mapping already ready.
- jb tool = DOPAMINE (newer gen, creates basebin; corrects previous note; semi-untethered,
  no PC after reboot — better than warned). IOKit still inaccessible even as root
  (deprioritized — chip known).
- EBUSY persists because nothing was actually stopped: killall found no "bluetoothd"
  process, and BlueTool runs as service (com.apple.BlueTool PID 7462) — likely the holder.
  My runbook's <placeholder> syntax caused a literal-typing parse error (my bug).
- Issued exact-label second-round commands (runbook updated): airplane mode ->
  ps axww|grep blue -> launchctl stop com.apple.bluetoothd + com.apple.BlueTool ->
  btiotest -w -> bootout escalation. Restore = Userspace Reboot.
- Formal status: PARTIAL (identity closed; transport experiment in progress).

### Session-6l (BREAKTHROUGH: /dev/uart.bluetooth OPENED on device)
- After stop+bootout of com.apple.bluetoothd and com.apple.BlueTool: btiotest -w ->
  open() OK fd=3, HCI Reset written. Screenshot ends at that line; chip response pending.
- G3 transport feasibility = YES on iPhone A (direct userland HCI). Chip response needs
  baud/flow match (BCM4350-class, likely 3M + HW flow left by BlueTool init).
- Built next: btiotest 0.2.0 — raw termios + baud x HW-flow sweep (115200/921600/1M/2M/3M/4M
  x flow off/on), Reset at each, stops at first Command Complete.
- Restore procedure: Userspace Reboot (Dopamine) returns all daemons.
- Formal status: PARTIAL -> major gate passed.

### Session-6m (round 3: wrong deb + sudo PATH lesson; port still opens)
- User installed ds4bridged_0.2.0 (held-back file) instead of btiotest_0.2.0 — same
  _0.2.0 suffix caused the pick. Verified ds4bridged 0.2.0 = inert stub binary
  (no plist, no UART) -> harmless. On-device btiotest still 0.1.0 -> no sweep ran.
- sudo PATH: jb launchctl = /var/jb/bin/launchctl (sudo strips /var/jb/bin).
- Round-2 bootouts persisted ("No such process" on re-bootout) and btiotest opened OK
  again — port availability is stable across sessions within same userspace boot.
- Runbook round 3b issued: install real btiotest 0.2.0 (exact filename), run sweep,
  capture through "close OK" (screenshots keep cutting right after "wrote HCI Reset").

### Session-6n (BTKit.ipa — all-button tool for the user, zero typing)
- User asked for a press-only program (not comfortable typing commands). Built BTKit:
  UIKit app + bundled setuid-root helper (bthelper: stop / sweep / restore via launchctl
  + the v0.2.0 baud x flow sweep + open test). App streams helper stdout into an on-screen
  log, saves /var/mobile/Documents/btkit-log.txt, one-tap COPY.
- Packaging verified: helper inside ipa carries mode 0o104755 (setuid preserved through
  zip via explicit external_attr). BUILD VERIFIED; device NOT RUN.
- Awaiting: BTKit run results (STOP shows euid=0 or NO_ROOT; SWEEP prints CONFIG line).
- Formal status: PARTIAL.

### Session-6o (BTKit v0.1.0 launch crash -> v0.1.1 fix + crash capture)
- Root cause: missing _btns init -> nil-anchor constraint in first layout pass ->
  instant NSException (code-verified; matches "bounce out at launch").
- v0.1.1 build 2: fixed + per-button explicit layout + automatic crash reporter
  (btkit-crash.txt surfaced in-app). Setuid helper still 4755 in ipa (verified).
- Awaiting BTKit device run: STOP (euid=0 check) -> SWEEP (CONFIG line) -> COPY LOG.
- Formal status: PARTIAL.

### Session-6p (BTKit 32512 -> v0.1.2 shell-free direct exec)
- All buttons exited 32512 (shell 127) with stderr lost by popen. Rewrote spawn chain:
  fork+execve+merged-pipe, EXEC_FAIL errno surfaced in-app, timeout kill; helper also
  de-shelled. Host-verified pattern. Setuid 4755 preserved in ipa (verified).
- Next device run decides: works -> SWEEP -> CONFIG line; EXEC_FAIL 1/13 -> use typed
  commands (fallback proven). Awaiting results.
- Formal status: PARTIAL.

### Session-6q (BTKit v0.1.2: plumbing perfect, setuid stripped -> v0.1.3 via sudo)
- v0.1.2 device run: helper executed, clean diagnostics: "bthelper v0.2.0 (euid=501
  uid=501) NO_ROOT" -> app-bundle setuid bit is not honored on iOS (expected mount/
  policy behavior). Plumbing itself fully working now (spawn + streamed output + codes).
- v0.1.3 build 4: privilege via the device-PROVEN mechanism — the jb's sudo (worked
  on-device from NewTerm). App spawns /var/jb/usr/bin/sudo -S -p '' <helper> <mode>,
  feeds standard password "alpine" on stdin, detects "try again/incorrect password"
  and instructs accordingly. Fallback (typed commands, proven round 2) stays documented.
- Awaiting: BTKit 0.1.3 run — expect euid=0 in helper banner, then STOP/RESTORE/SWEEP.
- Formal status: PARTIAL.

### Session-6r (v0.1.3: auth correctly detected — password is not alpine -> v0.1.4 two paths)
- v0.1.3 behaved exactly as designed: sudo ran, alpine rejected, AUTH FAILED guidance
  shown. Password stays private (user told not to share it).
- v0.1.4 build 5: two device-local paths — (A) in-app secure password field (memory
  only, not saved/logged) driving sudo -S; (B) one-time 2-line NewTerm setup copying
  the helper to /var/jb/usr/bin/bthelper + chmod 6755, where setuid IS honored (sudo
  itself is setuid on that mount) -> password-free forever. Resolution order: fixed
  copy first, else sudo+password, else instructions in-app.
- Awaiting: run via path B (recommended) or A; then STOP -> SWEEP -> CONFIG line.
- Formal status: PARTIAL.

### Session-6s (ROOT ACHIEVED in BTKit; argv bug -> v0.1.5)
- euid=0 confirmed via sudo path (user picked password field; password stays on device).
- launchctl calls failed on argv-splitting (single-string subcommand) — fixed properly
  with run_argv. v0.1.5 build 6 shipped.
- Expected next run: STOP bootouts succeed -> "port test: open() OK" in STOP log;
  SWEEP runs 12 combos -> COMMAND COMPLETE + CONFIG line.
- Formal status: PARTIAL (transport experiment on the verge of full confirmation).

### Session-6t (v0.1.6: launchd-free process kill for the UART holder)
- Round-6 run: argv OK, root OK, but "No such process" on both bootouts with EBUSY persisting
  -> holder not under those launchd labels. v0.1.6/helper v0.2.2: sysctl process enumeration +
  TERM/KILL of *bluet* processes + port test. Awaiting device run (STOP -> SWEEP -> COPY).
- Formal status: PARTIAL.

### Session-6u (v0.1.7: "blue" filter + full process dump fallback)
- v0.1.6 proved process-kill works (BlueTool terminated) but holder #2 remains (EBUSY).
- Suspect "blued" missed by "bluet" filter. v0.1.7: "blue" filter + full pid/name dump
  if still busy. Awaiting device run.
- Formal status: PARTIAL.

### Session-6v (process dump exposed the true holder: stuck btiotest; v0.1.8 tiered kill)
- v0.1.7's full dump found 8784 btiotest (stuck since terminal round 2 — v0.1.0 drain
  loop never exits while chip streams) = the persistent EBUSY holder; plus discovered
  FindMyDeviceBlue as a new BT family; BTLEServer/WirelessRadioManagerd as tier-2 suspects.
- v0.1.8/helper v0.2.4: tiered kill in one STOP press (tier1 blue*+btiotest -> test ->
  tier2 BT-adjacent -> test -> dump). Awaiting device run: STOP -> PORT FREE -> SWEEP.
- Formal status: PARTIAL.

### Session-6w (v0.1.8 run: bootout finally OK, all holders dead, EBUSY persists -> latch hypothesis; v0.1.9 probes + airplane recipe)
- v0.1.8: first successful bootout; killed bluetoothd/BlueTool/FindMyDeviceBlue; btiotest
  8784 gone; still EBUSY. tier2 respawners (rapportd/WRMd) revive in ~1 s.
- Hypothesis: driver-level UART latch from cold signal-kill (round-2 success always had
  airplane ON first). v0.1.9: auto-probes x4 in STOP + airplane instruction; intro shows
  airplane-first tip. Next run: airplane ON -> STOP -> (probes) -> SWEEP -> log -> RESTORE.
- Formal status: PARTIAL.

- BTKit v0.1.10 build 11 green: helper v0.2.6 packaged (setuid 4755 verified, lsof +
  selftest strings in binary). Device install deferred pending SSH-track decision.

- SSH track ready both sides: agent egress verified (pinggy.io reachable, OpenSSH 10),
  runbook round 12 = 4-step user guide (check server -> optional Sileo install ->
  install agent pubkey -> pinggy tunnel + screenshot).

### Session-6z (BTKit v0.1.11: SSH-by-buttons — 4 SSH KEY, 5 BRIDGE; zero typing)
- User declined terminal typing -> SSH track folded into BTKit as buttons. Build green,
  packaged, setuid verified. Flow: install 0.1.11 -> password -> 4 (expect ROOT-SSH-OK or
  Sileo hint) -> 5 (expect tcp:// address in log) -> COPY LOG -> paste in chat -> agent
  connects via bridge and diagnoses EBUSY itself. Awaiting device run.
- Formal status: PARTIAL.

### Session-7a (v0.1.12: jb-path fix for ssh detection + sshd auto-kickstart)
- Keys installed fine on first try; only detection paths were wrong. v0.1.12 built,
  packaged, setuid verified. Next device run: press 4 -> expect "ssh client:
  /var/jb/usr/bin/ssh" + ROOT-SSH-OK -> press 5 -> tcp:// address -> COPY LOG.
- Formal status: PARTIAL.

### Session-7b (bridge live; sshd key-policy fix = button 6; v0.1.13)
- Pinggy tunnel WORKS (60 min), sshd denies key -> v0.1.13 adds SSH FIX (config evidence +
  prepend-first rewrite + retest). Next device run: 4 -> 6 (expect ROOT-SSH-OK) -> 5
  (fresh address if old expired) -> COPY LOG -> agent connects.
- Formal status: PARTIAL.

### Session-7c (tunnel chain proven from agent side; sshfix v2 with server-side interrogation; v0.1.14)
- Probe: sandbox -> pinggy -> phone sshd = ANSWERS (denied only at auth). One fix away.
- v0.1.14 built/packaged/setuid-verified. Next run: 4 -> 6 -> COPY LOG (log now contains
  config-before, plist, and sshd's own rejection reason) -> 5 -> agent connects.
- Formal status: PARTIAL.

### Session-7d (2222 collision discovered; sshfix v3: fresh-port 2022 + loose overrides + netstat dump; v0.1.15)
- Next device run: 4 -> 6 -> COPY LOG. Decisive outputs: netstat listeners (who owns
  2222), DEBUG-ROOT-SSH-OK yes/no, sshd confession text.
- Formal status: PARTIAL.

### Session-7e (key offered+refused proven; own-sshd replacement = sshfix v4; v0.1.16)
- Next: install 0.1.16 -> 4 -> 6 -> 5 -> COPY LOG -> agent probes -> feedback loop via
  re-press 6 (log tail). Parallel track: same helper has kernel lsof for UART EBUSY
  (Airplane ON -> 1 STOP -> COPY LOG) — UART quest no longer blocked on SSH.
- Formal status: PARTIAL.

### Session-7f (SSH ROOT ACHIEVED; UART architecture decoded; device restored; battery incident)
- Agent now has persistent device access pattern: BTKit buttons 4/5/6 + pinggy + our sshd.
- G1.6 status: port-open trivially reproducible when stack idle; chip needs BlueTool
  bring-up (power GPIO + firmware) to answer; takeover-of-live-chip not yet achieved
  (bring-up loop + battery interruption). NEXT: retry with charged battery, possibly
  wrapper label exactly stock + single MachServices holder + watchdog on >=1M baud.
- Device state: STOCK BT stack restored; our sshd door open; experimental tools parked
  in /var/root; backups (.btkit.bak sshd_config) present.
- Formal status: PARTIAL (major infrastructure + knowledge gains).

### Session-7g (v0.1.18: LIVE VIEW — button 7 toggles 1s-poll live log screen in-app)
- Button 7 = toggle: pollAgent() reads /var/mobile/Documents/agent-activity.log every
  second into the app log view (auto-scroll); press again to stop; other buttons stop
  live mode automatically. File auto-created if missing. Helper unchanged (0.2.13).

### Session-7h (v0.1.19: bottom docked button bar — user request "รกจอ")
- All 8 buttons -> compact 2-row bar docked to bottom safe area (short titles
  1 STOP/2 SWEEP/3 RESTORE/4 KEY | 5 BRIDGE/6 FIX/7 LIVE/COPY), log fills the screen
  above. Helper unchanged (0.2.13). Functionality identical.

### Session-7i (🏆 CHIP SPOKE — BCM4355C0; remote BlueTool console via up4 fifo; G1.6 chip-reply captured)
- Formal status: G1.6 chip-reply MILESTONE DONE. Remaining: direct transport (our fd) for
  ds4bridged 0.3.0. Route defined: bcm -W -> bcm -b -> SEIZE -> direct HCI -> G3 -> G4/G5.
- Device state: up4+BlueTool session alive with port open @115200; chip answering HCI;
  airplane mode ON on device (user parked it); BT toggle spinner secondary issue.

### Session-7j (firmware loaded; chip = BCM4355C0 Elsa; BSD-termios verdict; BlueTool-pipe architecture chosen)
- G1.6 milestones banked: HCD firmware via bcm -W, identity+addr, 6M baud ops, remote
  console. Direct-fd G3 as originally designed = IMPOSSIBLE on this driver (no termios).
- NEW PATH: ds4bridged 0.3.0 = BlueTool-pipe transport (hci cmd TX + stdout RX via up4).
  Next sessions: (1) revive chip reliably (power/wake/reset recipe), (2) hci cmd reply
  parser, (3) spam streaming benchmark, (4) build 0.3.0, (5) DS4 emulation to iPhone B.

### Session-7k (golden window replicated; EBUSY final verdict; system power map; PIVOT to stack-riding daemon)
- Chip healthy @6M under stock stack; BT usable on phone (CC toggle works; Settings
  spinner cosmetic). UART path = only when BT off/stack down. aci/bcm/hci all UART-bound.
- Power map: power GPIO 88, wake GPIO 33, calib blob in DeviceTree. kickstart bluetoothd
  = chip power cycle (dangerous to sessions).
- NEXT BUILD (workspace, no device needed): CB daemon "bcgamed" v0.1 — BLE HID gamepad
  via CoreBluetooth PeripheralManager + fake entitlements; test = iPhone B sees/pairs it.
