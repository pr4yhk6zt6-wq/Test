# 12 — Phase-3 Lab Plan (revised after E14–E17 research)

Phase-3 = make iPhone A's Bluetooth controller act in **device role** so B pairs to A as a controller. This document is the concrete, falsifiable plan. Formal status stays PARTIAL until T7/T8/T9 pass on the real devices (docs/08).

## 1. What changed after the new evidence

| Evidence | Consequence |
|---|---|
| **internalblued** (InternalBlue project) is a jailbroken-iPhone daemon that bridges the BT controller's HCI to TCP; supported: **iPhone 6/7/SE/8/XR (UART Broadcom)**, tested iOS 12–13 [E14] | HCI access from userland on the exact chip family iOS 15.8.x devices use is a **published, reproducible technique** — the Phase-3 transport is no longer speculative, it is a port/verification task |
| **BlueTool** (Apple's own tool) accepts raw HCI commands (`hci cmd 0x2018`), runs only while BT is off; since iOS 13.6 BT firmware (.hcd) is embedded **inside BlueTool**; WriteRAM (0xFC4D) blocked since iOS 13.3 [E14] | (a) instant on-device HCI smoke test exists; (b) `idiag` v0.3 scans BlueTool strings for chip identity; (c) firmware-patch track needs the 0x4c→0x42 WriteRAM trick — higher risk, later step |
| Historic iPhone: `/dev/uart.bluetooth` + `/dev/btreset` userland HCI over UART; chip boots via BlueTool script then host talks HCI directly [E15] | The device-node architecture on A is known-shaped; `idiag` v0.3 enumerates these nodes |
| Frankenstein (USENIX'20): patchram/ROM work on jailbroken iPhone SE/7/8/X/XR (BCM4345-class) [E16] | Chip-level experimentation precedent on our target class |
| joycontrol: open-source **Joy-Con L/R/Pro emulation over BT** (HCI-level, Python) [E17] | Reference implementation for the BLE identity track; `src/ds4bridge/src/hogp.c` DB mirrors this direction |

## 2. Toolkit status for Phase-3

| Piece | Status |
|---|---|
| DS4 report 0x11 packer + HID state machine | DONE, 54/54 host tests pass |
| SDP record builder (HID + PnP) | DONE, tested |
| **SDP responder** (ServiceSearchAttribute + continuation) | DONE, byte-level tested (`src/ds4bridge/src/sdp_server.c`) |
| **HOGP/Joy-Con GATT DB builder** (BLE identity skeleton) | DONE, tested (`src/ds4bridge/src/hogp.c`); byte-exact Joy-Con map = capture task |
| **ds4lab** (BlueZ lab backend: PC+BT dongle plays the DS4 identity, input via UDP from A or demo sweep) | BUILT (compiles+links); **NOT TESTED — sandbox has no BT adapter** |
| On-device HCI transport (internalblued port / BlueTool scripting) | NOT BUILT — needs A's audit data first |
| L2CAP signaling (connection req/config over HCI) | NOT BUILT — next implementation task, only after transport exists |

## 3. Experiment ladder (each step falsifiable; record EVERY attempt in docs/09)

```
G1  Run idiag v0.3 on A (root) ->
      chip tokens from BlueTool strings, /dev/uart.bluetooth presence, jb type
      ├─ UART chip (BCM4xxx) → G2
      └─ PCIe chip (A12+... would contradict 15.8.x jb expectation) → reassess

G2  BlueTool smoke test (documented interface, BT toggled off) [E14]:
        device -D
        hci cmd 0x2018        (HCI_Read_Local_Version_Information)
      ├─ version event printed → HCI control path WORKS on iOS 15.8.8 (major gate)
      └─ refused/absent → try internalblued path G3

G3  Port/build internalblued (or equivalent socket proxy) for iOS 15.8.8 arm64
    [STATUS 2026-09-27] HOST SIDE DONE + sandbox-verified: hci_transport.h /
    hci_reader.c (framer + TCP) / hci_link.c (HCI cmds + L2CAP signaling +
    HID routing) — 70/70 mock-controller tests PASS, incl. TCP byte-split
    loopback. iOS-side transport (BlueTool `hci` bridge or /dev/uart.bluetooth
    io backend hci_io_uart) still NOT RUN on device.
    rootless [E14]; verify on-device HCI-over-TCP; connect InternalBlue from PC
      ├─ works → HCI transport available → G4
      └─ fails → capture exact failure (entitlement? socket path? PCIe?) → docs/09

G4  Implement minimal BT host over that transport (L2CAP signaling + SDP
    responder [DONE] + HID channels [DONE] + SSP Just-Works pairing);
    pair iPhone B.
      ├─ B sees "Wireless Controller" → G5
      └─ pairing rejected → capture HCI trace via the same proxy → analyze

G5  Stream reports from ControllerA (UDS→daemon) → game input on B.
      PASS ⇒ acceptance I/J/K achievable → proceed to T7/T8/T9.

BLE public-API note (FINAL, E20): the CoreBluetooth HID path is **PROVEN BLOCKED
on-device** — addService(0x1812) refused with CBError 8 under full entitlements
(v0.3.1 crash was fixed first; the refusal is genuine, not a side effect).
Chip-level tracks (G2–G5, G-B1, G-B2) do NOT use CoreBluetooth and are now the
ONLY remaining paths. Open secondary question: does iPhone B see the probe-2
advertisement ("ControllerA")? (pure visibility evidence, not HID).

BLE fallback track (parallel, cheaper hardware-wise):
G-B1 ds4lab + PC BT dongle: validate the whole identity stack against REAL
     iPhone B without any A-side work (PC is a labeled lab instrument).
      PASS ⇒ identity/protocol validated; remaining risk isolated to A's chip
G-B2 Joy-Con-shaped BLE identity on A (needs BLE device-role + hogp.c DB;
     joycontrol [E17] as reference). iOS-side acceptance UNKNOWN.
```

Kill criteria (rule 32): if G1–G3 all fail with captured evidence that no HCI
transport exists on A's chip/OS combination, Phase-3 BT-Classic track is
PROVEN BLOCKED **on this device**; the project reports PARTIAL with the BLE
fallback status.

## 4. Risk register (Phase-3)

- iOS 15.8.8 may have moved BlueTool/dev-node surfaces → idiag v0.3 answers this first.
- SSP pairing at raw-HCI level is the largest engineering piece; Just-Works association is standard but the host must implement it.
- A11 devices: passcode disabled while jailbroken [E2] — acceptable for a dedicated controller, but must be stated.
- Battery/Wi-Fi coexistence on the combo chip while streaming 120 Hz — measure in T9.

### E21 addendum (2026-09-27)
Before writing off user-facing BLE entirely: ProbeBLE.ipa (v0.1.0, NOT RUN) tests the
128-bit spelling of 0x1812 (short form = E20-proven blocked). If long form publishes AND
iPhone B pairs it as a gamepad, the BLE public-API track reopens as the PRIMARY route and
the G-track becomes fallback. Either outcome, the G3 host stack remains valid work
(classic-BT DS4 identity is still the only path if B filters generic BLE HID).

### G1 path note (2026-09-27)
Primary G1 instrument is now idiagTS.ipa (no jailbreak needed; TrollStore entitlements).
It also attempts open("/dev/uart.bluetooth") from a TS app — if that succeeds, a direct
userland-HCI transport (hci_io_uart) may be feasible WITHOUT any jailbreak, short-circuiting
G2. LaunchDaemon/deb path remains for the jb case (runbook parked, not deleted).

### G1.5 — palera1n gate (2026-09-27, decision pending: user's computer OS)
- Device: iPhone 7 (A10/iPhone9,3, checkm8) on 15.8.8 -> palera1n SUPPORTED (iOS 15.0-18.x,
  rootless default). A10 has no A11-style erase requirement; BUT iOS 15 palera1n rule:
  passcode must be OFF while jailbroken (re-enable when not jb'd). Semi-tethered: full
  power-off requires the computer again; daily use = userspace reboot from loader.
- WARNINGS recorded: use ONLY official palera1n (palera1n.com). "Palera1n Online"/no-PC
  sites (silzee etc.) are ad/scam fronts, NOT the real tool — do not use. iCloud backup
  first. Rootless = no data wipe.
- Post-jb plan: (a) full idiag as root (chip via IORegistry now readable); (b) NewTerm/ssh
  -> launchctl stop bluetoothd -> retry open(/dev/uart.bluetooth) (EBUSY expected to clear)
  -> G3 hci_io_uart; (c) BlueTool `hci cmd 0x2018` smoke (G2); (d) install ds4bridged .deb.
- User asked "should I jailbreak now?" -> YES (only remaining path to controller identity
  on iPhone B), pending computer availability (macOS/Linux direct; Windows via WSL+usbipd
  or Linux live USB — instructions differ, asked user).

### G1.6 (2026-09-27): jailbreak live — device experiments issued
Runbook: tools/idiag-g1/G16-runbook-postjb.md. Instruments: idiag 0.4.0 (root: IOKit chip
identity) + btiotest 0.1.0 (UART open probe, -w sends HCI Reset and detects Command
Complete) + BlueTool 0x2018. EBUSY-clearing ladder: Settings-off -> killall bluetoothd ->
launchctl stop <label>. Success = open() OK + Command Complete => wire hci_io_uart into
ds4bridged (daemon) as the G3 transport; app feeds via UDS as designed.
