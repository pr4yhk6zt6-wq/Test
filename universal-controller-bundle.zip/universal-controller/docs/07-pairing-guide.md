# 07 — Pairing Guide (A → B)

**STATUS: procedure documented, NOT YET EXECUTABLE end-to-end — the BT device-role capability on A is the Phase-3 research gate (docs/05).** Do not assume pairing works until T4/T5/T6 tests pass. B-side steps below are normal user actions only (nothing is installed or modified on B).

## What pairing will look like once a device-role path exists

1. iPhone A: start ControllerA (or the Phase-3 daemon) in "controller" mode → A's Bluetooth becomes discoverable as the chosen identity (DS4-shaped first candidate).
2. iPhone B: **Settings → Bluetooth** → the device appears under "Other Devices" (this is exactly how a real DualShock 4 appears [E3]) → tap to pair.
3. If paired-but-idle: launch a GameController-aware game on B and press the identity's "PS-equivalent" button to reconnect.
4. Verify recognition on B without any game: Settings → General? Not required; use any controller-aware game or the Apple TV Remote-style HUD in supported games. (A dedicated GCController test app on B would violate the boundary — recognition must be observable through stock UI/games only.)

## Interim validation experiments (allowed, clearly labeled)

| Test | Device(s) | What it proves |
|---|---|---|
| T4: real DS4 → B | B only | B-side path healthy on iOS 27 (control experiment) |
| T5: ESP32 DS4-emulator → B | B + lab MCU (external instrument, NOT shipped) | end-to-end DS4 emulation is accepted by stock iOS 27 — validates the whole identity/transport choice before any A-side BT work |
| T3: ControllerA BLE probe visible on B | A + B | BLE visibility/pairing behavior of a TrollStore app on A (evidence for the BLE residual track) |

## Safety / boundary reminders

- B must never be asked to install, trust, or configure anything beyond standard Bluetooth pairing.
- A11 devices on palera1n run with passcode disabled while jailbroken [E2] — treat A as a dedicated controller device.
