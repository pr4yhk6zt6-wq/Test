# 05 — Architecture Decision Record (chosen architecture + rejected tracks)

## FINAL OBJECTIVE (unchanged)

```
iPhone A (iOS 15.8.8, jailbroken, TrollStore)  ──Bluetooth──▶  iPhone B (iOS 27, stock)
        acts as a *recognized controller identity*                    native games
```
Hard boundary: zero software/changes on B; no PC/Mac/Pi/hardware bridge in the shipped system.

## CHOSEN: phased hybrid (Track K), entirely on iPhone A

```
PHASE 1 — ControllerA.app (TrollStore)                    [BUILT — build verified]
  Controller UI (2 sticks, D-pad, A/B/X/Y, L1/R1, analog L2/R2, Menu/View)
      → InputManager (120 Hz, deadzone, CRC, seq, stale timeout, latency counters)
          → Transports: UDP lab instrument · UDS (to future daemon) · BLE probe harness

PHASE 2 — ds4bridge protocol core (portable C)            [BUILT — 41/41 unit tests pass]
  ICInputPacket wire format → DS4 BT report 0x11 packer (GIMX/dsremap layout)
  HID report map + validator · SDP HID+PnP records · BT-HID device-role state machine
  (control/interrupt PSMs, GET/SET_REPORT, handshake, keepalive, stale→neutral)

PHASE 3 — make iPhone A's Bluetooth chip BE that device   [RESEARCH GATE — UNKNOWN]
  Transport prior art (published): internalblued bridges jailbroken-iPhone BT
  HCI to TCP on UART-Broadcom iPhones (6/7/SE/8/XR, iOS 12–13) [E14]; BlueTool
  accepts raw HCI commands [E14]. Ladder (full detail: docs/12):
    G1  idiag v0.3 → chip tokens (BlueTool strings), /dev/uart.bluetooth, jb type
    G2  BlueTool raw-HCI smoke test (hci cmd 0x2018)
    G3  internalblued-style HCI-over-TCP port for iOS 15.8.8 rootless
    G4  minimal BT host (L2CAP signaling + SDP responder [DONE] + HID channels
        [DONE] + SSP Just-Works) over that transport → pair B
    G5  stream ControllerA input → game input on B
  Parallel BLE fallback: ds4lab (PC+BT dongle, built) validates the whole
  identity against real B; Joy-Con-shaped identity via hogp.c [E17].
  Kill criteria: if G1–G3 all fail with captured evidence ⇒ Phase-3 BT-Classic
  PROVEN BLOCKED on this device; report PARTIAL (rules 12, 32).
```

Why phased: Phase 1+2 are fully buildable/verifiable today and are required by ANY
end-state; Phase 3 is the single remaining UNKNOWN and is structured as falsifiable
experiments, not assumptions.

## REJECTED tracks (rule 10/13)

| Track | Reason for rejection |
|---|---|
| Anything installing software on B (companion app, tweak, GCVirtualController) | violates ABSOLUTE DEVICE BOUNDARY |
| Wi-Fi/network controller | no controller ingress on stock iOS; receiver on B required ⇒ reject |
| PC/Mac/Pi/hardware bridge | explicitly forbidden |
| CoreBluetooth HID peripheral (public API) | **PROVEN BLOCKED — verified on our device** (CBError 8 under full entitlements, E20; matches E6). Entitlements do not bypass: the block is CoreBluetooth's UUID allow-list. CLOSED. |
| Generic BLE HID gamepad identity | B would pair it but GameController ignores generic HID gamepads [E5] |
| iCade / keyboard-event emulation | games must opt in ⇒ violates UNIVERSAL requirement (rule 5/30) |

## Wire/protocol summary (Phase 2, verified by tests)

- `ICInputPacket` 25 bytes, CRC-16/CCITT-FALSE, seq8+seq16, ms timestamp, stale policy 250 ms.
- DS4 BT input report 0x11 (49-byte CRC-disabled form), layout per GIMX/dsremap docs [E9, E10a]:
  `[0]=0x11 [1]=0x80 [2]=0x00 [3]=counter [4..7]=LX,LY,RX,RY [8]=hat<<4|SQ,CR,CI,TR [9]=L1,R1,L2b,R2b,SHARE,OPT,L3,R3 [10]=PS/TP [11]=L2 [12]=R2 [13..14]=ts [15]=battery`.
  Two UNVERIFIED details flagged in code: (a) 0x80 vs 0xC0 flags byte, (b) 49-byte no-CRC vs 78-byte CRC form — Phase-3 capture decides.
- SDP: HID record (class 0x1124, PSM 17 control / 19 interrupt, HIDDescriptorList→report map, subclass 0x08 gamepad) + separate PnP DeviceID record (VID 0x054C / PID 0x09CC / USB source).
- Input→DS4 mapping: A→CROSS, B→CIRCLE, X→SQUARE, Y→TRIANGLE, Menu→OPTIONS, View→SHARE, L2/R2 analog bytes (+ digital bit >127).

## Requirement coverage (rule 6)

Left/Right sticks ✓, D-pad ✓, A/B/X/Y ✓, L1/R1 ✓, analog L2/R2 ✓, Menu ✓, View/Select ✓ — all present in UI, wire format, DS4 report and HID map. Universal: no game-specific code path anywhere (grep-able: no bundle-id / game-name matching in src/).
