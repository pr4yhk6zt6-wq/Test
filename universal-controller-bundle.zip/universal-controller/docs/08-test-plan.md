# 08 — Test Plan & Record (rules 24–27)

## 8.1 What has ALREADY been tested (host environment — Linux x86_64 sandbox, EXTERNAL)

| Test | Result | Log |
|---|---|---|
| ds4bridge unit tests (CRC vectors, wire format, DS4 report layout, SDP records, HID state machine, stale policy, bad-packet rejection) | **41/41 PASS** | artifacts/logs/ds4bridge-unit-tests.txt |
| UDP echo mechanics (wire format round-trip through udp_echo + Python client, 200 pkts loopback) | **200/200 replies, 0 loss** (loopback — NOT a device latency figure) | artifacts/logs/udp-echo-loopback-test.txt |
| Cross-compile: ControllerA.ipa (arm64, min iOS 15.0), idiag.deb, ds4bridged.deb | **BUILD VERIFIED** | this repo artifacts/ |

## 8.2 Hardware test record — MUST be filled on the real devices (NOT RUN)

```
A Model:                    __UNKNOWN__ (idiag)
A iOS: 15.8.8               VERIFIED (device ran ControllerA v0.2.0, E18)
A Jailbreak:                __UNKNOWN__ (palera1n? Dopamine? version?)
A Rootless/Rootful:         __UNKNOWN__
A TrollStore:               VERIFIED (installed v0.2.0 IPA successfully; version UNKNOWN)
A BT chip:                  __UNKNOWN__ (idiag IOKit)
B Model:                    __UNKNOWN__
B iOS: 27                   (user-confirmed)
B Build:                    __UNKNOWN__
```

### Test sequence (also runnable via tools/hw-test-checklist.sh)

| ID | Test (rule refs) | Pass criterion | Result |
|---|---|---|---|
| T0 | Device audit (0.2) | idiag output fills all UNKNOWNs above | NOT RUN |
| T1 | TrollStore install of ControllerA.ipa (31-C) | app launches, UI renders | NOT RUN |
| T2 | Input pipeline + latency (26, 27) | all 13 inputs seen in packet stream; RTT displayed vs udp_echo lab | NOT RUN |
| T3 | BLE probe v1 (E6 on-device) | **RUN — FAILED EARLIER THAN EXPECTED**: state stuck Unknown(0), no prompt, app crash (E18); "0x1812 BLOCKED" never reached | ON-DEVICE: state-stuck + crash |
| T3b | BLE probe v2 (0.3.0) + `idiag -c`/`-p` | **RUN — PARTIAL SUCCESS**: authorization/PM/CM all healthy (E19); crash root-caused to our characteristic bug | ON-DEVICE: root cause fixed |
| T3c | BLE probe (0.3.1) — decisive 0x1812 publish | **RUN: 0x1812 BLOCKED (CBError 8) — E6 CONFIRMED on-device**; custom-service advertising OK (E20) | ON-DEVICE: track closed (PROVEN BLOCKED at API level) |
| T3d | iPhone B sees "ControllerA" (probe-2 advertisement) in Settings>Bluetooth? | visibility evidence for app-peripherals | AWAITING USER REPORT |
| T4 | Control experiment: real DS4 → B (7, 25) | B pairs, game receives input | NOT RUN |
| T5 | ESP32 DS4-emulator → B (decisive identity test; lab instrument) | B exposes emulator as controller | NOT RUN |
| T6 | Phase-3 ladder on A (docs/05 G3.2) | per-step records in failure ledger | NOT RUN |
| T7 | Discovery test chain (25): A advertising → B discovery → pairing → recognized → appears to iOS → game receives input | end-to-end | NOT RUN |
| T8 | Full input matrix (26): all 13 inputs in a real game | each input works | NOT RUN |
| T9 | Connection quality (27): reconnect, disconnect detection, seq/timestamp, loss detection, stale timeout, safe disconnect, latency | all behaviors demonstrated | NOT RUN (stale/seq logic unit-tested on host) |

Rule: **no SUCCESS claim** until T7/T8/T9 pass on the exact A/B pair (rule 31/32).

## T-E21 (2026-09-27) — decisive B-side test, NO reinstall needed (uses installed ProbeBLE)

1. A: open ProbeBLE → press **T3** (long-form full HOGP) → press **T5** (advertise).
2. B (STOCK): Settings > Bluetooth → look for **"ProbeBLE"** → tap to pair.
   - If NOT listed: also try with A screen on/app foreground; record absence.
3. While paired: the probe auto-sends input (X-axis wiggle + cycling buttons ~2 Hz).
   On B check: does the device show "Connected"? In any controller-supporting game or
   a controller-test app on B, does input appear/move by itself?
4. A: press **T6** → paste the copied log back (look for new `SUBSCRIBED … 2A4D` lines).
5. Answer: was peer 38BA17A2-… iPhone B? did B list ProbeBLE? was it a gamepad?

Interpretation: B pairs + input visible → H-E21c (BLE track primary again; merge into
ControllerA v0.4.0). B pairs but no gamepad input → H-E21d (generic GATT only → G-track).
B never lists it → central-side filtering → G-track.

### T-E21a/T-E21b (2026-09-27) — zero-install follow-ups (NO reinstall of ours)

T-E21a (Android, the phone that already found ProbeBLE — as labeled instrument):
  In nRF Connect (or the scanner used): with ProbeBLE advertising (A: T3 then T5):
  1. Advertisement contents: does the AD show Service UUID **0x1812** (16-bit) and/or
     Appearance **0x03C4 (Gamepad)**? Screenshot the device entry.
  2. Does Android offer PAIR? If it pairs: what device type does Android show
     (input/gamepad)? Does a gamepad tester app on Android receive the auto-wiggle?

T-E21b (any iPhone signed into a DIFFERENT Apple ID than A — Settings only, no installs):
  1. While A advertises (T3+T5): Settings > Bluetooth — is "ProbeBLE" listed?
  2. Same test again on the iPhone 11 (same iCloud) for contrast.
  -> different-account iPhone sees it  = iCloud/Continuity factor real (H-E21e).
     no iPhone sees it, Android does   = Apple central filter (X4) confirmed on iOS.

Decision: Apple filter confirmed on iOS 27 -> BLE-to-B closed, G-track primary.
ADV missing 16-bit 0x1812/appearance -> we iterate advertisement first (CB API limits noted).
