# 10 — Known Limitations

1. **End-to-end goal not achieved yet.** Nothing here makes iPhone B see iPhone A as a controller *today*. The remaining blocker is Phase-3 (BT device role on A) — UNKNOWN, research-gated. Current formal status: PARTIAL (docs/STATUS.md).
2. ControllerA UI is foreground-only in practice: BLE advertising suspends when the app backgrounds unless state-restore modes are enabled; the daemon path (UDS) is the intended long-session design once Phase-3 lands.
3. DS4 report: 49-byte CRC-disabled form + 0x80 flags byte are UNVERIFIED against live captures; motion/touchpad segments are zero-filled (games relying on gyro/touch will see neutral data).
4. ControllerA UDP transport is a diagnostic instrument for a lab PC — it is explicitly NOT a path into iPhone B (no receiver exists on stock iOS) and must never be presented as one.
5. `idiag` filesystem heuristics for TrollStore/jailbreak detection are best-effort; anything not found prints UNKNOWN instead of a guess.
6. ds4bridged runs the protocol core on the null transport (self-test); the real HCI/L2CAP backend does not exist yet.
7. ControllerA has no rumble/motion/battery feedback to A (DS4 output reports parsed as no-ops in the core).
8. The ipa/debs are unsigned by a real Apple certificate (ldid fake-sign). TrollStore accepts this by design [E1]; a normal iOS device would not install them — irrelevant for B, which never receives any artifact.
9. Latency numbers do not exist yet (no hardware); the loopback figure in the logs is mechanics-only and must not be quoted as device latency.
