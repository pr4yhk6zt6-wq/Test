# 04 — Research Dossier (rule 8, 9, 16)

Full citations live in docs/11-evidence-register.md (E1–E12). Labels per rule 0.4: **A-side** / **B-side** / **EXTERNAL** / **UNKNOWN**.

## 1. How a stock iPhone accepts controllers (B-side, EXTERNAL)

1. **MFi controllers** — Bluetooth Classic HID; protocol details gated by MFi program (Apple engineer statement) [E10].
2. **Sony DualShock 4** (iOS 13+), **DualSense/Edge/Access** — BT Classic HID; Apple's support page (updated Sep 2026, i.e. current for iOS 26/27 era) still lists them [E3]. DS4 uses report 0x11 over BT with documented layout [E9, E10a].
3. **Microsoft Xbox One/Series controllers** (iOS 13/14+) [E10].
4. **Nintendo Switch Joy-Con / Pro Controller** (iOS 16+) — Joy-Cons pair over BLE [E4].
5. **Generic BLE HID gamepads** — reported NOT to appear in GameController.framework even when paired [E5]. ⇒ Apple matches *specific* device identities, not arbitrary HID gamepads.

Conclusion for architecture: to be a controller **without touching B**, A must present as one of the *specific* supported identities, over a transport B already accepts (BT Classic HID or the Joy-Con's BLE HID variant).

## 2. Transport options from iPhone A (A-side)

| Track | Mechanism | Verdict | Evidence |
|---|---|---|---|
| A. Public API (GCVirtualController) | on-device virtual controller | **REJECT** — runs on B ⇒ needs software on B | API semantics |
| A'. CoreBluetooth peripheral HID | publish HID-over-GATT service 0x1812 | **PROVEN BLOCKED** — iOS refuses to publish 0x1812 via CBPeripheralManager (CBErrorDomain Code=8); multiple independent sources incl. Apple-adjacent confirmations [E6] | EXTERNAL; on-device re-verification provided via ControllerA "BLE probe" |
| E. BLE HID device (chip-level) | drive BT controller directly (HOGP peripheral) | UNKNOWN — possible with chip access; must shape as Joy-Con to be recognized [E4, E5] | research |
| F. BT Classic HID device (DS4-shaped) | HCI/L2CAP device role | **Most probable end-state**: DS4 confirmed supported by current iOS [E3]; HID device role proven implementable on hosts with suitable BT controllers (ESP32 examples) [E8]; on iPhone A requires low-level BT access — **UNKNOWN**, research-grade (InternalBlue supports some BCM43xx incl. iPhone-6-era chips [E7]) | mixed |
| F'. Xbox-shaped emulation | vendor GATT | UNKNOWN — Xbox One S BLE stack details under-documented publicly; also likely uses HID GATT services blocked by E6 | research |
| G. Network (Wi-Fi) | send input over Wi-Fi | **REJECT** — GameController.framework has no network-controller ingress; receiver app on B would be required (violates boundary) | API semantics |
| B/C. Tweak/daemon on A | enabling components | YES but only as *enablers* for Track F/E, not alternatives | design |
| H. System-level BT emulation via blued | hijack/extend Apple's BT daemon | UNKNOWN — no public research found; to investigate in Phase 3 (blued/BlueTool analysis on-device) | research |
| I. Existing implementations | none found that turn an iDevice into a recognized controller with zero B-side software [E8 scan]; projects like Bluepad32/ESP32-HID prove the protocol layer on other hardware | partially reusable | EXTERNAL |
| K. Discovered hybrid | **Phased plan in docs/05**: Phase-1 (app+probes) → Phase-2 (DS4 protocol core, done) → Phase-3 (BT device role on A) with kill-criteria | chosen | this project |

## 3. HCI access on jailbroken iOS (Phase-3 transport, added after E14–E17)

- **internalblued** — published daemon for jailbroken iPhones that bridges the BT controller HCI interface to TCP: supports UART-Broadcom iPhones (6/7/SE/8/XR), tested iOS 12–13; PCIe-BT devices (Xs/11/SE2) listed but untested [E14]. ⇒ userland HCI control of the BT controller on the A8–A11 chip family is established prior art, not speculation.
- **BlueTool** — Apple's own userland BT tool: boots the chip, accepts raw HCI commands (`hci cmd 0x2018`), runs only with BT toggled off; WriteRAM (0xFC4D) blocked since iOS 13.3; BT firmware (.hcd) embedded inside BlueTool since iOS 13.6 [E14]. ⇒ cheap on-device smoke test + chip-identity via embedded firmware tokens (idiag v0.3 scans this).
- **/dev/uart.bluetooth + /dev/btreset** — historic iPhone userland-HCI device nodes; chip init via BlueTool boot script, then HCI directly [E15].
- **Frankenstein (USENIX'20)** — patchram/ROM extraction on jailbroken iPhone SE/7/8/X/XR (BCM4345-class) [E16] ⇒ chip-level experimentation precedent on the target class.
- **joycontrol** — open-source Joy-Con/Pro-Controller BT emulation (HCI-level, Python, for Switch) [E17] ⇒ reference for the BLE identity track; our hogp.c DB mirrors this direction.

Conclusion: Phase-3's core unknown (driving A's BT controller in device role) now has **published technique coverage on the exact hardware class**; what remains is verification on iOS 15.8.8 specifically (docs/12 ladder G1–G3). Still UNKNOWN until idiag output + experiments — not assumed.

## 4. Existing project scan (rule 16) — summary

- `StryderUK/BluetoothHID` (ESP32, BT-Classic HID device + DS4 example) — proves profile mechanics; not iPhone-targeted [E8].
- `esp-idf` classic BT HID device component — same.
- `Bluepad32` — gamepad *host*, not device emulation.
- iOS-side "phone as gamepad" apps (Joypad-class) — all require a receiver app on B ⇒ **REJECT** by boundary rule.
- InternalBlue — Broadcom BT firmware research framework; chip list includes iPhone-6-era BCM4345 [E7]; host tooling normally runs on a PC — porting to on-device iOS is a research task, not a drop-in.

No existing open-source project satisfies the full constraint set ⇒ new implementation built here (rule 17): ControllerA app + ds4bridge protocol core (both delivered, build-verified) + Phase-3 research gate.
