# E21 — CBError 8 (0x1812): scope of the block and the long-form (128-bit) bypass question

Date: 2026-09-27 · Status: **H-E21a CONFIRMED on device (log archived); B-side verdict PENDING** · Related: E6 (external), E20 (on-device short-form), docs/12 G-track

## Why this file exists

User asked to "fix" the E20 block. E20's on-device verdict (CBErrorDomain code=8 on
`addService` with `CBUUID UUIDWithString:@"1812"`) is correct and stands — but a
source review on 2026-09-27 found that **the verdict is scoped to the 16-bit ("short")
UUID spelling**, because that is the only form our probe ever tried. Multiple
independent public sources report that iOS accepts the **long (128-bit) spelling**
`00001812-0000-1000-8000-00805F9B34FB` of the *same* UUID on modern iOS.
On iOS 15.8.8 this is **UNKNOWN** → E21.

## Evidence table (external, labeled)

| # | Source (date) | Platform | Long form result |
|---|---|---|---|
| X1 | sassembla blog 2014 (iOS 7/8 era) | iOS peripheral | **BLOCKED** — `00001812-…` also got "UUID not allowed". Also compiled short-form deny list: 0x1801, 0x1812 denied; 0x180D/0x180F/0x1808… allowed |
| X2 | SO 44579031 (2017) | iOS | Short-form **HID characteristics also blocked individually** (2A4A, 2A33, 2A4B, 2A4D, 2A4E) even under a custom service |
| X3 | conath gist comments (2022–2024) | macOS (commenters) | Long form **added OK**; one commenter: connection + didReceiveRead fired; another: paired but no callbacks (inconclusive GATT) |
| X4 | Apple dev forum 725238 (~2023) | iPad + App Store app "Bluetouch" | An App Store app **advertises 0x1812 from an iPad** (seen by BLE analyzer, Windows, Android; NOT visible from a MacBook system scan) |
| X5 | HemiPad PR #18 (2026-09, AI-assisted hobby project) | iPad (iOS ≥ 15 era) | Working recipe: HID service published in **long form**; + Report Reference 0x2908 per report; + Device Information/PnP; hosts accepting it: Windows/Linux/Android; refusing: Switch/PS5/Xbox; iOS-as-central: not claimed |
| X6 | Bluetouch (App Store id1622635358, user reports incl. 2025-10 visionOS) | iPhone as BLE HID keyboard | Shipping app = existence proof that some 0x1812 publish path works on current iOS from a third-party app |
| X7 | 8BitDo official (iOS 18.5+); r/8bitdo 2019 | iPhone as HID central | Apple centrals pair generic gamepads more openly on iOS 18.5+; older trick paired DS4-emulating devices — suggests generic-HID gamepad→GCController on iOS 27 is possible but UNVERIFIED |

Reading: the deny-list likely string/short-form based, and modern iOS accepts the long
spelling at `addService` (X3/X5/X6), while iOS 7/8 blocked both (X1). Where iOS 15.8.8
falls = the E21 question. Whether an *added* long-form service also normalizes to HID
for the *peer* (and whether iPhone B's HID host/GCController accepts a generic BLE-HID
gamepad, X7) are downstream UNKNOWNs measured by the same test round.

## Hypotheses

- **H-E21a (primary):** on iOS 15.8.8, `addService` accepts the long-form spelling
  (service and characteristics), because the check compares short-form UUIDs.
- **H-E21b:** long form is also refused (2014 behavior persists) → the check
  normalizes → BLE public-API stays PROVEN BLOCKED; remaining paths = blued-level
  patch (jailbroken A) or the chip-level HCI track (G3, already built host-side).
- **H-E21c:** long form adds, B pairs and it acts as a gamepad on B → BLE public-API
  track REOPENED end-to-end for our use case.
- **H-E21d:** long form adds, B pairs but B treats it as generic GATT/keyboard only
  (no GCController gamepad) → HID-identity path needs classic-BT DS4 emulation (G-track).

## Artifact built for this round

- `artifacts/ProbeBLE.ipa` v0.1.0 build 1 — **SEPARATE app, does not touch
  ControllerA v0.3.2 (FINAL)**. Buttons: T1 short svc (control, expect CBError 8),
  T2 long svc only, T3 long full-HOGP (2A4B/2A4D+0x2908 descriptor/2A4E/2A4A, all
  value:nil reads served dynamically per E19 lesson), T4 short full-HOGP,
  T5 advertise (LocalName "ProbeBLE" + long svc), T6 stop + copy log.
  60 Hz 8-byte input report (reportID 1, X/Y/Z/RZ, hat, 16 buttons) matches the
  built-in gamepad report map, so a paired host visibly reacts.
- Status: **BUILD VERIFIED (sandbox), NOT RUN on device** — needs one TrollStore
  install. Zero-code alternative checklist: `tools/ble-longform-zeroinstall-test.md`.

## Kill / decision rules

- If T2/T3 return code=8 → H-E21b: BLE public-API stays closed (E20 restored as
  blanket verdict), record and stay on G-track.
- If T3 OK + B pairs + gamepad works → H-E21c: BLE public-API reopened; G-track
  becomes the fallback.
- If T3 OK but B doesn't see/pair → X4-style central-side filtering; test with
  non-Apple scanner only; HID-identity via BLE unlikely to reach B; stay on G-track.


## DEVICE RESULT (2026-09-27, ProbeBLE v0.1.0 — artifacts/evidence/E21-probeble-log.txt)

- **H-E21a CONFIRMED**: T1/T4 (short form) → CBError 8 every time (E20 reproduced as control).
  **T2/T3 (long form) → OK (published), repeatedly — including the FULL HOGP service**
  (2A4B report map, 2A4D notify + 0x2908, 2A4E, 2A4A). The block is SHORT-FORM-ONLY on 15.8.8.
- **Live central event**: `SUBSCRIBED 00002A4D… by <CBCentral identifier 38BA17A2-…, MTU = 524>`
  multiple times (+2 UNSUBSCRIBED) — a real peer connected and enabled input-report
  notifications (HID-host GATT flow). Identity of that central: UNKNOWN from log.
- Next (no reinstall needed): B-side pairing test per docs/08 T-E21 — if the central was
  iPhone B and B exposes it as a gamepad → H-E21c → BLE track REOPENED as primary route.
- Cosmetic (queued for the ControllerA v0.4.0 merge, not for a standalone reinstall):
  log UITextView zero height (user couldn't see lines live; copy still worked);
  "full HOGP service is live" also printed after T2 (svc-only) — wording only.


## E21b (2026-09-27): central-side visibility — Android YES, iPhone NO

- Android scan: **FOUND ProbeBLE** → peripheral advertise + long-form publish work end-to-end.
- iPhone 11 (same iCloud as A): **not listed** in Bluetooth settings.
- Matches X4 exactly (Apple central ignores generic 0x1812 advertisers; Android/Windows see them).
- H-E21e (same-iCloud/Continuity hiding): UNLIKELY (X4 lacked any account factor;
  Continuity affects Handoff-type features, not the base pairing list) — disprove cheaply:
  scan with any iPhone signed into a DIFFERENT Apple ID (no installs, Settings only).
- Attribution correction: previous log's SUBSCRIBED events (MTU 524) were most likely the
  Android scanner app exploring/subscribing, NOT an Apple HID host.
- Consequence if Apple-central filter confirmed on iOS 27: BLE-HID cannot reach iPhone B
  (H-E21c dead, H-E21d moot) → G-track (classic-BT DS4 emulation via chip-level HCI)
  becomes THE path for iOS targets; the BLE route still serves Android/PC hosts.
- One lever remains before concluding: if Android nRF shows our ADV **without** 16-bit
  0x1812 / gamepad appearance 0x03C4, the fix is advertisement shaping, not filtering.
  Ask scanner to report AD contents (T-E21a).


## E21c (2026-09-27): Android classifies ProbeBLE as a PHONE → track verdict

User tested T3+T5 with Android scanning: name changes to "ProbeBLE" but the device
type stays "phone". Cause: CB peripheral API cannot set AD Appearance (0x03C4),
cannot put the compact 16-bit 0x1812 into the ADV packet (long-form goes out as
128-bit scan-response data), cannot set Class of Device. Peers default-classify.

### FINAL VERDICT for the BLE public-API track (three measured layers)
| Layer | Result | Evidence |
|---|---|---|
| Short-form 0x1812 publish | BLOCKED (CBError 8) | E20 (device), E21 control |
| Long-form 0x1812 publish | WORKS (full HOGP live) | E21 (device) |
| Apple-central visibility | BLIND (filter) | E21b + X4 |
| Input-device identity for peers | IMPOSSIBLE via public API (no Appearance/16-bit/CoD) | E21c |
=> **BLE public-API = PROVEN INSUFFICIENT for controller identity. Track CLOSED
(final).** It remains usable for custom-GATT data channels only.
The missing controls (raw ADV bytes, Appearance, CoD, SDP/HID identity) are exactly
what the chip-level HCI track (docs/12 G1–G5) provides — that is now THE path for
iPhone B, with the BLE-HOGP code kept as a working Android/PC option via the same
ds4bridge host stack.
