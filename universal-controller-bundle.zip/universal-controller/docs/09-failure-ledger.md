# 09 — Failure Ledger (rules 11, 14, 23)

Every method attempted or evaluated, with the required 6-line record.

## 9.1 Evaluated-and-blocked (external evidence, on-device re-verification pending T3)

### METHOD: CoreBluetooth BLE HID peripheral (publish 0x1812 via CBPeripheralManager)
FAILED METHOD: iOS app publishing HID-over-GATT service (0x1812 + 2A4A/2A4B/2A4D/2A4E)
EXACT FAILURE: `CBErrorDomain Code=8 "The specified UUID is not allowed for this operation"` at addService
EVIDENCE: 4 independent sources (SO 20827028, Apple forums 725238, gist conath, SO 44579031) [E6]
HYPOTHESIS: Apple deliberately reserves HID peripheral role for the OS
CHANGE: none possible via public API → app ships an on-device probe (ControllerA "BLE") to re-verify on iOS 15.8.8
NEXT TEST: T3 (run probe on A; if NOT blocked → architecture pivot, record immediately)

### METHOD: Present as generic BLE HID gamepad (any transport)
FAILED METHOD: generic HID-over-GATT gamepad identity
EXACT FAILURE: pairs on iOS/macOS but never appears in GameController.framework
EVIDENCE: developer report incl. descriptors copied from supported controllers [E5]
HYPOTHESIS: iOS matches specific controller identities only
CHANGE: only device-specific identities are pursued (DS4-shaped, Joy-Con-shaped)
NEXT TEST: T4/T5 control experiments

### METHOD: Wi-Fi / network controller transport
FAILED METHOD: send input to B over Wi-Fi
EXACT FAILURE: stock iOS exposes no network controller ingress to GameController
EVIDENCE: GameController API surface (public docs); receiver app would be needed on B
HYPOTHESIS: —
CHANGE: REJECT ARCHITECTURE (rule 10: would require software on B)
NEXT TEST: none — closed by constraint, not by experiment

## 9.2 Attempted during this build session (sandbox, real)

### BUILD: theos installer non-interactive
FAILED METHOD: `install-theos` in non-TTY sandbox
EXACT FAILURE: toolchain step requires interactive Swift/no-Swift prompt; nothing installed
EVIDENCE: installer output stopped after "A toolchain does not appear to be installed"
HYPOTHESIS: `read -p` fails with closed stdin
CHANGE: manual install — L1ghtmann/llvm iOSToolchain tarball + theos/sdks clone + Procursus ldid
NEXT TEST: direct cross-compile (PASSED)

### BUILD: clang-11 + iPhoneOS16.5.sdk
FAILED METHOD: compile with sdk 16.5
EXACT FAILURE: `SDKSettings.json could not be parsed` promoted to error (-Werror,-Wdarwin-sdk-settings)
EVIDENCE: compile log
HYPOTHESIS: clang-11 can't parse newer SDKSettings.json
CHANGE: switched to iPhoneOS14.5.sdk (deployment target stays iOS 15.0)
NEXT TEST: rebuild (PASSED — minos 15.0 confirmed in Mach-O)

### BUILD: idiag.m first compile
FAILED METHOD: plain C-string literals as NSString format args + missing io_name_t typedef + wrong IOKit fn signature
EXACT FAILURE: 20+ ObjC compile errors
EVIDENCE: compile log
HYPOTHESIS: —
CHANGE: P() macro + @"" literals, added typedef, fixed CFProperties signature
NEXT TEST: rebuild (PASSED)

### BUILD: ds4bridge SDP builder/parser
FAILED METHOD: first SDP implementation (single combined HID+PnP record; wrong element-size table; DES treated as invalid type; TEXT length form)
EXACT FAILURE: 5 unit tests failed (record validation, attr lookup, VendorID)
EVIDENCE: test log (retained in git history of this session)
HYPOTHESIS: real controllers expose TWO SDP records; SDP size-index map is 0=1B..4=16B,5=+1Bl,6=+2Bl,7=+4Bl; TEXT-2-byte-len = 0x26
CHANGE: split HID + PnP records; fixed elem_size; 0x26 for len16 TEXT
NEXT TEST: tests (PASSED — 41/41)

### BUILD: ds4 report 0x11 layout
FAILED METHOD: LX at byte[3] (memory-based layout)
EXACT FAILURE: contradicted public RE docs
EVIDENCE: GIMX wiki + dsremap ("report ID 0x11 followed by 0xC0 0x00; offsets shift") [E9, E10a]
CHANGE: relayout to [0]=0x11 [1]=flags [2]=0x00 [3]=counter [4..7]=sticks
NEXT TEST: tests re-aligned (PASSED); live capture verification still pending (Phase-3)

### BUILD: ds4bridged deb packaging
FAILED METHOD: `ds4bridged_INSTALL_PATH = usr/bin` (relative path) + split `make -j2` / `make package`
EXACT FAILURE: deb contained only "./" — binary staged to `.theos/_usr/bin` outside the rootless layout
EVIDENCE: dpkg-deb -c output (728-byte deb, no payload)
HYPOTHESIS: relative INSTALL_PATH breaks rootless staging; stage/package split mismatch
CHANGE: removed INSTALL_PATH (default /usr/bin, staged to /var/jb/usr/bin), single `make package`
NEXT TEST: rebuild → deb contains /var/jb/usr/bin/ds4bridged (69 KB arm64) (PASSED)

### BUILD/TEST: SDP responder + HOGP + ds4lab (session 2)
FAILED METHOD: first SDP-server request parse
EXACT FAILURE: error PDU 0x0003 on valid request — des_payload accepted only 0x36 (2-byte-len DES) while phones send 0x35 (1-byte-len); elem_parse returned payload without element start so AttributeIDList ranges were parsed from the wrong offset
EVIDENCE: unit-test failure log + /tmp debug harness output
HYPOTHESIS: strict byte-level tests catch wire-level mistakes cheaply (they did: 4 distinct defects found)
CHANGE: accept 0x35/0x36, expose element start, rewrite continuation test to rebuild the request each round and check rsp[n-1] before reading the cont bytes
NEXT TEST: full suite → 54/54 PASS (artifacts/logs/ds4bridge-unit-tests.txt)

### METHOD: ds4lab runtime validation in sandbox
FAILED METHOD: run ds4lab end-to-end in the build sandbox
EXACT FAILURE: sandbox has no Bluetooth adapter — binary builds and links (-lbluetooth) but cannot open L2CAP sockets
EVIDENCE: sandbox environment inspection
HYPOTHESIS: —
CHANGE: labeled NOT TESTED; execution deferred to a PC with a BT dongle (docs/12 G-B1)
NEXT TEST: G-B1 on real hardware

## 9.25 ON-DEVICE findings (first real-device round — iPhone A, iOS 15.8.8)

### METHOD: ControllerA v0.2.0 BLE probe (T3, probe 1 = CBPeripheralManager + HID 0x1812)
FAILED METHOD: create CBPeripheralManager in a TrollStore-permasigned app and wait for poweredOn, then publish 0x1812
EXACT FAILURE: state stayed Unknown(0) forever (no didUpdateState callback), NO Bluetooth permission prompt ever shown; app crashed back to SpringBoard seconds later — while the UDP loop kept ticking (main runloop healthy)
EVIDENCE: ON-DEVICE — user screen recording + screenshots (archived artifacts/evidence/T3-probe1-state0-stuck.jpeg, T3-udp-popup.PNG). NOTE: addService(0x1812) was NEVER called (gated on poweredOn) ⇒ the crash is downstream of the stuck daemon/XPC handshake, NOT our HID descriptor
HYPOTHESIS: H1 bluetoothd/TCC cannot resolve the TrollStore-permasigned app identity (prompt never shown, state never resolves) > H2 jailbreak TCC/tweak interference > H3 usage keys invisible to daemon (disfavored: keys ARE in the IPA; missing keys crash at init on stock iOS, not hang) ; crash mechanism needs .ips
CHANGE: probe v2 shipped (0.3.0): CBManager.authorization pre-init, CBCentralManager cross-check, 6 s stuck-watchdog with verdict, @try guards, in-app crash journal; idiag v0.4 adds `-c` (.ips collector) and `-p` (BT permission storage audit)
NEXT TEST: install 0.3.0 → tap BLE → send v2 log lines + `idiag -c` output

### BUG (fixed): status label showed raw "uds: %@"
FAILED METHOD: `self.stats.text = @"uds: %@ · dpad/13btn · 120Hz";`
EXACT FAILURE: literal string assigned; %@ never formatted (confirmed in device screenshot)
EVIDENCE: ON-DEVICE screenshot T3-probe1-state0-stuck.jpeg (bottom line)
HYPOTHESIS: —
CHANGE: format with real UDS path via +[UDSTransport socketPath] (shipped in 0.3.0)
NEXT TEST: verified in next install

### BUG (fixed): v1 crash left no trace in-app
CHANGE: main.m now installs NSUncaughtExceptionHandler + SIGABRT/SEGV/BUS/ILL/TRAP handlers writing Documents/ControllerA-crash.txt, then re-raises so the system still produces the standard .ips
NEXT TEST: if 0.3.0 crashes, journal + .ips both exist

### RESOLVED: v1/v2 "state stuck + mid-air crash" — root cause found on device (E19)
FAILED METHOD: creating HID characteristics with cached initial values (2A4E Protocol Mode had value={1} AND WriteWithoutResponse permission)
EXACT FAILURE: NSInternalInconsistencyException "Characteristics with cached values must be read-only" thrown by CoreBluetooth inside addService — the exception fired when PM state reached poweredOn (~5-6 s after init on this device), which v1 showed as "stuck at 0 then crash"
EVIDENCE: ON-DEVICE v2 log (artifacts/evidence/E19-probe2-log.txt): auth=allowed(1), CM state→5, PM state→5, exception backtrace pointing at -[CBProbe addHIDService]
HYPOTHESIS: **H1/H2/H3 all DISPROVEN** — the daemon handshake and permissions work fine on this TrollStore/iOS 15.8.8 setup; the crash was OUR characteristic-creation bug; the "hang" was just slow (~5-6 s) state resolution
CHANGE: all five 0x1812 characteristics are now created with value:nil and served dynamically via didReceiveReadRequest (0.3.1); watchdog extended to 15 s; UI fix: buttons created with CGRectZero had zero cornerRadius/font (square unlabeled buttons) — geometry now follows layout in layoutSubviews; face buttons laid out as a proper diamond
NEXT TEST (decisive): v0.3.1 probe 1 will actually publish 0x1812 for the first time → either "ACCEPTED (E6 does not hold here — track reopened)" or "BLOCKED (matches E6)"

### METHOD: BLE HID-over-GATT via public API — DECISIVE on-device test (E20)
FAILED METHOD: CBPeripheralManager addService(0x1812) with 5 correct, non-cached characteristics under FULL entitlements (TrollStore permasigned + jailbroken iOS 15.8.8)
EXACT FAILURE: CBErrorDomain code=8 "The specified UUID is not allowed for this operation" — same error as all external reports
EVIDENCE: ON-DEVICE log v0.3.1 (artifacts/evidence/E20-probe-e6-confirmation.txt): authorization=allowed, PM poweredOn, publish attempted and refused
HYPOTHESIS: —
CHANGE: **track CLOSED as PROVEN BLOCKED at public-API level** (rule 12 satisfied: on-device attempt + error code + E6 corroboration). The block is in CoreBluetooth's UUID allow-list — entitlements do not bypass it. Chip-level HCI tracks (G2–G5, G-B1, G-B2) unaffected — the radio is not involved in this block.
NEXT TEST: probe 2 advertising visibility check on iPhone B (secondary evidence); then docs/12 G1/G2 (idiag v0.4 audit + BlueTool HCI smoke test)

### BUG (fixed): probe printed "ACCEPTED" in the BLOCKED branch
FAILED METHOD: v0.3.1 messaging patch put the wrong result string in the error branch
EXACT FAILURE: log showed "RESULT PROBE 1: 0x1812 ACCEPTED..." directly under "didAddService 1812 FAILED (code=8)"
EVIDENCE: user-submitted log (E20)
HYPOTHESIS: —
CHANGE: v0.3.2 — error branch prints BLOCKED+E6-confirmed; success branch prints ACCEPTED+reopened
NEXT TEST: verified next run

## 9.3 Open failures (not yet resolved — carried into Phase-3 gate)

- BT Classic HID *device role* on iPhone A: NOT TESTED (needs idiag chip id + HCI access experiments) — transport prior art strengthened by E14–E16 (internalblued/BlueTool/Frankenstein).
- iOS 15.8.8 BlueTool/`/dev/uart.bluetooth` surface: NOT TESTED (idiag v0.4 + docs/12 G1/G2).
- CoreBluetooth peripheral role on TrollStore/iOS 15.8.8: **FAILS ON DEVICE** (state stuck Unknown + crash) — v2 instrumentation shipped to discriminate H1/H2/H3; BLE public-API track unusable in this environment unless v2 shows a fixable cause.
- 49-byte CRC-disabled vs 78-byte CRC-enabled 0x11 form accepted by iOS: NOT TESTED.
- Joy-Con-shaped BLE identity (iOS 16+ supports Joy-Cons [E4]; shape details need captures): NOT TESTED.

## E21 (2026-09-27) — is the 0x1812 block short-form only? (reopen attempt)

- TRIGGER: user asked to "fix" the E20 block. Source review found E20 never tested the
  128-bit spelling of the same UUID; multiple external reports say modern iOS accepts it
  (Bluetouch App Store app, HemiPad 2026, gist comments 2024) while iOS 7/8 blocked both forms.
- METHOD: docs/13 E21 evidence file + ProbeBLE.ipa v0.1.0 (separate app; T1 short control /
  T2 long svc / T3 long full-HOGP / T4 short full / T5 advertise / T6 copy-log) +
  zero-install pre-test checklist (tools/ble-longform-zeroinstall-test.sh).
- STATUS: BUILD VERIFIED sandbox, **NOT RUN on device**. ControllerA v0.3.2 stays FINAL.
- DECISION RULES: T2/T3 refused -> E20 blanket verdict restored (H-E21b). T3 OK + B pairs +
  gamepad -> BLE track reopened (H-E21c). T3 OK but B blind -> central-side filter (X4),
  stay on G-track (H-E21d).

### E21 RESULT (2026-09-27, on device)
- EVIDENCE: artifacts/evidence/E21-probeble-log.txt. Short form = code=8 (control OK).
  Long form = PUBLISHED, full HOGP service live, repeatedly. H-E21a confirmed; H-E21b dead.
- UNEXPECTED: real central subscribed to 2A4D (MTU 524, id 38BA17A2-…) — HID-host flow
  already happened against A. Who it was → pending user answer (B-side test T-E21).
- Next: B pairs from stock Settings → is it a gamepad on B? → decides H-E21c vs H-E21d.

### E21c (2026-09-27, on device + Android instrument) — BLE public-API track CLOSED (final)
- EVIDENCE: Android sees ProbeBLE but classifies it as a phone (name-only change).
- ROOT CAUSE: CB API exposes only LocalName + UUIDs in ADV; Appearance/16-bit HID UUID/
  Class of Device are below the API -> no peer can classify us as an input device.
- CHANGE: track verdict finalized (see docs/13 table). Remaining paths to iPhone B:
  chip-level HCI (G-track, host stack 70/70 done) — pending G1 idiag + G2 BlueTool
  evidence. BLE-HOGP publish kept as Android/PC feature of the same host stack.

### G1 attempt 1 (2026-09-27): /var/jb ABSENT on iPhone A — premise check
- EVIDENCE: user Filza report — no /var/jb folder at all.
- HYPOTHESES: H-jb1 jb never actually installed (TrollStore-only so far); H-jb2 semi-tethered
  currently unjailed; H-jb3 rootful (no /var/jb but /.procursus). Device model UNKNOWN makes
  feasibility unknown (palera1n needs A8-A11; Dopamine caps 15.4.1).
- CHANGE: built idiagTS.ipa (TrollStore app, no jb needed) as the G1 instrument + model/jb-app
  questions to user. LaunchDaemon runbook parked until jb state clarified.
- NOTE: all prior device evidence came from TrollStore app runs — no jb-context execution
  has ever been observed on this device. Scoreboard premise "A jailbroken" = UNVERIFIED.

### idiagTS v0.1.0 black screen (2026-09-27) — RESOLVED, root cause from code
- SYMPTOM: app launches to a black stuck screen on device.
- ROOT CAUSE (certain, code inspection): main.m passed IDViewController (a VIEW CONTROLLER)
  as the 4th UIApplicationMain argument, which is the APP DELEGATE class. No
  didFinishLaunching -> no window created -> black screen (app alive, nothing shown).
  ProbeBLE worked because it passed PBAppDelegate. Signature UIKit-wiring mistake.
- FIX: added IDAppDelegate (window + rootViewController = IDViewController), main.m now
  references IDAppDelegate. v0.1.1 build 2, clean rebuild (stale-.theos packaging hazard
  also caught: package script now must run only after a verified fresh build).
- NEW PRE-PACKAGE QA RULE (both probe apps): (1) grep main.m for "[XAppDelegate class]";
  (2) grep the delegate .m for didFinishLaunchingWithOptions; (3) clean .theos before build;
  (4) verify the packaged binary contains the AppDelegate symbol.

### BTKit v0.1.0 instant crash (2026-09-27) — RESOLVED from code
- SYMPTOM: app bounced out immediately on launch.
- ROOT CAUSE (certain): viewDidLoad never initialized _btns (omission); the layout
  block later anchored the log to b[2] — with a nil array b[2] evaluated to nil and
  activating a constraint with a nil anchor threw NSInvalidArgumentException during
  the first layout pass. ProbeBLE/idiagTS initialize the array, which is why they launch.
- FIX in v0.1.1 build 2: array created; layout rewritten per-button (no blind indexing);
  PLUS automatic crash capture (NSSetUncaughtExceptionHandler -> /var/mobile/Documents/
  btkit-crash.txt, displayed in-app on next launch) so any future crash self-reports
  with zero typing.
- NEW QA RULE (probe/button apps): (1) delegate wiring greps; (2) all ivar collections
  initialized before first use — grep the init line exists; (3) no bare arr[i] in
  constraint blocks.

### BTKit v0.1.1 all-buttons exit 32512 (2026-09-27) — root-caused, v0.1.2 rewritten spawn
- EVIDENCE: every button -> "[exit 32512]" (=127<<8, shell "command not found"), NO helper
  output at all. popen captured only stdout, so the shell's stderr explanation was lost
  (my plumbing flaw — diagnosis impossible from that log).
- FIX (v0.1.2 build 3): shell removed from the entire chain. App: fork + pipe(1+2 merged)
  + execve(helper) directly; on exec failure the child writes "EXEC_FAIL errno=<n> (<str>)"
  into the pipe before _exit -> exact reason visible in the app log. 120s timeout kill.
  Helper: internal launchctl calls also converted to fork/execv (no popen anywhere).
- Host test of the spawn pattern: real-exec path + EXEC_FAIL/127 path both PASS.
- Interpretation table for next run: EXEC_FAIL 1/13 (EPERM/EACCES) -> setuid/AMFI trust
  issue -> fallback = typed terminal commands (proven working in G1.6 round 2);
  2 ENOENT -> path/install issue; works -> proceed.

### BTKit v0.1.4 device run (2026-09-27): ROOT ACHIEVED; argv-splitting bug found -> v0.1.5
- EVIDENCE: "bthelper v0.2.0 (euid=0 uid=0)" — sudo path works, user is root inside helper.
  All launchctl calls then failed: "Unrecognized subcommand: bootout system/com.apple.bluetoothd"
  — my helper passed the whole "bootout system/X" as ONE argv item (shell had been splitting
  it when typed manually). Same for "bootstrap system <plist>".
- FIX v0.1.5 build 6 / helper v0.2.1: run_argv() with properly split argv arrays
  {launchctl, bootout, system/<label>} and {launchctl, bootstrap, system, <plist>}.
- NOTE: daemons were running again this round (device rebooted/userspace-rebooted since
  round 2) — bootout must succeed this time for the port to open.

### BTKit v0.1.5 run (2026-09-27): argv fixed; launchd labels miss the holder -> v0.1.6 process kill
- EVIDENCE: bootouts accepted (no "unrecognized") but BOTH returned "Boot-out failed: 3: No
  such process" while port STILL EBUSY -> the processes holding the UART are not currently
  registered in launchd under those labels (survived from an earlier boot context).
- FIX v0.1.6 build 7 / helper v0.2.2: after bootout attempts, enumerate ALL processes via
  sysctl(KERN_PROC_ALL), match names containing "bluet" (case-insensitive), SIGTERM then
  SIGKILL survivors, then port test. Deterministic — does not depend on launchd bookkeeping.
- Note: helper v0.2.2 banner + port test visible in STOP output; SWEEP unchanged.

### BTKit v0.1.6 run (2026-09-27): killed BlueTool(9197) — port still EBUSY -> v0.1.7
- EVIDENCE: process pass worked (kill(9197, TERM) <- BlueTool), no "bluet"-survivors in
  pass 2, but open() still EBUSY -> second holder exists whose name lacks "bluet".
  Prime suspect: "blued" (iOS BT daemon name — has no 't'; our filter missed it; idiag
  round 1 already probed for blued).
- FIX v0.1.7 build 8 / helper v0.2.3: filter broadened to "blue" (catches blued/
  bluetoothd/BlueTool/BluetoothUIService); if port STILL busy after kills, dump the
  ENTIRE process list (pid + name) into the log — nothing can hide after that.

### BTKit v0.1.7 run (2026-09-27): SMOKING GUN — stuck btiotest from terminal holds the UART
- Full process dump (new v0.1.7 feature) exposed: **8784 btiotest** (+ parent sudos
  8782/8783) alive since the terminal round — v0.1.0's drain loop never exits when the
  chip streams events -> IT has been the EBUSY holder all along after BlueTool died.
  Also killed this round: BlueTool(9326) + FindMyDeviceBlue(9233) — new BT process family.
- Other BT-adjacent holders in dump: BTLEServer(7511), WirelessRadioManagerd(7390,
  p_comm truncated "WirelessRadioMan"), findmydeviced(7470)/fmfd(7569)/nearbyd/rapportd.
- FIX v0.1.8 build 9 / helper v0.2.4: tiered kill — tier1 {blue*, btiotest}, port test,
  tier2 {btleserver, wirelessradioman, findmydeviced, fmfd, nearbyd, rapportd}, port test,
  full dump only if STILL busy. All tier-2 processes restart on Userspace Reboot.

### BTKit v0.1.8 run (2026-09-27): FIRST full bootout SUCCESS; all known holders dead; STILL EBUSY
- EVIDENCE: no "Boot-out failed" lines (first time ever — restored daemons registered
  properly); tier1 killed bluetoothd(9461) + BlueTool(9463) + FindMyDeviceBlue(9465);
  btiotest 8784 already gone (died externally, likely user's NewTerm kill); dump shows
  BTLEServer/nearbyd/fmfd collapsed with bluetoothd; tier2 killed findmydeviced/rapportd/
  WirelessRadioMan — rapportd+WRMd RESPAWNED within ~1 s (KILL pass caught 9474/9473).
  Port STILL EBUSY with zero known userland holders alive.
- INTERPRETATION (labeled hypothesis, evidence-based): (a) fast respawner grabs port
  between kill and test, or (b) driver-level stale latch — round 2 (the only success)
  ALWAYS had airplane mode ON (clean radio-down) before killing; recent rounds kill
  cold. Airplane toggle = discriminator.
- FIX v0.1.9 build 10 / helper v0.2.5: STOP now ends with 4 auto-probes (SIGKILL tier2
  respawners -> 3 s -> open test, logging each); if all fail prints airplane-mode cure
  instruction. App intro now shows "TIP: Airplane Mode ON first (round-2 proven recipe)".

- SDK fix: libproc.h + sys/proc_info.h BOTH absent in iPhoneOS14.5 SDK tarball ->
  inlined ABI-stable minimal defs (vinfo_stat/vnode_fdinfo/proc_fdinfo + extern
  proc_pidinfo/proc_pidfdinfo) and added lsof SELF-TEST (must find its own /dev/null
  fd first, else prints SELFTEST FAILED and skips reports). Build green, packaged.

### SSH track moved to press-only BTKit v0.1.11 build 12 / helper v0.2.7 (user: "no typing")
- Button 4 SSH KEY: checks sshd + ssh client, appends agent PUBKEY (ed25519, public
  material) to /var/root/.ssh + /var/mobile/.ssh authorized_keys (0700/0600, mobile
  chowned), self-tests root@localhost BatchMode -> ROOT-SSH-OK.
- Button 5 BRIDGE: kills stale p_comm=="ssh" clients, spawns DETACHED
  `ssh -p 443 -R0:localhost:22 tcp@a.pinggy.io` (pinggy free tcp, no account, ~60 min),
  logs -> /var/mobile/Documents/pinggy-bridge.txt, sleeps 12 s, cats log so the
  tcp://...pinggy.io:NNNN address lands in the app log -> user COPY LOG.
- Unknown-mode now prints STALE HELPER hint (fixed copy /var/jb/usr/bin/bthelper older).
- Password still typed ONLY in the app field. No terminal typing required at all.

### v0.1.11 device run: keys installed OK but ssh "NOT FOUND" — jb-path bug -> v0.1.12 build 13 / helper v0.2.8
- RCA: helper checked ONLY stock paths (/usr/bin/ssh, /usr/sbin/sshd); Dopamine/Procursus
  puts packages under /var/jb (/var/jb/usr/bin/ssh) — same lesson as launchctl=/var/jb/bin.
  User's apt install DID succeed.
- FIX v0.2.8: find_first() over {jb, stock} for ssh + sshd, prints the found path; sshkey
  self-test uses found ssh; if sshd present but self-test failed -> launchctl kickstart -k
  system/com.openssh.sshd via /var/jb/bin/launchctl then retry; bridge execs found ssh and
  prints the apt fallback line if absent.

### v0.1.12 run: bridge UP (tcp://...:35893) but sshd denies our pubkey -> v0.1.13 build 14 / helper v0.2.9
- EVIDENCE: sshd answers (Permission denied, not refused) after kickstart -> server alive,
  key present (installed OK) -> auth POLICY blocks key. Suspects: PermitRootLogin /
  AuthorizedKeysFile override in Procursus sshd_config. NOTE: OpenSSH uses FIRST directive
  occurrence -> appending would be useless.
- FIX v0.2.9: NEW helper mode sshfix + button 6 SSH FIX: greps current rules (evidence),
  backs up config once (.btkit.bak), rewrites with directives PREPENDED
  (PermitRootLogin prohibit-password / PubkeyAuthentication yes /
  AuthorizedKeysFile .ssh/authorized_keys) while commenting out conflicts, fixes perms,
  kickstart -k sshd, retests root@ + mobile@. Button 4 now ends with hint to press 6.

### v0.1.13 run: config rewritten but root+mobile BOTH still denied; TUNNEL CHAIN PROVEN
- AGENT-SIDE EVIDENCE (2026-09-27): ssh from agent sandbox through pinggy
  (fockh-...:44975) reached the phone's sshd -> full chain works, only key auth blocked.
- Oddity: the grep-evidence line produced NO output in round 14 -> the config sshd
  actually reads may not be the file we fixed (-f in plist?) or grep missing.
- FIX v0.1.14 build 15 / helper v0.2.10 (sshfix v2): prints plist + config BEFORE state
  (pure C, no external grep), fixes BOTH sshd_config paths, adds "UsePAM no" (first-wins
  prepend), hard restart (kickstart -k -> kill_by_name sshd -> kickstart), then
  SERVER-SIDE interrogation: sshd -d -p 2222 -E debugfile + one test connection ->
  dumps the exact rejection reason into the app log. No more guessing.
- USER SAFETY RULES (standing, user-set 2026-09-27): agent must NOT access personal
  data (photos/videos/messages), must not exfiltrate data, must not break the device;
  only BT diagnostics + ssh config + BTKit logs; every change backed up/reversible;
  key removed at session end.

### v0.1.14 run: INTERROGATION COLLIDED — port 2222 already occupied by unknown listener
- EVIDENCE: "Bind to port 2222 failed: Address already in use. Cannot bind any address."
  -> the 2222 self-test was answered by a MYSTERY listener, not our debug sshd. Config
  confirmed correct on disk (BEFORE head shows #btkit-sshfix v1 rules at top) yet :22
  still denies both root+mobile. Plist confirmed: launchd socket-activated wrapper
  (sshd-keygen-wrapper -i, label com.openssh.sshd).
- FIX v0.1.15 build 16 / helper v0.2.11 (sshfix v3): netstat -anv listener dump (if
  present) to expose the 2222 owner; authorized_keys integrity print; config rewrite +
  AFTER head; hard restart; selftests :22; interrogation MOVED to fresh port 2022 with
  command-line overrides PermitRootLogin=yes StrictModes=no UsePAM=no
  AuthorizedKeysFile=/var/root/.ssh/authorized_keys -> if DEBUG-ROOT-SSH-OK then the
  problem is :22-path config only; else the confession names the reason.

### v0.1.15 run: AGENT KEY OFFERED AND REFUSED -> launchd-sshd confinement suspected -> v0.1.16 build 17 / helper v0.2.12
- AGENT-SIDE VERBOSE PROOF: "Offering public key ... SHA256:Z1J0..." (exact pair of the
  on-device authorized_keys line) -> server answers "Authentications that can continue"
  = REFUSED. Meanwhile phone-local ssh has NO private key to offer (none-only + close,
  seen in 2022 interrogation) -> localhost self-tests were untestable by design.
  Test-design flaw acknowledged; agent key + tunnel are the only meaningful probes.
- FIX v4: button 6 now (1) dumps tail of /var/mobile/Documents/sshd-run.log (= confession
  of the PREVIOUS agent attempt), (2) bootout com.openssh.sshd + kill all sshd,
  (3) spawns OUR OWN sshd daemon on :22 with flags PermitRootLogin=prohibit-password,
  PubkeyAuth=yes, AuthorizedKeysFile=/var/root/.ssh/authorized_keys, StrictModes=no,
  UsePAM=no, -E sshd-run.log, (4) phone-local control: ssh-keygen test_key + append +
  ssh -i test_key -> LOCAL-KEY-SSH-OK proves our daemon accepts valid keys end-to-end.
  Loop: press 6 -> 5 -> agent tries -> if refused press 6 again (tail shows confession).

### SESSION 2026-09-27 07:30-09:00 — SSH BREAKTHROUGH + UART TRUTHS (all device-verified via agent SSH root)
- SSH chain WORKS: agent key (ed25519) + our own sshd daemon on :22 (flags
  PermitRootLogin=prohibit-password, PubkeyAuth=yes, AKF=/var/root/.ssh/authorized_keys,
  StrictModes=no, UsePAM=no) + pinggy bridge (button 5) = full root from sandbox.
  launchd's sshd refused valid keys (context) -> replacing it was the fix. Key perms on
  sandbox must be 600 (workspace snapshot resets them each turn -> chmod 600 before use).
- ON-DEVICE EXEC LESSON (corrects earlier note): bins in /var/root signed PLAIN adhoc
  (-S) are SIGKILLed (137, no crash report); MUST ldid -S<ent.plist>
  (platform-application/no-container/no-sandbox). v1.0 uartprobe success WAS ent-signed.
- BUILD LESSON: stale .theos with arm64e objects poisons links ("incompatible arm64e
  ABI" warning = poison). Clean-room rebuild (fresh dir + ARCHS=arm64) fixed a binary
  that never ran despite identical LC structure. rm -rf .theos before every deploy build.
- DEVICE TOOLS: /var/root/{uartprobe(up2 clone),up2,up3,regdump,hello2}; regdump = IOKit
  registry walker (dlsym-only) — works great.
- UART ARCHITECTURE (D101AP/iPhone7): BT chip on arm-io/uart1/AppleSamsungSerial/
  bluetooth; /dev/{uart,cu,tty}.bluetooth — uart.* (18,2) vs cu.* (9,5) DIFFERENT nodes
  but driver enforces EXCLUSIVE binding across nodes (open EBUSY). Idle chip = baud 19200,
  CTS=0 (powered down when port closed!). BlueTool bring-up raises baud (observed up to
  4M; earlier full bring-up hit 6M) — firmware+calibration data (bluetooth-taurus-
  calibration 1064B) live in registry. THE EBUSY MYSTERY = driver exclusivity; chip
  silence = power-off when unheld. Power enable = GPIO function-power_enable on uart1.
- BRING-UP LOOP OBSERVED: 19200 -> 115200 -> 4M -> back to 19200 cycle while BT enable
  was attempted with our wrapper label games (root cause TBD: MachServices/XPC confusion).
  BT Settings switch spun forever during experiment (also battery at 1% — iOS blocks
  radio at critical battery).
- LAUNCHD LESSONS: disable persists across bootout (must enable to re-bootstrap);
  Dopamine launchd rejects unsigned-for-it bins as daemon programs (exit 78 EX_CONFIG)
  -> use /var/jb/bin/sh -c 'exec ...' as ProgramArguments (sh is trusted). Duplicate
  MachServices (our label + stock label same name) causes XPC routing chaos.
- ps: comm= prints FULL argv (self-kill trap in grep loops!); ucomm= is short name.
  awk/pkill absent on device. bootout+kill -9 stock pair can leave a respawned copy ->
  verify with ps after.
- RESTORATION DONE (device back to stock): watchdogs killed, com.research.btup label
  bootout + plist deleted, stock BlueTool/bluetoothd enabled+bootstrapped, fresh
  bluetoothd running, baud idle 19200. Our sshd still on :22 (agent door kept).
  Stock pair will respawn on demand when BT is switched on (with charged battery).

### USER-REQUESTED TRANSPARENCY (2026-09-27): agent CCTV — BTKit v0.1.17 build 18 / helper v0.2.13
- User wants to see EVERYTHING the agent does on the device, live, to verify no misuse.
- Button 6 now writes /var/root/agentwrap.sh (command+output logger, 300KB rotating to
  120KB tail) and starts our sshd with -o ForceCommand=/var/root/agentwrap.sh -> EVERY
  agent one-shot command and its full output land in
  /var/mobile/Documents/agent-activity.log (readable via Filza live, or button 7).
- Button 7 AGENT LOG = helper mode agentlog (prints 9KB tail into the app log).
- Honest limitation: interactive shell keystrokes are not per-line logged ((interactive
  shell) marker only); the agent operates exclusively via one-shot commands, which are
  fully logged with output. ls of /var/root tools is static, non-invasive.
- NOTE: stock-Label-impersonation lesson encoded — our wrapper plist must NEVER reuse
  com.apple.* labels (the leftover btup label stealing com.apple.BlueTool caused the
  BT spinner; fixed by bootout of the impersonating label + re-bootstrap stock).

### 🏆 SESSION 2026-09-27 09:30-10:30 — CHIP SPOKE: BCM4355C0 IDENTIFIED VIA REMOTE BLUETOOL (G1.6 chip-reply MILESTONE CAPTURED)
- Path that worked: up4 (fifo remote-control wrapper) -> real BlueTool REPL -> chip.
  BlueTool menu discovered: device/power/reset/wake/autobaud/hci/bcm.
  Sequence: device -D ("Opening com.apple.uart.bluetooth @ 115200") -> power on -> wake on
  -> reset pulse (earlier peace.sh run) -> [patient feeds] -> "Issued HCI Reset" ->
  hci info: Manufacturer Broadcom, HCI 4.2, LMP Subversion 0x6103 ->
  **hci localName: "BCM4355C0"** (chip self-identified! idiag's BCM4350/4345C1-class
  guess refined: actual = BCM4355C0). BDAddr placeholder aa:aa:aa:aa:aa:aa (pre-HCD).
- INFRA lessons (blood): grep -x never matched (ps pads ucomm with spaces) -> all my
  kill loops were no-ops for hours -> use `while read p u rest; case $u in ...)`;
  awk/pkill absent on device; /tmp does not persist (ent plist vanished); step2 retry
  logic was killing our own wrapper on silent-success feeds; stale .theos poisons
  binaries (arm64e); up4 v2 = write(2) logging (stdio freopen mystery bypassed);
  first feed after BlueTool spawn is LOST (>3s init) — wait 8s or feed twice;
  child stdout MUST dup2 to log or replies go to /dev/null (nohup).
- btup plist had Label com.apple.BlueTool (impersonation) causing respawn zombie +
  BT-toggle spinner; exorcised: bootout both labels, fresh plist Label com.research.btup
  exec up4, MachServices com.apple.BlueTool (we answer XPC as BlueTool now).
- NEXT (G3 closure): bcm -W (load default HCD firmware) -> hci reset verify -> bcm -b
  (fast baud) -> SEIZE (kill BlueTool; up4 opens port itself) -> direct-transport probe
  at firmware baud -> wire hci_io_uart into ds4bridged 0.3.0.
- USER GOAL restated: iPhone A = wireless game controller for iPhone B (stock iOS 27).

### SESSION-2 2026-09-27 10:40-11:20 — FIRMWARE LOADED, CHIP FULLY IDENTIFIED, DIRECT-PATH VERDICT
- bcm -W (default HCD) SUCCEEDED: localName became "BCM4355C0 Elsa MUR MCC"
  (Elsa = iPhone7 BT module codename), HCI Rev 0x0010 -> 0x1D15 (RAM FW running),
  BDAddr aa:aa.. -> 43:55:c0:00:1f:ac (chip-derived).
- bcm -b 3000000 raised chip to fast baud (registry showed 230400 then 6000000 across
  runs); hci reset STILL ANSWERED at fast baud via BlueTool.
- SEIZE worked mechanically every time (kill BlueTool -> up4 opens uart.* in ms, CTS=1 =
  chip power persists). BUT direct reads silent because:
  **VERDICT: this driver exposes NO working BSD termios layer to userland**
  (tcgetattr OK but fake; IOSSIOSPEED -> ENOTTY; TIOCMSET -> EINVAL even on cu.*;
  uart.* AND cu.* both stubbed). Apple gates real UART control behind IOKit user
  clients — exactly what BlueTool uses. Conclusion: raw-fd transport (hci_io_uart as
  designed) CANNOT configure baud via BSD ioctls on this device. 
- NEW ARCHITECTURE (decided): pipe HCI through BlueTool itself — up4 fifo -> REPL:
  "hci cmd <bytes>" = arbitrary HCI TX; chip replies print to stdout (captured).
  "spam" exists for raw UART streaming (help pending). ds4bridged 0.3.0 will speak via
  this pipe (control-plane OK; stream-plane to be benchmarked via spam).
- CHIP POWER-STATE LESSON: chip answers only in certain power windows (after stock-stack
  activity or fresh power on/wake/reset pulse + autobaud dance). Silent-state recovery
  recipe still being tuned (autobaud produced no reset lines in final sleepy state).
- INFRA: launchd respawns jobs holding MachServices whenever clients (bluetoothd) poke
  them -> for stable manual sessions bootout BOTH bluetoothd and the job; /tmp resets
  every sandbox refresh (always re-create ent plist); stale .theos poisons AGAIN (up5
  137) -> clean-room rebuild fixed (STANDING RULE: fresh dir per tool build).
- STATE ON DEVICE: bluetoothd+btup labels bootout'ed (stock BT toggle will need
  re-bootstrap or reboot); up4+up5+up2+regdump parked in /var/root; agent key + our
  sshd on :22; airplane mode ON (user parked); authorized_keys has dup lines (harmless).

### SESSION-3 2026-09-27 15:00-15:30 — REBOOT ERA: GOLDEN WINDOW CONFIRMED + SYSTEM MAP COMPLETE + STRATEGIC PIVOT
- After clean reboot + re-JB: chip boot-staged at FULL FIRMWARE 6000000 baud by stock
  stack (BT enabled persisted). GOLDEN WINDOW at 09:50 was exactly this state; replicated.
- EBUSY VERDICT FINAL: with BT enabled + healthy bluetoothd, the UART is held by the
  stack itself (BlueTool `device -D` -> "Unable to open device / returned 3" even after
  evicting stock BlueTool). All BlueTool commands (incl. `aci -h` features) are
  UART-bound. => Raw-HCI (G3 direct) only possible when stack is down/BT off;
  coexistence = ride the stack instead.
- 14:50 self-inflicted loss: kickstart bluetoothd demoted chip 6M->ROM(19200); lesson:
  kickstart bluetoothd = chip power-cycle. Never kickstart while holding a session plan.
- Control-Center BT toggle WORKS; Settings page toggle still spins (cosmetic, deprioritized).
- SYSTEM MAP (regdump, T8010 /D101AP): power_enable = GPIO 0x58 (88), bt_wake = GPIO 0x21 (33),
  uart1 AppleSamsungSerial -> bluetooth (cu/tty/uart nodes), taurus-calibration blob
  1064 B "BLOBP..." embedded in DeviceTree (= aci -Q "MSF from ioreg"; no .hcd files on
  disk, /etc/bluetool absent on iOS — HCD name from bcm -v is virtual/generated).
- BlueTool `aci` unlocked: -F fw from /etc/bluetool (n/a on iOS), -c get ACL, -S accept
  any connection + change addr, -t/-s SCO routes, -U status (needs device open),
  -Q MSF from ioreg, -K regulatory HCD. `spam` segfaults if device not open.
- up4 one-shot trap: any BlueTool exit triggers SEIZE->EBUSY->die when stack healthy.
- PIVOT DECISION: controller deliverable (iPhone A -> iPhone B) now rides the HEALTHY
  stack: CoreBluetooth-based daemon (BLE HID-over-GATT gamepad; iOS 27 GCController
  accepts BLE HID controllers). Classic DS4 BR/EDR route stays documented (SDP records
  in docs/13) for when raw-HCI window exists. No more reboot dances needed from user.
