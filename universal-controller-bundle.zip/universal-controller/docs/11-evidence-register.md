# 11 — Evidence Register (rule 33-11)

Labels: EXTERNAL = public source, not our devices · LOCAL = produced in this project's build sandbox · ON-DEVICE = to be produced by the listed test (NOT RUN yet).

| ID | Evidence | Type | Supports |
|----|----------|------|----------|
| E1 | TrollStore README/wiki — supported iOS 14.0–16.6.1, 16.7RC, 17.0; CoreTrust multiple-signer bug; arbitrary entitlements; ldid pseudo-signing normal for TS | EXTERNAL | TrollStore usable on iOS 15.8.x; app artifact form |
|    | https://github.com/opa334/TrollStore · https://theapplewiki.com/wiki/TrollStore | | |
| E2 | palera1n docs/guides — A8–A11, iOS 15.0+, checkm8, semi-tethered, rootless/rootful, A11 passcode caveat; iClarified 2026 matrix ("iPhone 7/6s/SE latest jailbreakable 15.8.8") | EXTERNAL | A-side jailbreak environment candidates |
|    | https://docs.palera.in · https://www.iclarified.com/jailbreak · https://onejailbreak.com/blog/palera1n-jailbreak/palera1n-c-jailbreak/ | | |
| E3 | Apple Support "Connect a PlayStation wireless game controller" (updated 2026-09-14): DualShock 4 / DualSense / Edge / Access supported; BT pairing steps | EXTERNAL | DS4 identity remains valid target on current iOS (B-side behavior itself NOT VERIFIED) |
|    | https://support.apple.com/en-us/111100 | | |
| E4 | iOS 16 adds Nintendo Switch Joy-Con / Pro Controller support (Riley Testut demo; Apple eng. manager confirmation); Joy-Cons pair individually over BLE | EXTERNAL | Joy-Con-shaped BLE identity candidate |
|    | https://www.nintendolife.com/news/2022/06/apples-ios-16-update-supports-switch-joy-con-and-pro-controllers · https://www.nme.com/news/gaming-news/nintendo-switch-joy-con-and-pro-controller-support-coming-to-iphone-via-ios-16-3241733 | | |
| E5 | Apple dev forums #763679 — generic BLE HID gamepads (incl. descriptors cloned from supported controllers) pair but never appear in GameController.framework on iOS/macOS | EXTERNAL | generic-HID identity closed; identity-specific emulation required |
|    | https://developer.apple.com/forums/thread/763679 | | |
| E6 | iOS blocks publishing HID 0x1812 via CBPeripheralManager — CBErrorDomain Code=8; also blocked chars 2A4A/2A4B/2A4D/2A4E; Apple TSO confirmation "HID support intentionally reserved" | EXTERNAL | public-API BLE peripheral track PROVEN BLOCKED; on-device re-verification = T3 |
|    | https://stackoverflow.com/questions/20827028/create-ios-ble-hid-service · https://developer.apple.com/forums/thread/725238 · https://gist.github.com/conath/c606d95d58bbcb50e9715864eeeecf07 · https://stackoverflow.com/questions/44579031/ | | |
| E7 | InternalBlue (ACM AsiaCCS'19) — Broadcom/Cypress BT firmware patching framework; supported chips BCM4339/4358/4343/4345; iPhone 6 = BCM4345 in their device table | EXTERNAL | firmware-patch path plausibility on A8-era chips; chip-dependent |
|    | https://dl.acm.org/doi/pdf/10.1145/3307334.3326089 · https://arxiv.org/pdf/1905.00631 | | |
| E8 | ESP32 BT-Classic HID device implementations (StryderUK/BluetoothHID w/ DS4 example; ESP-IDF classic HID module); Bluepad32 (host-side) | EXTERNAL | HID device role implementable on capable BT controllers; no iPhone-side prior art found |
|    | https://github.com/StryderUK/BluetoothHID · https://gitlab.com/ricardoquesada/bluepad32 | | |
| E9 | GIMX DualShock 4 wiki — BT HID input reports, 0x11 layout (LX at [4]), output 0x11 | EXTERNAL | DS4 report layout used in ds4bridge |
|    | https://gimx.fr/wiki/index.php?title=DualShock_4 | | |
| E10a | dsremap docs — BT 0x11 = USB layout + 0xC0 0x00 header shift; GET_REPORT 0x02 (calibration) switches DS4 to 0x11-family reports | EXTERNAL | header flags detail; Phase-3 capture checklist |
|      | https://dsremap.readthedocs.io/en/latest/reverse.html | | |
| E10b | controllers.fandom DS4 — ReportIn11 struct, EnableHID/EnableCRC bits, CRC32 trailer, 78-byte form | EXTERNAL | 49 vs 78-byte open question |
|      | https://controllers.fandom.com/wiki/Sony_DualShock_4 | | |
| E11 | palen1x guide — Dopamine via TrollStore available for iOS 15.0–15.8.6 (semi-untethered alternative) | EXTERNAL | second jailbreak candidate for 15.8.x |
|      | https://docs.palera.in/docs/get-started/installing-palen1x-windows | | |
| E12 | iOS 27 released 2026-09-14 (MacWorld et al.) | EXTERNAL | B-side OS confirmed current; controller stack claims from E3/E4 treated as current-era |
|      | https://www.macworld.com/article/2986799/ios-27-new-iphone-features-release-date-beta-compatiblity-apple-intelligence-siri.html | | |
| E13 | LOCAL build/test logs: 54/54 unit tests (incl. SDP responder + HOGP), IPA+debs build (arm64, minos 15.0), UDP echo 200/200 loopback, ds4lab compile | LOCAL | Phase-1/2 + Phase-3 protocol-toolkit correctness at build level |
|      | artifacts/logs/ | | |
| E14 | InternalBlue "iOS internalblued" doc — jailbroken-iPhone daemon bridging BT controller HCI to TCP; UART devices: iPhone 6/7/SE/8/XR (tested iOS 12–13); BlueTool raw HCI usage (`hci cmd`); WriteRAM 0xFC4D blocked ≥13.3; .hcd firmware embedded in BlueTool ≥13.6 | EXTERNAL | Phase-3 HCI transport = published technique on target chip class |
|      | https://github.com/bm16ton/internalblue/blob/master/doc/ios.md | | |
| E15 | "Bare-metal coding: the iPhone as a Bluetooth breadboard" — /dev/uart.bluetooth + /dev/btreset userland HCI, BlueTool boot scripts, chip controlled from userland | EXTERNAL | device-node architecture of iPhone BT (historic) |
|      | https://medium.com/@david.m.thornton/bare-metal-coding-the-iphone-as-a-bluetooth-breadboard-1e69b6b9939c | | |
| E16 | Frankenstein (USENIX Security'20) — InternalBlue patchram/ROM work on jailbroken iPhone SE/7/8/X/XR (BCM4345-class), firmware-level experimentation | EXTERNAL | chip-level precedent on A8–A11-class devices |
|      | https://www.usenix.org/system/files/sec20-ruge.pdf | | |
| E18 | **ON-DEVICE (iPhone A, iOS 15.8.8, TrollStore)** — user-run T3: ControllerA v0.2.0 installs and runs (UI + UDP loop healthy, 4648+ pkts); BLE probe: CBPeripheralManager init → state stuck at Unknown(0), NO permission prompt, app crashed to SpringBoard seconds later; addService(0x1812) never reached | ON-DEVICE | acceptance C partially VERIFIED (TrollStore install works); BLE public-API track fails in this environment; v2 instrumentation + .ips collection deployed |
|      | artifacts/evidence/T3-udp-popup.PNG · artifacts/evidence/T3-probe1-state0-stuck.jpeg | | |
| E19 | **ON-DEVICE v2 probe log** — authorization=notDetermined→allowed(1); CM state→poweredOn(5) at +5 s; PM state→poweredOn(5); then NSInternalInconsistencyException "Characteristics with cached values must be read-only" inside -[CBProbe addHIDService] | ON-DEVICE | v1 mystery crash root-caused (our 2A4E characteristic bug, NOT a daemon/TCC block); state resolution on this device takes ~5-6 s; probe now fixed to publish 0x1812 for the first time |
|      | artifacts/evidence/E19-probe2-log.txt | | |
| E20 | **ON-DEVICE decisive test** — under full entitlements (TrollStore + jb, iOS 15.8.8): addService(0x1812) refused with CBErrorDomain code=8; probe 2 (custom 128-bit service) adds + advertises OK | ON-DEVICE | E6 CONFIRMED on-device; BLE public-API HID track PROVEN BLOCKED; block = framework-level UUID allow-list; Phase-3 = chip-level HCI only |
|      | artifacts/evidence/E20-probe-e6-confirmation.txt | | |
| E17 | joycontrol — open-source Nintendo Switch Joy-Con/Pro emulation over Bluetooth (HCI-level) | EXTERNAL | BLE identity-track reference for hogp.c |
|      | https://github.com/QueenLinuxGlitch/joycontrol-kb | | |

## E21 (2026-09-27, LOCAL source review + external evidence, labeled)
- E20 scope correction: on-device proof covers `UUIDWithString:@"1812"` (16-bit) only.
- X1 2014 iOS7/8: long form ALSO blocked. X3 2022-24: macOS long form adds OK (mixed GATT results).
- X4/X6: "Bluetouch" (App Store) advertises real 0x1812 from iPad — third-party 1812 path exists.
- X5 HemiPad PR 2026 (AI-assisted): long-form publish recipe + 0x2908 Report Reference; hosts: Win/Linux/Android OK, consoles no, iOS-central unclaimed.
- X7: iOS 18.5+ pairs 8BitDo Ultimate 2 from Bluetooth list — generic-HID gamepad on modern iOS = plausible, UNVERIFIED for iOS 27.
- Conclusion: 0x1812 long-form on iOS 15.8.8 = UNKNOWN -> ProbeBLE.ipa built (NOT RUN).
