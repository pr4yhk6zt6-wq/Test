# 02 — Jailbreak / TrollStore Capability Audit (rule 0.2, 0.5)

## Decision chain required by rule 0.2

```
iOS 15.8.8 → device must be A8–A11 (6s/7/8/X/SE1) or A12+ (XS–13-era)
   A12+  → TrollStore: YES on 15.x arm64e [E1]; public jailbreak covering 15.8.x: none confirmed
           ⇒ "Jailbreak: YES" would then imply a private/unreleased tool → must ask user for jb details
   A8–A11→ palera1n (checkm8, semi-tethered, rootless default / rootful optional) [E2]
           or Dopamine-family semi-untethered via TrollStore on 15.0–15.8.x [E11]
```
⇒ **INFERRED**: A is an A8–A11 (arm64) device. **UNKNOWN until `idiag` output.**

## What each jailbreak type gives this project

| Capability | palera1n rootless | palera1n rootful | Dopamine (rootless) |
|---|---|---|---|
| TrollStore app install | YES (independent of jb) | YES | YES |
| CLI tools (.deb) under /var/jb | YES (Procursus) | YES (/usr) | YES (Procursus) |
| launchd daemons | YES (launchctl as root) | YES | YES |
| Tweak injection (ElleKit) | YES | YES | YES |
| Kernel patches (KPF via PongoOS) | YES | YES | limited (its own KPF) |
| Custom kext loading | Research-grade (PongoOS modules) — NOT assumed | same | NO |
| Direct BT chip (HCI/UART) access | UNKNOWN — needs `idiag` chip id + experimentation | same | same |
| A11 caveat | passcode/FaceID disabled while jailbroken [E2] | same | n/a |

**Do not assume** "jailbreak = everything". The one capability the whole Phase-3 depends on — driving the Broadcom BT controller in HID *device* role — has **no proven on-iOS implementation** and stays UNKNOWN (research track, docs/05 §Phase-3).

## TrollStore boundary audit (rule 0.5)

- TrollStore = permasigned install with arbitrary entitlements via CoreTrust bug; supported 14.0–16.6.1 ⊇ 15.8.x [E1].
- TrollStore gives: permanent app install, entitlements, root *helper* capability inside the app sandbox.
- TrollStore does **NOT** give: root shell system-wide, kernel access, BT chip access, daemon hosting.
- ⇒ ControllerA.ipa (app) = TrollStore. CLI tools + daemon = .deb via the jailbreak bootstrap (Sileo/Filza). This split is honored by the artifacts (see docs/06).

## Compatibility matrix (rule 0.3)

| Component | Required | Available | Verified |
|---|---|---|---|
| iOS 15.8.8 on A | YES | user-confirmed | NOT VERIFIED (run `idiag`) |
| Jailbreak on A | YES | user-confirmed | NOT VERIFIED (type unknown) |
| TrollStore on A | YES | user-confirmed | NOT VERIFIED (version check) |
| Rootless/Rootful | YES (to pick .deb layout) | UNKNOWN | NOT VERIFIED |
| Tweak injection | MAYBE | UNKNOWN | NOT NEEDED so far |
| Daemon execution | MAYBE | expected YES on palera1n/Dopamine | NOT VERIFIED |
| Private frameworks | MAYBE | UNKNOWN | NOT TESTED |
| IOKit/HID access | MAYBE | UNKNOWN | NOT TESTED |
| Bluetooth access (public, BLE) | YES | YES (CoreBluetooth, any iOS) | BUILD VERIFIED (app compiles; runtime NOT TESTED) |
| BT Classic HID device role | YES for Phase-3 | UNKNOWN | NOT TESTED — research gate |
| Network access | MAYBE | YES (public API) | BUILD VERIFIED |
| Entitlements | MAYBE | YES via TrollStore [E1] | NOT VERIFIED on device |
| iOS 27 controller support on B | YES | YES per Apple docs for DS4/Xbox/Switch [E3, E4] | NOT VERIFIED on device B |

Legend: VERIFIED = evidence obtained in THIS environment (device or full build). External documentation is cited, not claimed as device verification (rule 0.4).
