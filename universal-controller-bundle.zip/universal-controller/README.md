# Universal Game Controller — iPhone A → iPhone B

**iPhone A** (iOS 15.8.8 · jailbroken · TrollStore) เป็นเครื่องเดียวที่ถูกแก้ไข → ทำหน้าที่เป็น **เกมคอนโทรลเลอร์จริง** ให้ **iPhone B** (iOS 27 · stock) ซึ่ง**ไม่ถูกติดตั้ง/แก้ไขอะไรเลย** ไม่มี PC/Mac/Pi/hardware bridge

> ## FORMAL STATUS: `PARTIAL` — BUILD VERIFIED / HARDWARE NOT TESTED
> Phase 1–2 สร้างและทดสอบเชิง build ครบ (IPA + 2 debs + 41/41 unit tests)
> เป้าหมายปลายทาง (B เห็น A เป็น controller) ยังไม่สำเร็จ — blocker ที่เหลือคือ Phase-3:
> ทำ Bluetooth device-role บน A = **UNKNOWN, research-gated** พร้อมแผนทดลองที่ falsifiable
> รายละเอียด: `docs/STATUS.md` · ห้ามอ้าง SUCCESS (rule 32)

## Deliverables (rule 33 mapping)

| # | ของ | ที่อยู่ |
|---|---|---|
| 1 | Working Architecture | docs/05-architecture.md (phased hybrid, tracks A–K พร้อมเหตุผล) |
| 2 | Device/Jailbreak Compatibility Report | docs/01-device-audit.md · docs/02-capability-audit.md |
| 3 | Source Code | src/ControllerA · src/idiag · src/ds4bridge · src/ds4bridged-theos |
| 4 | ControllerA.ipa | artifacts/ControllerA.ipa (v0.3.0: probe v2 + crash journal + fixed status label) |
| 5 | .deb (tool + daemon shell) | artifacts/com.research.idiag_0.4.0…deb (`-c` .ips collector, `-p` BT-permission audit) · com.research.ds4bridged_…deb (rootless) |
| 6 | Installation Guide (A) | docs/06-install-guide.md |
| 7 | Pairing Guide (A→B) | docs/07-pairing-guide.md |
| 8 | Diagnostic Tools | tools/aidiag-standalone.sh · idiag (deb) · ControllerA BLE probe |
| 9 | Test Report | docs/08-test-plan.md + artifacts/logs/ (host tests) |
| 10 | Known Limitations | docs/10-known-limitations.md |
| 11 | Evidence Register | docs/11-evidence-register.md (E1–E13) |
| 12 | Methods tried | docs/09-failure-ledger.md §9.1–9.2 |
| 13 | Failure analysis | docs/09-failure-ledger.md (ทุก entry มี 6-line format) |
| 14 | Technical reasons for architecture | docs/04-research-dossier.md · docs/05-architecture.md |

## Quick start on the real devices (when available)

```sh
# 0) audit A first — no architecture decision before evidence (rule 0.2/0.3)
sh tools/aidiag-standalone.sh            # or install idiag.deb and run: /var/jb/usr/bin/idiag
# 1) TrollStore → install artifacts/ControllerA.ipa → launch
# 2) follow tools/hw-test-checklist.sh (T0–T9), record into docs/08-test-plan.md
```

## What works today (evidence-backed)

- ControllerA app: full 13-input controller UI, 120 Hz input engine (deadzone, CRC-16, seq, 250 ms stale policy), UDP lab transport with live RTT, UDS transport to the future daemon, and an on-device **BLE HID probe** that re-verifies the iOS HID-peripheral block on A itself.
- ds4bridge protocol core (C, portable): ICInputPacket wire format, DS4 BT report 0x11 packer (GIMX/dsremap layout), HID report map + validator, SDP HID+PnP records, **SDP responder** (ServiceSearchAttribute + continuation), **HOGP/Joy-Con GATT DB builder**, BT-HID **device-role state machine** (control/interrupt PSMs, GET/SET_REPORT, handshake, keepalive, stale→neutral) — **54/54 unit tests pass** on host.
- **ds4lab** (lab backend): PC + BT dongle plays the full DS4 identity (our SDP responder + HID channels), input from A via UDP — validates the whole protocol against a real iPhone B without touching A's chip. Built; runtime needs a BT adapter (NOT TESTED in sandbox).
- Phase-3 transport prior art secured: internalblued/BlueTool HCI access on UART-Broadcom iPhones (E14–E16) — ladder และ kill criteria ใน docs/12.
- Cross-built artifacts: `ControllerA.ipa`, `idiag` (deb), `ds4bridged` (deb, self-test via null transport) — all arm64, min iOS 15.0.

## What is explicitly NOT claimed

- ไม่มีการยืนยันบน hardware จริง (A/B) — ทุก on-device test = NOT RUN (docs/08)
- Public-API BLE HID path = **PROVEN BLOCKED** (external evidence + on-device probe ไว้ยืนยันซ้ำ)
- Generic BLE HID gamepad identity = closed by evidence (iOS แสดงเฉพาะ controller identity ที่รู้จัก)
- ทุก claim จากภายนอกถูกติดป้าย EXTERNAL และไม่ถูกนำมาอ้างเป็นผลทดสอบของ environment นี้ (rule 0.4)

## Layout

```
universal-controller/
├─ artifacts/        ControllerA.ipa · idiag.deb (v0.3) · ds4bridged.deb · logs/
├─ docs/             01 audit · 02 capability+matrix · 04 research · 05 architecture
│                    06 install · 07 pairing · 08 tests · 09 failures · 10 limits · 11 evidence
├─ tools/            aidiag-standalone.sh · hw-test-checklist.sh
└─ src/
   ├─ ControllerA/       (Theos app → ipa)
   ├─ idiag/             (Theos CLI → deb)
   ├─ ds4bridge/         (portable C core + host tests + udp_echo lab tool)
   └─ ds4bridged-theos/  (Theos daemon shell → deb)
```

## Rebuild from source

```sh
export THEOS=…  # theos + L1ghtmann iOSToolchain + theos/sdks + Procursus ldid
( cd src/ControllerA      && make -j2 )   # .app → package ipa per docs/06
( cd src/idiag            && make package FINALPACKAGE=1 )
( cd src/ds4bridged-theos && make package FINALPACKAGE=1 )
( cd src/ds4bridge        && make test  ) # host unit tests
```
