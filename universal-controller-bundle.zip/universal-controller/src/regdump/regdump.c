/* regdump — IOKit registry walker (pure dlsym, no IOKit headers needed).
   Prints every node whose name/class matches BT/UART keywords, with
   power/GPIO/clock properties. Bounded: depth cap + print cap. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dlfcn.h>
#include <CoreFoundation/CoreFoundation.h>
#include <mach/mach.h>
typedef mach_port_t io_object_t;
typedef mach_port_t io_iterator_t;
static mach_port_t (*_IORegistryEntryFromPath)(mach_port_t, const char *);
static kern_return_t (*_IORegistryEntryGetName)(io_object_t, char *);
static kern_return_t (*_IOObjectGetClass)(io_object_t, char *);
static kern_return_t (*_IORegistryEntryGetChildIterator)(io_object_t, const char *, io_iterator_t *);
static io_object_t (*_IOIteratorNext)(io_iterator_t);
static kern_return_t (*_IOObjectRelease)(io_object_t);
static kern_return_t (*_IORegistryEntryCreateCFProperties)(io_object_t, CFMutableDictionaryRef *, CFAllocatorRef, uint32_t);
static mach_port_t kZeroPort = 0;
static int lo(const char *s, const char *kw) {
    char a[128]; size_t i; for (i = 0; s[i] && i < 127; i++) a[i] = (s[i] >= 'A' && s[i] <= 'Z') ? s[i] + 32 : s[i]; a[i] = 0;
    return strstr(a, kw) != NULL;
}
static int node_interesting(const char *nm, const char *cls) {
    static const char *kws[] = { "bcm", "blue", "uart", "serial", "hci", "gpout", "gpio", NULL };
    for (int i = 0; kws[i]; i++) if (lo(nm, kws[i]) || lo(cls, kws[i])) return 1;
    return 0;
}
static int prop_interesting(const char *k) {
    static const char *kws[] = { "gpio", "reg", "clock", "power", "reset", "enable", "baud", "firmware", "config", "bluet", "device", "interrupt", "function", NULL };
    for (int i = 0; kws[i]; i++) if (lo(k, kws[i])) return 1;
    return 0;
}
static int g_prints = 0;
static void dump_prop(CFStringRef key, CFTypeRef val) {
    char kb[96];
    if (!CFStringGetCString(key, kb, sizeof(kb), kCFStringEncodingUTF8)) return;
    if (!prop_interesting(kb)) return;
    CFTypeID t = CFGetTypeID(val);
    if (t == CFStringGetTypeID()) {
        char vb[160];
        if (CFStringGetCString(val, vb, sizeof(vb), kCFStringEncodingUTF8)) { printf("    %s = \"%s\"\n", kb, vb); g_prints++; }
    } else if (t == CFNumberGetTypeID()) {
        long long v = 0; CFNumberGetValue(val, kCFNumberLongLongType, &v);
        printf("    %s = %lld\n", kb, v); g_prints++;
    } else if (t == CFDataGetTypeID()) {
        CFIndex n = CFDataGetLength(val);
        const uint8_t *b = CFDataGetBytePtr(val);
        printf("    %s = data[%ld]:", kb, (long)n);
        for (CFIndex i = 0; i < n && i < 8; i++) printf(" %02X", b[i]);
        printf("\n"); g_prints++;
    } else if (t == CFArrayGetTypeID()) {
        CFIndex n = CFArrayGetCount(val);
        printf("    %s = array[%ld]:", kb, (long)n);
        for (CFIndex i = 0; i < n && i < 6; i++) {
            CFTypeRef e = CFArrayGetValueAtIndex(val, i);
            if (CFGetTypeID(e) == CFNumberGetTypeID()) { long long v = 0; CFNumberGetValue(e, kCFNumberLongLongType, &v); printf(" %lld", v); }
            else if (CFGetTypeID(e) == CFDataGetTypeID()) printf(" data[%ld]", (long)CFDataGetLength(e));
            else printf(" ?");
        }
        printf("\n"); g_prints++;
    }
}
static void walk(io_object_t node, const char *path, int depth) {
    if (depth > 22 || g_prints > 600) return;
    char nm[128] = "?", cls[128] = "?";
    _IORegistryEntryGetName(node, nm);
    _IOObjectGetClass(node, cls);
    if (node_interesting(nm, cls)) {
        printf("[%s] name=%s class=%s\n", path, nm, cls);
        g_prints++;
        CFMutableDictionaryRef d = NULL;
        if (_IORegistryEntryCreateCFProperties(node, &d, NULL, 0) == 0 && d) {
            CFIndex n = CFDictionaryGetCount(d);
            if (n > 0 && n < 200) {
                CFTypeRef *vals = malloc(sizeof(CFTypeRef) * n);
                CFStringRef *keys = malloc(sizeof(CFStringRef) * n);
                CFDictionaryGetKeysAndValues(d, (const void **)keys, (const void **)vals);
                for (CFIndex i = 0; i < n; i++) dump_prop(keys[i], vals[i]);
                free(vals); free(keys);
            }
            CFRelease(d);
        }
    }
    io_iterator_t it;
    if (_IORegistryEntryGetChildIterator(node, "IOService", &it) == 0) {
        io_object_t ch;
        char npath[512];
        while ((ch = _IOIteratorNext(it)) != 0 && g_prints < 650) {
            snprintf(npath, sizeof(npath), "%s/%s", path, nm);
            walk(ch, npath, depth + 1);
            _IOObjectRelease(ch);
        }
        _IOObjectRelease(it);
    }
}
int main(void) {
    setvbuf(stdout, NULL, _IONBF, 0);
    printf("regdump 1.0\n");
    void *k = dlopen("/System/Library/Frameworks/IOKit.framework/IOKit", RTLD_NOW);
    if (!k) { printf("dlopen IOKit errno=%s\n", dlerror()); return 1; }
    _IORegistryEntryFromPath = dlsym(k, "IORegistryEntryFromPath");
    _IORegistryEntryGetName = dlsym(k, "IORegistryEntryGetName");
    _IOObjectGetClass = dlsym(k, "IOObjectGetClass");
    _IORegistryEntryGetChildIterator = dlsym(k, "IORegistryEntryGetChildIterator");
    _IOIteratorNext = dlsym(k, "IOIteratorNext");
    _IOObjectRelease = dlsym(k, "IOObjectRelease");
    _IORegistryEntryCreateCFProperties = dlsym(k, "IORegistryEntryCreateCFProperties");
    if (!_IORegistryEntryFromPath || !_IORegistryEntryGetChildIterator) { printf("dlsym failed\n"); return 1; }
    io_object_t root = _IORegistryEntryFromPath(kZeroPort, "IOService:/");
    if (!root) { printf("no root\n"); return 1; }
    walk(root, "", 0);
    printf("REGDUMP-DONE (prints=%d)\n", g_prints);
    return 0;
}
