#!/bin/sh
# package-ipa.sh — idiagTS (TrollStore G1 audit app, no jailbreak needed)
set -e
export THEOS=${THEOS:-/home/user/.cache/theos}
export PATH="$THEOS/bin:$PATH"
APP=.theos/obj/debug/idiagTS.app
[ -f "$APP/idiagTS" ] || { echo "binary missing — run make first"; exit 1; }

cat > "$APP/Info.plist" <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>CFBundleDevelopmentRegion</key><string>en</string>
	<key>CFBundleDisplayName</key><string>idiagTS</string>
	<key>CFBundleExecutable</key><string>idiagTS</string>
	<key>CFBundleIdentifier</key><string>com.research.idiagts</string>
	<key>CFBundleInfoDictionaryVersion</key><string>6.0</string>
	<key>CFBundleName</key><string>idiagTS</string>
	<key>CFBundlePackageType</key><string>APPL</string>
	<key>CFBundleShortVersionString</key><string>0.1.1</string>
	<key>CFBundleVersion</key><string>2</string>
	<key>MinimumOSVersion</key><string>15.0</string>
	<key>UIRequiresFullScreen</key><true/>
	<key>UISupportedInterfaceOrientations</key>
	<array>
		<string>UIInterfaceOrientationPortrait</string>
	</array>
</dict>
</plist>
EOF

# TrollStore entitlements (embedded) — platform app, no sandbox/container
cat > /tmp/idiagts.ent.plist <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>platform-application</key><true/>
	<key>com.apple.private.security.no-container</key><true/>
	<key>com.apple.private.security.no-sandbox</key><true/>
	<key>com.apple.private.skip-library-validation</key><true/>
</dict>
</plist>
EOF

"$THEOS/bin/ldid" -S/tmp/idiagts.ent.plist "$APP/idiagTS"
rm -rf Payload
mkdir Payload
cp -r "$APP" Payload/
OUT=../../artifacts/idiagTS.ipa
rm -f "$OUT"
zip -qry "$OUT" Payload
echo "packaged: $OUT"
unzip -l "$OUT"
