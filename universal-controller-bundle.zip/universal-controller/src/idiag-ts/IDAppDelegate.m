#import <UIKit/UIKit.h>
#import "IDViewController.h"

@interface IDAppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow *window;
@end

@implementation IDAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.rootViewController = [[IDViewController alloc] init];
    [self.window makeKeyAndVisible];
    return YES;
}

@end
