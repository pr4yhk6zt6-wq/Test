#import "IDViewController.h"
#import <sys/sysctl.h>
#import <sys/stat.h>
#import <sys/errno.h>
#import <string.h>
#import <fcntl.h>
#import <unistd.h>
#import <dirent.h>
#import <dlfcn.h>

/* idiagTS — G1 audit WITHOUT jailbreak (TrollStore app).
   Rationale: user reports /var/jb absent on iPhone A -> the LaunchDaemon
   runbook can't run. TrollStore installs this app with platform
   entitlements (embedded via ldid), enough for: sysctls, filesystem
   existence probes, /dev node stat + open() attempt, binary presence,
   limited IORegistry. Everything is READ-ONLY.
   Lessons applied: log view gets EXPLICIT height (ProbeBLE v0.1.0 bug);
   copy button; report also written to /var/mobile/Documents/. */

typedef mach_port_t io_object_t;
typedef io_object_t io_iterator_t;
typedef io_object_t io_registry_entry_t;
typedef char io_name_t[128];
typedef kern_return_t (*fn_IORegistryGetRootEntry)(mach_port_t, io_registry_entry_t *);
typedef kern_return_t (*fn_IORegistryEntryGetChildEntry)(io_registry_entry_t, const char *, io_iterator_t *);
typedef kern_return_t (*fn_IOIteratorNext)(io_iterator_t, io_object_t *);
typedef kern_return_t (*fn_IOObjectGetClass)(io_object_t, io_name_t);
typedef kern_return_t (*fn_IOObjectRelease)(io_object_t);
typedef CFTypeRef (*fn_IORegistryEntryCreateCFProperties)(io_registry_entry_t, CFMutableDictionaryRef *, CFAllocatorRef, uint32_t);

static NSMutableString *out;
#define P(...) do { [out appendString:[NSString stringWithFormat:__VA_ARGS__]]; [out appendString:@"\n"]; } while (0)

static NSString *sysctlStr(NSString *name) {
    size_t len = 0;
    if (sysctlbyname(name.UTF8String, NULL, &len, NULL, 0) != 0 || len == 0) return @"UNKNOWN";
    char buf[512];
    if (len > sizeof(buf) - 1) len = sizeof(buf) - 1;
    if (sysctlbyname(name.UTF8String, buf, &len, NULL, 0) != 0) return @"UNKNOWN";
    return [NSString stringWithUTF8String:buf] ?: @"UNKNOWN";
}

static BOOL ex(const char *p) { struct stat st; return stat(p, &st) == 0; }
static long fsz(const char *p) { struct stat st; return stat(p, &st) == 0 ? (long)st.st_size : -1; }

/* hw.machine -> marketing name / SoC / checkm8 (A8..A11) / our-jb feasibility notes */
static NSString *modelInfo(NSString *m) {
    NSDictionary *d = @{
        @"iPhone6,1": @"iPhone 5s / A7 / checkm8",
        @"iPhone6,2": @"iPhone 5s / A7 / checkm8",
        @"iPhone7,1": @"iPhone 6 Plus / A8 / checkm8",
        @"iPhone7,2": @"iPhone 6 / A8 / checkm8",
        @"iPhone8,1": @"iPhone 6s / A9 / checkm8",
        @"iPhone8,2": @"iPhone 6s Plus / A9 / checkm8",
        @"iPhone8,4": @"iPhone SE (1st) / A9 / checkm8",
        @"iPhone9,1": @"iPhone 7 / A10 / checkm8",
        @"iPhone9,3": @"iPhone 7 / A10 / checkm8",
        @"iPhone9,2": @"iPhone 7 Plus / A10 / checkm8",
        @"iPhone9,4": @"iPhone 7 Plus / A10 / checkm8",
        @"iPhone10,1": @"iPhone 8 / A11 / checkm8 (palera1n OK, A11 passcode caveat)",
        @"iPhone10,4": @"iPhone 8 / A11 / checkm8 (palera1n OK, A11 passcode caveat)",
        @"iPhone10,2": @"iPhone X / A11 / checkm8 (palera1n OK, A11 passcode caveat)",
        @"iPhone10,5": @"iPhone X / A11 / checkm8 (palera1n OK, A11 passcode caveat)",
        @"iPhone10,3": @"iPhone XS / A12 / NO checkm8",
        @"iPhone10,6": @"iPhone XS Max / A12 / NO checkm8",
        @"iPhone11,2": @"iPhone XS / A12 / NO checkm8",
        @"iPhone11,4": @"iPhone XS Max / A12 / NO checkm8",
        @"iPhone11,6": @"iPhone XS Max / A12 / NO checkm8",
        @"iPhone11,8": @"iPhone XR / A12 / NO checkm8",
        @"iPhone12,1": @"iPhone 11 / A13 / NO checkm8",
        @"iPhone12,3": @"iPhone 12 Pro / A14 / NO checkm8",
        @"iPhone12,8": @"iPhone SE (2nd) / A13 / NO checkm8",
        @"iPhone13,1": @"iPhone 13 mini / A15 / NO checkm8",
        @"iPhone13,2": @"iPhone 13 / A15 / NO checkm8",
        @"iPhone14,2": @"iPhone 13 Pro / A15 / NO checkm8",
        @"iPhone14,4": @"iPhone 13 mini / A15 / NO checkm8",
        @"iPhone14,5": @"iPhone 14 / A15 / NO checkm8",
        @"iPhone14,7": @"iPhone 14 / A15 / NO checkm8",
    };
    return d[m] ?: [NSString stringWithFormat:@"%@ / UNKNOWN model mapping", m];
}

@implementation IDViewController {
    UITextView *_log;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];

    UILabel *t = [[UILabel alloc] init];
    t.text = @"idiagTS — G1 audit (no jailbreak needed)";
    t.textColor = [UIColor cyanColor];
    t.font = [UIFont boldSystemFontOfSize:15];
    t.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:t];

    UIButton *run = [UIButton buttonWithType:UIButtonTypeSystem];
    [run setTitle:@"RUN AUDIT" forState:UIControlStateNormal];
    [run addTarget:self action:@selector(runAudit) forControlEvents:UIControlEventTouchUpInside];
    UIButton *copy = [UIButton buttonWithType:UIButtonTypeSystem];
    [copy setTitle:@"COPY REPORT" forState:UIControlStateNormal];
    [copy addTarget:self action:@selector(copyReport) forControlEvents:UIControlEventTouchUpInside];
    for (UIButton *b in @[run, copy]) {
        b.tintColor = [UIColor cyanColor];
        b.layer.borderColor = [UIColor cyanColor].CGColor;
        b.layer.borderWidth = 1;
        b.layer.cornerRadius = 8;
        b.titleLabel.font = [UIFont boldSystemFontOfSize:13];
        b.translatesAutoresizingMaskIntoConstraints = NO;
        [self.view addSubview:b];
    }

    _log = [[UITextView alloc] init];
    _log.editable = NO;
    _log.backgroundColor = [UIColor colorWithWhite:0.08 alpha:1];
    _log.textColor = [UIColor greenColor];
    _log.font = [UIFont monospacedSystemFontOfSize:11 weight:UIFontWeightRegular];
    _log.layer.cornerRadius = 8;
    _log.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:_log];

    [NSLayoutConstraint activateConstraints:@[
        [t.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:8],
        [t.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:14],
        [run.topAnchor constraintEqualToAnchor:t.bottomAnchor constant:10],
        [run.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:12],
        [run.widthAnchor constraintEqualToAnchor:self.view.widthAnchor multiplier:0.45],
        [run.heightAnchor constraintEqualToConstant:40],
        [copy.topAnchor constraintEqualToAnchor:run.topAnchor],
        [copy.leadingAnchor constraintEqualToAnchor:run.trailingAnchor constant:10],
        [copy.widthAnchor constraintEqualToAnchor:run.widthAnchor],
        [copy.heightAnchor constraintEqualToConstant:40],
        [_log.topAnchor constraintEqualToAnchor:run.bottomAnchor constant:10],
        [_log.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:10],
        [_log.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-10],
        /* explicit height — do NOT rely on intrinsic size (ProbeBLE lesson) */
        [_log.heightAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.heightAnchor multiplier:0.72],
    ]];
    _log.text = @"press RUN AUDIT to start.\n";
}

- (void)copyReport {
    UIPasteboard.generalPasteboard.string = _log.text;
    UIAlertController *a = [UIAlertController alertControllerWithTitle:@"Copied" message:@"report copied to clipboard — paste it to the chat" preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:a animated:YES completion:nil];
}

- (void)runAudit {
    out = [NSMutableString new];
    P(@"=== idiagTS v0.1.0 — G1 audit (TrollStore, no jb) ===");
    P(@"# all probes are READ-ONLY; UNKNOWN = could not determine");

    P(@"");
    P(@"--- Hardware / OS ---");
    NSString *mach = sysctlStr(@"hw.machine");
    P(@"hw.machine    = %@", mach);
    P(@"model decode  = %@", modelInfo(mach));
    P(@"hw.model      = %@", sysctlStr(@"hw.model"));
    P(@"kern.osversion         = %@", sysctlStr(@"kern.osversion"));
    P(@"kern.osproductversion  = %@", sysctlStr(@"kern.osproductversion"));

    P(@"");
    P(@"--- Jailbreak state (user reports NO /var/jb — verify here) ---");
    P(@"/var/jb            = %@", ex("/var/jb") ? @"YES" : @"no");
    P(@"/.procursus        = %@", ex("/.procursus") ? @"YES (rootful)" : @"no");
    P(@"/.bootstrapped     = %@", ex("/.bootstrapped") ? @"YES" : @"no");
    P(@"/var/jb/basebin    = %@", ex("/var/jb/basebin") ? @"YES (palera1n)" : @"no");
    P(@"/usr/lib/substrate = %@", (ex("/usr/lib/substrate") || ex("/usr/lib/TweakInject")) ? @"YES" : @"no");
    P(@"/var/jb/usr/lib/TweakInject = %@", ex("/var/jb/usr/lib/TweakInject") ? @"YES" : @"no");

    P(@"");
    P(@"--- TrollStore markers ---");
    P(@"/var/jb/Applications/TrollStore.app = %@", ex("/var/jb/Applications/TrollStore.app") ? @"YES" : @"no");
    P(@"/Applications/TrollStore.app        = %@", ex("/Applications/TrollStore.app") ? @"YES" : @"no");
    P(@"(running INSIDE TrollStore-installed app right now = TrollStore exists)");

    P(@"");
    P(@"--- Bluetooth stack surfaces (G-track critical) ---");
    struct stat st;
    BOOL have = NO;
    if (stat("/dev/uart.bluetooth", &st) == 0) {
        have = YES;
        P(@"/dev/uart.bluetooth EXISTS (mode %o)", st.st_mode & 07777);
        int fd = open("/dev/uart.bluetooth", O_RDONLY);
        if (fd >= 0) {
            uint8_t b[16] = {0};
            ssize_t n = read(fd, b, sizeof(b));
            P(@"  open+read OK (%zd bytes):%@ %.*s", n, n > 0 ? @"" : @"", (int)(n > 0 ? (n > 16 ? 16 : n) : 0), b);
            close(fd);
            P(@"  >>> direct userland HCI transport LOOKS POSSIBLE from this app <<<");
        } else {
            P(@"  open() FAILED errno=%d (%s)", errno, strerror(errno));
        }
    } else {
        P(@"/dev/uart.bluetooth = not visible (errno=%d)", errno);
    }
    P(@"/dev/btreset        = %@", ex("/dev/btreset") ? @"YES" : @"no");
    long blt1 = fsz("/usr/sbin/BlueTool");
    P(@"/usr/sbin/BlueTool  = %@", blt1 >= 0 ? [NSString stringWithFormat:@"YES (%ld bytes)", blt1] : @"no");
    long blt2 = fsz("/usr/bin/BlueTool");
    P(@"/usr/bin/BlueTool   = %@", blt2 >= 0 ? [NSString stringWithFormat:@"YES (%ld bytes)", blt2] : @"no");
    long btd = fsz("/usr/libexec/bluetoothd");
    P(@"/usr/libexec/bluetoothd = %@", btd >= 0 ? [NSString stringWithFormat:@"YES (%ld bytes)", btd] : @"no");
    if (!have) P(@"note: /dev visibility can differ between jb and non-jb contexts — UNKNOWN here");

    P(@"");
    P(@"--- IOKit Bluetooth nodes (limited without jb; UNKNOWN expected) ---");
    @try {
        void *iokit = dlopen("/System/Library/Frameworks/IOKit.framework/IOKit", RTLD_LAZY);
        if (!iokit) { P(@"IOKit dylib not loadable -> UNKNOWN"); }
        else {
            fn_IORegistryGetRootEntry pRoot = (fn_IORegistryGetRootEntry)dlsym(iokit, "IORegistryGetRootEntry");
            fn_IORegistryEntryGetChildEntry pChild = (fn_IORegistryEntryGetChildEntry)dlsym(iokit, "IORegistryEntryGetChildEntry");
            fn_IOIteratorNext pNext = (fn_IOIteratorNext)dlsym(iokit, "IOIteratorNext");
            fn_IOObjectGetClass pClass = (fn_IOObjectGetClass)dlsym(iokit, "IOObjectGetClass");
            fn_IOObjectRelease pRelease = (fn_IOObjectRelease)dlsym(iokit, "IOObjectRelease");
            fn_IORegistryEntryCreateCFProperties pProps = (fn_IORegistryEntryCreateCFProperties)dlsym(iokit, "IORegistryEntryCreateCFProperties");
            if (!pRoot || !pChild || !pNext || !pClass || !pRelease) { P(@"IOKit symbols missing -> UNKNOWN"); }
            else {
                io_registry_entry_t root;
                if (pRoot(0, &root) != KERN_SUCCESS) { P(@"IORegistry root not accessible -> UNKNOWN (expected without jb)"); }
                else {
                    __block int hits = 0;
                    [self walk:root depth:0 cls:pClass child:pChild next:pNext rel:pRelease props:pProps hits:&hits];
                    pRelease(root);
                    if (!hits) P(@"no Bluetooth-prefixed IOKit classes visible -> UNKNOWN (limited perms)");
                }
            }
        }
    } @catch (NSException *e) { P(@"IOKit probe exception: %@", e.reason); }

    P(@"");
    P(@"=== end of report ===");

    _log.text = [NSString stringWithString:out];
    NSString *dst = @"/var/mobile/Documents/idiag-ts-report.txt";
    [out writeToFile:dst atomically:YES encoding:NSUTF8StringEncoding error:nil];
    NSArray *dirs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    if (dirs.count) [out writeToFile:[dirs[0] stringByAppendingPathComponent:@"idiag-ts-report.txt"] atomically:YES encoding:NSUTF8StringEncoding error:nil];
}

- (void)walk:(io_registry_entry_t)node depth:(int)depth
         cls:(fn_IOObjectGetClass)cls child:(fn_IORegistryEntryGetChildEntry)child
        next:(fn_IOIteratorNext)next rel:(fn_IOObjectRelease)rel props:(fn_IORegistryEntryCreateCFProperties)props hits:(int *)hits {
    if (depth > 4 || *hits > 8) return;
    io_iterator_t iter = 0;
    if (child(node, "IOService", &iter) != KERN_SUCCESS) return;
    io_object_t ch;
    while (next(iter, &ch) == KERN_SUCCESS && *hits <= 8) {
        io_name_t nm = {0};
        cls(ch, nm);
        NSString *c = [NSString stringWithUTF8String:nm] ?: @"";
        if ([c rangeOfString:@"Bluetooth" options:NSCaseInsensitiveSearch].length ||
            [c rangeOfString:@"BCM4" options:NSCaseInsensitiveSearch].length) {
            (*hits)++;
            P(@"  IOKit class: %@", c);
            if (props) {
                CFMutableDictionaryRef d = NULL;
                if (props(ch, &d, kCFAllocatorDefault, 0) == KERN_SUCCESS && d) {
                    for (NSString *k in @[@"Bluetooth Firmware Version", @"HardwareVersion", @"Chipset", @"Vendor", @"Product", @"Transport"]) {
                        id v = (__bridge id)CFDictionaryGetValue(d, (__bridge const void *)k);
                        if (v) {
                            if ([v isKindOfClass:[NSData class]])
                                P(@"    %@ = %@", k, [[NSString alloc] initWithData:v encoding:NSUTF8StringEncoding] ?: [v base64EncodedStringWithOptions:0]);
                            else
                                P(@"    %@ = %@", k, v);
                        }
                    }
                    CFRelease(d);
                }
            }
        }
        [self walk:ch depth:depth + 1 cls:cls child:child next:next rel:rel props:props hits:hits];
        rel(ch);
    }
    rel(iter);
}
@end
