/* up5 — cu.node multi-baud HCI prober. argv = baud list. */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <termios.h>
#include <stdarg.h>
#include <sys/select.h>
#include <sys/ioctl.h>
#ifndef IOSSIOSPEED
#define IOSSIOSPEED _IOW('T', 38, speed_t)
#endif
#define P "/dev/cu.bluetooth"
int main(int argc, char **argv) {
    setvbuf(stdout, NULL, _IONBF, 0);
    static const uint8_t reset[4] = { 0x01, 0x03, 0x0C, 0x00 };
    for (int a = 1; a < argc; a++) {
        int baud = atoi(argv[a]);
        printf("\n=== CU-NODE %d ===\n", baud);
        int fd = open(P, O_RDWR | O_NONBLOCK | O_NOCTTY);
        if (fd < 0) { printf("open errno=%d\n", errno); continue; }
        struct termios t;
        if (tcgetattr(fd, &t) == 0) {
            t.c_iflag &= ~(tcflag_t)(IGNBRK | BRKINT | PARMRK | ISTRIP | INLCR | IGNCR | ICRNL | IXON | IXOFF | IXANY);
            t.c_oflag &= ~(tcflag_t)OPOST;
            t.c_lflag &= ~(tcflag_t)(ECHO | ECHONL | ICANON | ISIG | IEXTEN);
            t.c_cflag &= ~(tcflag_t)(PARENB | CSTOPB);
            t.c_cflag |= CS8 | CREAD | CLOCAL;
#ifdef CCTS_OFLOW
            t.c_cflag &= ~(tcflag_t)CCTS_OFLOW;
#endif
            t.c_cc[VMIN] = 0; t.c_cc[VTIME] = 0;
            cfsetispeed(&t, 115200); cfsetospeed(&t, 115200);
            if (tcsetattr(fd, TCSANOW, &t) != 0) printf("tcsetattr errno=%d\n", errno);
            speed_t sp = (speed_t)baud;
            if (ioctl(fd, IOSSIOSPEED, &sp) == 0) printf("IOSSIOSPEED %d OK\n", baud);
            else printf("IOSSIOSPEED errno=%d\n", errno);
            int m = 0;
            if (ioctl(fd, TIOCMGET, &m) == 0)
                printf("modem: CTS=%d DSR=%d DCD=%d\n", !!(m & TIOCM_CTS), !!(m & TIOCM_DSR), !!(m & TIOCM_CAR));
            m |= TIOCM_RTS | TIOCM_DTR;
            ioctl(fd, TIOCMSET, &m);
            usleep(50000);
            ssize_t w = write(fd, reset, 4);
            printf("wrote=%zd errno=%d\n", w, errno);
            int total = 0;
            for (int r = 0; r < 10; r++) {
                fd_set rf; FD_ZERO(&rf); FD_SET(fd, &rf);
                struct timeval tv = { 0, 300000 };
                int rv = select(fd + 1, &rf, NULL, NULL, &tv);
                if (rv <= 0) { if (r > 4) break; continue; }
                uint8_t buf[256];
                ssize_t n = read(fd, buf, sizeof(buf));
                if (n > 0) {
                    total += (int)n;
                    printf("rx[%d]:", (int)n);
                    for (ssize_t i = 0; i < n; i++) printf(" %02X", buf[i]);
                    printf("\n");
                }
            }
            if (total) printf(">>> CHIP TALKS AT %d (%d bytes) <<<\n", baud, total);
            else printf("silent at %d\n", baud);
        } else printf("tcgetattr errno=%d (not a tty?)\n", errno);
        close(fd);
        usleep(150000);
    }
    printf("UP5-DONE\n");
    return 0;
}
