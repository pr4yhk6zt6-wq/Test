/* up3 — BlueTool wrapper with microsecond port takeover.
   Child = real /usr/sbin/BlueTool (does full chip bring-up).
   Parent = waitpid(); the instant BlueTool dies, opens the UART
   itself and talks HCI at 6M before the chip loses power. */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <termios.h>
#include <sys/select.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#ifndef IOSSIOSPEED
#define IOSSIOSPEED _IOW('T', 38, speed_t)
#endif
#define P "/dev/uart.bluetooth"
int main(void) {
    setvbuf(stdout, NULL, _IONBF, 0);
    FILE *lg = freopen("/var/mobile/Documents/up3.log", "w", stdout);
    (void)lg;
    printf("up3 wrapper start (pid=%d)\n", getpid());
    int pp[2];
    if (pipe(pp) != 0) { printf("pipe errno=%d\n", errno); return 1; }
    pid_t pid = fork();
    if (pid == 0) {
        dup2(pp[0], 0);
        close(pp[0]); close(pp[1]); /* parent keeps write end -> stdin never EOFs */
        char *argv[] = { "/usr/sbin/BlueTool", NULL };
        execv(argv[0], argv);
        printf("EXEC_FAIL BlueTool errno=%d\n", errno);
        _exit(127);
    }
    close(pp[0]);
    printf("holding BlueTool stdin pipe open (write fd=%d)\n", pp[1]);
    printf("BlueTool child pid=%d — waiting for its death...\n", pid);
    int st = 0;
    waitpid(pid, &st, 0);
    printf("BlueTool gone (status=0x%x) — TAKING OVER NOW\n", st);
    int fd = open(P, O_RDWR | O_NONBLOCK);
    if (fd < 0) { printf("takeover open errno=%d\n", errno); return 1; }
    printf("takeover open OK fd=%d\n", fd);
    struct termios t;
    tcgetattr(fd, &t);
    t.c_iflag &= ~(tcflag_t)(IGNBRK | BRKINT | PARMRK | ISTRIP | INLCR | IGNCR | ICRNL | IXON | IXOFF | IXANY);
    t.c_oflag &= ~(tcflag_t)OPOST;
    t.c_lflag &= ~(tcflag_t)(ECHO | ECHONL | ICANON | ISIG | IEXTEN);
    t.c_cflag &= ~(tcflag_t)(PARENB | CSTOPB);
    t.c_cflag |= CS8 | CREAD | CLOCAL;
#ifdef CCTS_OFLOW
    t.c_cflag &= ~(tcflag_t)CCTS_OFLOW;
#endif
    t.c_cc[VMIN] = 0; t.c_cc[VTIME] = 0;
    cfsetispeed(&t, 115200); cfsetospeed(&t, 115200);
    tcsetattr(fd, TCSANOW, &t);
    speed_t sp = 6000000;
    if (ioctl(fd, IOSSIOSPEED, &sp) == 0) printf("IOSSIOSPEED 6000000 OK\n");
    else printf("IOSSIOSPEED errno=%d\n", errno);
    int m = 0;
    if (ioctl(fd, TIOCMGET, &m) == 0)
        printf("modem: CTS=%d DSR=%d DCD=%d\n", !!(m & TIOCM_CTS), !!(m & TIOCM_DSR), !!(m & TIOCM_CAR));
    m |= TIOCM_RTS | TIOCM_DTR;
    ioctl(fd, TIOCMSET, &m);
    uint8_t reset[4] = { 0x01, 0x03, 0x0C, 0x00 };
    int wrote = 0;
    for (int a = 0; a < 5 && !wrote; a++) {
        ssize_t w = write(fd, reset, 4);
        printf("write a%d = %zd errno=%d\n", a, w, errno);
        if (w == 4) wrote = 1;
        else usleep(20000);
    }
    int total = 0;
    for (int r = 0; r < 30; r++) {
        fd_set rf; FD_ZERO(&rf); FD_SET(fd, &rf);
        struct timeval tv = { 0, 200000 };
        int rv = select(fd + 1, &rf, NULL, NULL, &tv);
        if (rv <= 0) { if (total && r > 5) break; continue; }
        uint8_t buf[256];
        ssize_t n = read(fd, buf, sizeof(buf));
        if (n > 0) {
            total += (int)n;
            printf("rx[%d]:", (int)n);
            for (ssize_t i = 0; i < n; i++) printf(" %02X", buf[i]);
            printf("\n");
        }
    }
    if (!total) printf("chip silent after takeover\n");
    else printf(">>> CHIP RESPONDED (%d bytes) <<<\n", total);
    close(fd);
    printf("UP3-DONE\n");
    return 0;
}
