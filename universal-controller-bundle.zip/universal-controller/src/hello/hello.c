#include <stdio.h>
int main(void){ printf("HELLO-ALIVE\n"); return 0; }
