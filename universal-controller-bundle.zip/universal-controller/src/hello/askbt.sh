#!/var/jb/bin/sh
/var/root/restart_up4.sh > /dev/null 2>&1
sleep 1
timeout 3 sh -c 'printf "help\r\n" > /var/root/btcmd'
sleep 2
timeout 3 sh -c 'printf "help\n" > /var/root/btcmd'
sleep 2
echo "--- log:"
tail -50 /var/mobile/Documents/up3.log
