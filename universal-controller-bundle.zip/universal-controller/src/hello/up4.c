/* up4 v2 — BlueTool wrapper + REMOTE CONTROL, write(2) logging only. */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <termios.h>
#include <stdarg.h>
#include <signal.h>
#include <sys/select.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <sys/stat.h>
#ifndef IOSSIOSPEED
#define IOSSIOSPEED _IOW('T', 38, speed_t)
#endif
#define P "/dev/uart.bluetooth"
static int LOGFD = -1;
static void L(const char *fmt, ...) {
    if (LOGFD < 0) return;
    char b[1024];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(b, sizeof(b), fmt, ap);
    va_end(ap);
    if (n > 0) { ssize_t w = write(LOGFD, b, (size_t)n); (void)w; }
}
static void takeover(void) {
    L("=== TAKEOVER BEGIN ===\n");
    int fd = open(P, O_RDWR | O_NONBLOCK);
    if (fd < 0) { L("takeover open errno=%d\n=== FAIL ===\n", errno); return; }
    L("takeover open OK fd=%d\n", fd);
    struct termios t;
    tcgetattr(fd, &t);
    t.c_iflag &= ~(tcflag_t)(IGNBRK | BRKINT | PARMRK | ISTRIP | INLCR | IGNCR | ICRNL | IXON | IXOFF | IXANY);
    t.c_oflag &= ~(tcflag_t)OPOST;
    t.c_lflag &= ~(tcflag_t)(ECHO | ECHONL | ICANON | ISIG | IEXTEN);
    t.c_cflag &= ~(tcflag_t)(PARENB | CSTOPB);
    t.c_cflag |= CS8 | CREAD | CLOCAL;
#ifdef CCTS_OFLOW
    t.c_cflag &= ~(tcflag_t)CCTS_OFLOW;
#endif
    t.c_cc[VMIN] = 0; t.c_cc[VTIME] = 0;
    cfsetispeed(&t, 115200); cfsetospeed(&t, 115200);
    tcsetattr(fd, TCSANOW, &t);
    speed_t sp = 6000000;
    if (ioctl(fd, IOSSIOSPEED, &sp) == 0) L("IOSSIOSPEED 6000000 OK\n"); else L("IOSSIOSPEED errno=%d\n", errno);
    int m = 0;
    if (ioctl(fd, TIOCMGET, &m) == 0)
        L("modem: CTS=%d DSR=%d DCD=%d\n", !!(m & TIOCM_CTS), !!(m & TIOCM_DSR), !!(m & TIOCM_CAR));
    m |= TIOCM_RTS | TIOCM_DTR;
    ioctl(fd, TIOCMSET, &m);
    uint8_t reset[4] = { 0x01, 0x03, 0x0C, 0x00 };
    int wrote = 0;
    for (int a = 0; a < 5 && !wrote; a++) {
        ssize_t w = write(fd, reset, 4);
        L("write a%d = %zd errno=%d\n", a, w, errno);
        if (w == 4) wrote = 1; else usleep(20000);
    }
    int total = 0;
    for (int r = 0; r < 40; r++) {
        fd_set rf;
        FD_ZERO(&rf);
        FD_SET(fd, &rf);
        struct timeval tv = { 0, 200000 };
        int rv = select(fd + 1, &rf, NULL, NULL, &tv);
        if (rv <= 0) { if (total && r > 6) break; continue; }
        uint8_t buf[256];
        ssize_t n = read(fd, buf, sizeof(buf));
        if (n > 0) {
            total += (int)n;
            L("rx[%d]:", (int)n);
            for (ssize_t i = 0; i < n; i++) { char hb[8]; snprintf(hb, 8, " %02X", buf[i]); L("%s", hb); }
            L("\n");
        }
    }
    if (total) L(">>> CHIP RESPONDED (%d bytes) <<<\n", total);
    else L("chip silent after takeover\n");
    close(fd);
    L("=== TAKEOVER END ===\n");
}
int main(void) {
    LOGFD = open("/var/mobile/Documents/up3.log", O_WRONLY | O_CREAT | O_TRUNC, 0644);
    chown("/var/mobile/Documents/up3.log", 501, 501);
    L("up4 v2 write2 wrapper pid=%d\n", getpid());
    unlink("/var/root/btcmd");
    if (mkfifo("/var/root/btcmd", 0666) != 0) L("mkfifo errno=%d\n", errno);
    chmod("/var/root/btcmd", 0666);
    int pp[2];
    if (pipe(pp) != 0) { L("pipe errno=%d\n", errno); return 1; }
    pid_t pid = fork();
    if (pid == 0) {
        dup2(pp[0], 0);
        dup2(LOGFD, 1);   /* child replies -> same log */
        dup2(LOGFD, 2);
        close(pp[0]);
        close(pp[1]);
        char *argv[] = { "/usr/sbin/BlueTool", NULL };
        execv(argv[0], argv);
        L("EXEC_FAIL BlueTool errno=%d\n", errno);
        _exit(127);
    }
    close(pp[0]);
    L("child BlueTool pid=%d; fifo ready (SEIZE = takeover)\n", pid);
    int ffd = -1;
    int st = 0;
    for (;;) {
        pid_t r = waitpid(pid, &st, WNOHANG);
        if (r == pid) { L("BlueTool exited (status=0x%x)\n", st); break; }
        if (ffd < 0) ffd = open("/var/root/btcmd", O_RDONLY | O_NONBLOCK);
        if (ffd >= 0) {
            char buf[512];
            ssize_t n = read(ffd, buf, sizeof(buf));
            if (n > 0) {
                L("fifo->BlueTool: %.*s", (int)n, buf);
                if (n >= 5 && memcmp(buf, "SEIZE", 5) == 0) {
                    L("SEIZE — killing BlueTool\n");
                    kill(pid, SIGKILL);
                } else {
                    ssize_t w = write(pp[1], buf, n);
                    (void)w;
                }
            } else if (n == 0) {
                close(ffd);
                ffd = -1;
            }
        }
        usleep(50000);
    }
    takeover();
    L("UP4-DONE\n");
    return 0;
}
