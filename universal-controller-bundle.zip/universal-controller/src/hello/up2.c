/* uartprobe — bounded UART diagnostic, every syscall has a timeout.
   Answers: does write() block? what do modem lines say? does the chip
   ever answer at any baud/flow combo? Prints everything. */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <termios.h>
#include <sys/select.h>
#include <sys/ioctl.h>
#define P "/dev/uart.bluetooth"
#ifndef IOSSIOSPEED
#define IOSSIOSPEED _IOW('T', 38, speed_t)
#endif
static int set_raw(int fd, int baud, int hwflow) {
    struct termios t;
    if (tcgetattr(fd, &t) != 0) return -1;
    /* manual raw mode — cfmakeraw is absent in the iOS 14.5 SDK */
    t.c_iflag &= ~(tcflag_t)(IGNBRK | BRKINT | PARMRK | ISTRIP | INLCR | IGNCR | ICRNL | IXON | IXOFF | IXANY);
    t.c_oflag &= ~(tcflag_t)OPOST;
    t.c_lflag &= ~(tcflag_t)(ECHO | ECHONL | ICANON | ISIG | IEXTEN);
    t.c_cflag &= ~(tcflag_t)(PARENB | CSTOPB);
    t.c_cflag |= CS8 | CREAD | CLOCAL;
#ifdef CCTS_OFLOW
    if (hwflow) t.c_cflag |= CCTS_OFLOW; else t.c_cflag &= ~(tcflag_t)CCTS_OFLOW;
#endif
    t.c_cc[VMIN] = 0; t.c_cc[VTIME] = 0;
    cfsetispeed(&t, 115200); cfsetospeed(&t, 115200);
    if (tcsetattr(fd, TCSANOW, &t) != 0) return -1;
    speed_t sp = (speed_t)baud;
    return ioctl(fd, IOSSIOSPEED, &sp); /* Apple extension: any baud, no SDK limits */
}
static const char *bn(int b) {
    switch (b) {
        case 115200: return "B115200";
        case 921600: return "B921600";
        case 3000000: return "B3000000";
        default: return "?";
    }
}
static int g_bauds[8];
static int g_nbauds = 0;
int main(int argc, char **argv) {
    setvbuf(stdout, NULL, _IONBF, 0);
    printf("uartprobe 1.3 (pid=%d)\n", getpid());
    static const int allb[] = { 6000000, 4000000, 3000000, 2000000, 1000000, 921600, 115200 };
    if (argc > 1) { /* fast mode: single baud from argv */
        for (int i = 1; i < argc && g_nbauds < 8; i++) g_bauds[g_nbauds++] = atoi(argv[i]);
    } else {
        for (size_t i = 0; i < sizeof(allb)/sizeof(allb[0]); i++) g_bauds[g_nbauds++] = allb[i];
    }
    const int *bauds = g_bauds;
    static const uint8_t reset[4] = { 0x01, 0x03, 0x0C, 0x00 };
    for (int bi = 0; bi < g_nbauds; bi++) {
        for (int fl = 0; fl < 1; fl++) { /* hwflow=on is EOPNOTSUPP on this driver — single pass */
            printf("\n=== %s hwflow=%s ===\n", bn(bauds[bi]), fl ? "on" : "off");
            int fd = open(P, O_RDWR | O_NONBLOCK);
            if (fd < 0) { printf("open errno=%d\n", errno); continue; }
            if (set_raw(fd, bauds[bi], fl) != 0) printf("tcsetattr errno=%d\n", errno);
            /* modem lines */
            int m = 0;
            if (ioctl(fd, TIOCMGET, &m) == 0)
                printf("modem: RTS=%d DTR=%d CTS=%d DSR=%d DCD=%d RNG=%d\n",
                    !!(m & TIOCM_RTS), !!(m & TIOCM_DTR), !!(m & TIOCM_CTS),
                    !!(m & TIOCM_DSR), !!(m & TIOCM_CAR), !!(m & TIOCM_RNG));
            else printf("TIOCMGET errno=%d\n", errno);
            /* force assert RTS+DTR (host says: I am ready) */
            m |= TIOCM_RTS | TIOCM_DTR;
            if (ioctl(fd, TIOCMSET, &m) == 0) {
                usleep(100000);
                int m2 = 0;
                if (ioctl(fd, TIOCMGET, &m2) == 0)
                    printf("after RTS|DTR assert: CTS=%d DSR=%d DCD=%d\n",
                        !!(m2 & TIOCM_CTS), !!(m2 & TIOCM_DSR), !!(m2 & TIOCM_CAR));
            } else printf("TIOCMSET errno=%d\n", errno);
            /* bounded write attempts */
            int wrote = 0;
            for (int a = 1; a <= 6 && !wrote; a++) {
                fd_set wf; FD_ZERO(&wf); FD_SET(fd, &wf);
                struct timeval tv = { 0, 500000 };
                int rv = select(fd + 1, NULL, &wf, NULL, &tv);
                if (rv <= 0) { printf("write-try %d: select=%d errno=%d\n", a, rv, errno); continue; }
                ssize_t w = write(fd, reset, 4);
                printf("write-try %d: wrote=%zd errno=%d\n", a, w, errno);
                if (w == 4) wrote = 1;
                else if (w < 0 && errno != EAGAIN && errno != EWOULDBLOCK) break;
            }
            if (!wrote) { printf("WRITE BLOCKED/FAILED at this combo\n"); close(fd); continue; }
            /* bounded read, hexdump everything */
            int total = 0;
            for (int r = 0; r < 20; r++) {
                fd_set rf; FD_ZERO(&rf); FD_SET(fd, &rf);
                struct timeval tv = { 0, 300000 };
                int rv = select(fd + 1, &rf, NULL, NULL, &tv);
                if (rv <= 0) { if (total == 0 && r > 4) break; else if (total) break; continue; }
                uint8_t buf[256];
                ssize_t n = read(fd, buf, sizeof(buf));
                if (n > 0) {
                    total += (int)n;
                    printf("rx[%d]:", (int)n);
                    for (ssize_t i = 0; i < n; i++) printf(" %02X", buf[i]);
                    printf("\n");
                }
            }
            if (total == 0) printf("no bytes received (chip silent at this combo)\n");
            close(fd);
            usleep(200000);
        }
    }
    printf("\nPROBE-DONE\n");
    return 0;
}
