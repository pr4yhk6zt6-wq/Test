#import <UIKit/UIKit.h>
#import "CAAppDelegate.h"
#import <signal.h>
#import <execinfo.h>

/* In-app crash journal: an uncaught NSException or fatal signal is appended to
   Documents/ControllerA-crash.txt so a crash is recoverable WITHOUT .ips files
   (Filza/TrollStore-readable). Best-effort: signal handlers are async-signal
   unsafe by nature; we keep to a fixed static buffer + write(). */

static char crash_path_buf[512];
static int crash_path_ready = 0;

static void ca_append_text(const char *text) {
    if (!crash_path_ready) {
        NSString *docs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
        if (!docs) return;
        NSString *p = [docs stringByAppendingPathComponent:@"ControllerA-crash.txt"];
        strncpy(crash_path_buf, p.fileSystemRepresentation, sizeof(crash_path_buf) - 1);
        crash_path_ready = 1;
    }
    int fd = open(crash_path_buf, O_WRONLY | O_CREAT | O_APPEND, 0644);
    if (fd < 0) return;
    write(fd, text, strlen(text));
    close(fd);
}

static void ca_uncaught(NSException *exception) {
    NSMutableString *s = [NSMutableString stringWithFormat:
        @"[%@] UNCAUGHT EXCEPTION %@\nreason: %@\ncallStack:\n",
        [NSDate date], exception.name, exception.reason ?: @"(none)"];
    for (NSString *f in exception.callStackSymbols) [s appendFormat:@"  %@\n", f];
    [s appendString:@"\n"];
    ca_append_text(s.UTF8String);
}

static void ca_signal_handler(int sig) {
    static const char msg[] = "FATAL SIGNAL (see .ips for backtrace)\n";
    /* minimal async-signal-safe-ish report */
    char buf[64];
    int n = snprintf(buf, sizeof(buf), "[%ld] SIGNAL %d — ", (long)time(NULL), sig);
    int fd = open(crash_path_buf, O_WRONLY | O_CREAT | O_APPEND, 0644);
    if (fd >= 0) {
        void *bt[32];
        int frames = backtrace(bt, 32);
        write(fd, buf, (size_t)n);
        write(fd, msg, sizeof(msg) - 1);
        backtrace_symbols_fd(bt, frames, fd);
        close(fd);
    }
    /* re-raise so the system still generates the standard .ips */
    signal(sig, SIG_DFL);
    raise(sig);
}

int main(int argc, char *argv[]) {
    NSSetUncaughtExceptionHandler(ca_uncaught);
    signal(SIGABRT, ca_signal_handler);
    signal(SIGSEGV, ca_signal_handler);
    signal(SIGBUS,  ca_signal_handler);
    signal(SIGILL,  ca_signal_handler);
    signal(SIGTRAP, ca_signal_handler);
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CAAppDelegate class]));
    }
}
