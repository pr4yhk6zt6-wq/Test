#import "CAAppDelegate.h"
#import "GamepadViewController.h"
#import "InputManager.h"
#import "Transports/UDPTransport.h"
#import "Transports/UDSTransport.h"
#import "BT/CBProbe.h"

@interface CAAppDelegate ()
@property (strong, nonatomic) UDPTransport *udp;
@property (strong, nonatomic) UDSTransport *uds;
@property (strong, nonatomic) CBProbe *probe;
@end

@implementation CAAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    GamepadViewController *vc = [[GamepadViewController alloc] init];
    self.window.rootViewController = vc;
    [self.window makeKeyAndVisible];

    [[InputManager shared] start];

    self.udp = [[UDPTransport alloc] init];
    [self.udp start];
    self.uds = [[UDSTransport alloc] init];
    [self.uds start];
    self.probe = [[CBProbe alloc] init];

    __weak typeof(self) wself = self;
    vc.udpTransport = self.udp;
    vc.settingsHandler = ^(NSString *host, uint16_t port) {
        [wself.udp setHost:host port:port];
    };
    vc.bleProbeHandler = ^{
        [wself.probe runHOGPProbe];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [wself.probe runCustomServiceProbe];
        });
    };

    return YES;
}

@end
