#import "CBProbe.h"

static NSMutableString *cbLog;

@implementation CBProbe {
    CBPeripheralManager *_pm;
    CBCentralManager *_cm;
    BOOL _phaseHID;
    BOOL _phaseCustom;
    BOOL _pmRequested;
    NSDate *_pmRequestedAt;
    CBMutableCharacteristic *_reportChar;
    NSMutableDictionary<CBUUID *, NSData *> *_readValues; /* served via didReceiveReadRequest */
}

+ (void)initialize {
    if (self == [CBProbe class]) cbLog = [NSMutableString new];
}

+ (NSString *)logText { return [cbLog copy]; }

+ (void)clearLog { [cbLog setString:@""]; }

+ (NSString *)crashJournalText {
    NSString *docs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
    NSString *p = [docs stringByAppendingPathComponent:@"ControllerA-crash.txt"];
    return [NSString stringWithContentsOfFile:p encoding:NSUTF8StringEncoding error:nil] ?: @"";
}

- (void)log:(NSString *)fmt, ... NS_FORMAT_FUNCTION(1,2) {
    va_list args;
    va_start(args, fmt);
    NSString *s = [[NSString alloc] initWithFormat:fmt arguments:args];
    va_end(args);
    NSString *line = [NSString stringWithFormat:@"[%@] %@\n",
        [NSDateFormatter localizedStringFromDate:[NSDate date] dateStyle:NSDateFormatterNoStyle timeStyle:NSDateFormatterMediumStyle], s];
    dispatch_async(dispatch_get_main_queue(), ^{
        if (cbLog.length > 12000) [cbLog deleteCharactersInRange:NSMakeRange(0, 6000)];
        [cbLog appendString:line];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"CBProbeLogChanged" object:nil];
        NSLog(@"CBProbe: %@", s);
    });
}

+ (NSString *)authName:(CBManagerAuthorization)a {
    switch (a) {
        case CBManagerAuthorizationNotDetermined: return @"notDetermined(0)";
        case CBManagerAuthorizationAllowedAlways: return @"allowed(1)";
        case CBManagerAuthorizationDenied:        return @"denied(2)";
        case CBManagerAuthorizationRestricted:    return @"restricted(3)";
        default: return [NSString stringWithFormat:@"?(%ld)", (long)a];
    }
}

- (void)ensureManagers {
    if (_pmRequested) {
        [self log:@"managers already requested (pm.state=%ld cm.state=%ld)", (long)_pm.state, (long)_cm.state];
        return;
    }
    _pmRequested = YES;
    _pmRequestedAt = [NSDate date];
    _readValues = [NSMutableDictionary new];

    /* authorization BEFORE creating managers — class property, does not prompt */
    [self log:@"CBManager.authorization (pre-init) = %@",
        [CBProbe authName:[CBManager authorization]]];

    @try {
        _pm = [[CBPeripheralManager alloc] initWithDelegate:self queue:nil];
        [self log:@"CBPeripheralManager init (state=%ld)", (long)_pm.state];
    } @catch (NSException *e) {
        [self log:@"!!! CBPeripheralManager init THREW: %@ — %@\n%@",
            e.name, e.reason ?: @"(no reason)", e.callStackSymbols ?: @[]];
        return;
    }
    @try {
        _cm = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
        [self log:@"CBCentralManager init (state=%ld) [cross-check]", (long)_cm.state];
    } @catch (NSException *e) {
        [self log:@"!!! CBCentralManager init THREW: %@ — %@", e.name, e.reason ?: @"(no reason)"];
    }

    /* watchdog: stock resolves <1 s; THIS device observed ~5-6 s (E18-log) — allow 15 s */
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(15 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self stuckCheck];
    });
}

- (void)stuckCheck {
    if (!_pm || _pm.state != CBManagerStateUnknown) return;
    [self log:@"VERDICT: state STILL Unknown after 15 s — bluetoothd handshake never completed (slow-but-successful ~5-6 s already observed on this device, so this is beyond normal)."];
    [self log:@"Candidates: (H1) daemon/TCC cannot resolve TrollStore-permasigned identity — prompt never shown; (H2) jailbreak TCC/tweak swallows prompt; (H3) usage keys invisible to daemon; crash (if any) needs .ips."];
    [self log:@"USER CHECKS: Settings > Privacy & Security > Bluetooth — is ControllerA listed? Toggle BT off/on and retry. Re-jailbreak and retry. Then pull .ips: run 'idiag -c' as root."];
    NSString *journal = [CBProbe crashJournalText];
    if (journal.length) [self log:@"--- in-app crash journal ---\n%@", journal];
}

- (void)runHOGPProbe {
    _phaseHID = YES;
    [self log:@"--- PROBE 1: HID-over-GATT (0x1812) publish test (v2) ---"];
    [self ensureManagers];
    if (_pm.state == CBManagerStatePoweredOn) [self addHIDService];
}

- (void)runCustomServiceProbe {
    _phaseCustom = YES;
    [self log:@"--- PROBE 2: custom 128-bit service advertise test ---"];
    [self ensureManagers];
    if (_pm.state == CBManagerStatePoweredOn) [self addCustomService];
}

- (void)peripheralManagerDidUpdateState:(CBPeripheralManager *)peripheral {
    @try {
        [self log:@"PM state -> %ld (auth=%@) cm.state=%ld cm.auth=%@",
            (long)peripheral.state,
            [CBProbe authName:[CBManager authorization]],
            _cm ? (long)_cm.state : -1L,
            [CBProbe authName:[CBManager authorization]]];
        if (peripheral.state == CBManagerStatePoweredOn) {
            if (_phaseHID) [self addHIDService];
            if (_phaseCustom) [self addCustomService];
        }
    } @catch (NSException *e) {
        [self log:@"!!! PM didUpdateState THREW: %@ — %@\n%@", e.name, e.reason ?: @"", e.callStackSymbols ?: @[]];
    }
}

- (void)centralManagerDidUpdateState:(CBCentralManager *)central {
    [self log:@"CM state -> %ld (cross-check; %ld == poweredOn)",
        (long)central.state, (long)CBManagerStatePoweredOn];
}

- (NSData *)gamepadReportMap {
    static const uint8_t map[] = {
        0x05, 0x01, 0x09, 0x05, 0xA1, 0x01, 0xA1, 0x00,
        0x85, 0x01,
        0x09, 0x30, 0x09, 0x31, 0x09, 0x32, 0x09, 0x35,
        0x15, 0x81, 0x25, 0x7F, 0x75, 0x08, 0x95, 0x04, 0x81, 0x02,
        0x09, 0x39, 0x15, 0x00, 0x25, 0x07, 0x35, 0x00, 0x46, 0x3B, 0x01, 0x65, 0x14,
        0x75, 0x04, 0x95, 0x01, 0x81, 0x42, 0x65, 0x00,
        0x75, 0x04, 0x95, 0x01, 0x81, 0x01,
        0x05, 0x09, 0x19, 0x01, 0x29, 0x10,
        0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x10, 0x81, 0x02,
        0xC0, 0xC0
    };
    return [NSData dataWithBytes:map length:sizeof(map)];
}

/* ROOT-CAUSE FIX (device evidence E19): CoreBluetooth requires that a
   characteristic created WITH a cached value be read-only. v1/v2 cached a
   value in 2A4E (Protocol Mode) while granting write →
   NSInternalInconsistencyException at addService = the v1 "mid-air crash".
   Now: every characteristic is created with value:nil and all reads are
   served dynamically from _readValues. */
- (void)addHIDService {
    CBUUID *svcID = [CBUUID UUIDWithString:@"1812"];
    CBMutableService *svc = [[CBMutableService alloc] initWithType:svcID primary:YES];

    _readValues[[CBUUID UUIDWithString:@"2A4B"]] = [self gamepadReportMap];
    _readValues[[CBUUID UUIDWithString:@"2A4A"]] = [NSData dataWithBytes:(uint8_t[]){0x01,0x01,0x00,0x02} length:4];
    _readValues[[CBUUID UUIDWithString:@"2A4E"]] = [NSData dataWithBytes:(uint8_t[]){0x01} length:1];

    CBMutableCharacteristic *reportMap =
        [[CBMutableCharacteristic alloc] initWithType:[CBUUID UUIDWithString:@"2A4B"]
                                           properties:CBCharacteristicPropertyRead
                                                value:nil
                                          permissions:CBAttributePermissionsReadEncryptionRequired];
    _reportChar =
        [[CBMutableCharacteristic alloc] initWithType:[CBUUID UUIDWithString:@"2A4D"]
                                           properties:CBCharacteristicPropertyRead | CBCharacteristicPropertyNotify
                                                value:nil
                                          permissions:CBAttributePermissionsReadEncryptionRequired];
    CBMutableCharacteristic *protoMode =
        [[CBMutableCharacteristic alloc] initWithType:[CBUUID UUIDWithString:@"2A4E"]
                                           properties:CBCharacteristicPropertyRead | CBCharacteristicPropertyWriteWithoutResponse
                                                value:nil
                                          permissions:CBAttributePermissionsReadable | CBAttributePermissionsWriteable];
    CBMutableCharacteristic *hidInfo =
        [[CBMutableCharacteristic alloc] initWithType:[CBUUID UUIDWithString:@"2A4A"]
                                           properties:CBCharacteristicPropertyRead
                                                value:nil
                                          permissions:CBAttributePermissionsReadable];
    CBMutableCharacteristic *ctrlPoint =
        [[CBMutableCharacteristic alloc] initWithType:[CBUUID UUIDWithString:@"2A4C"]
                                           properties:CBCharacteristicPropertyWriteWithoutResponse
                                                value:nil
                                          permissions:CBAttributePermissionsWriteable];

    svc.characteristics = @[reportMap, _reportChar, protoMode, hidInfo, ctrlPoint];
    [self log:@"publishing 0x1812 (5 characteristics, no cached values)..."];
    @try {
        [_pm addService:svc];
    } @catch (NSException *e) {
        [self log:@"!!! addService THREW: %@ — %@\n%@", e.name, e.reason ?: @"", e.callStackSymbols ?: @[]];
    }
}

- (void)addCustomService {
    CBUUID *svcID = [CBUUID UUIDWithString:@"8E400001-F315-4F60-9FB8-838830DAEA50"];
    CBMutableService *svc = [[CBMutableService alloc] initWithType:svcID primary:YES];
    CBMutableCharacteristic *ch =
        [[CBMutableCharacteristic alloc] initWithType:[CBUUID UUIDWithString:@"8E400002-F315-4F60-9FB8-838830DAEA50"]
                                           properties:CBCharacteristicPropertyRead | CBCharacteristicPropertyWriteWithoutResponse | CBCharacteristicPropertyNotify
                                                value:nil
                                          permissions:CBAttributePermissionsReadable | CBAttributePermissionsWriteable];
    svc.characteristics = @[ch];
    [_pm addService:svc];
}

- (void)peripheralManager:(CBPeripheralManager *)peripheral didAddService:(CBService *)service error:(NSError *)error {
    @try {
        NSString *uuid = service.UUID.UUIDString ?: @"?";
        if (error) {
            [self log:@"didAddService %@ FAILED: %@ (code=%ld) — %@", uuid,
                error.domain, (long)error.code, error.localizedDescription];
            if ([uuid isEqualToString:@"1812"]) {
                [self log:@"RESULT PROBE 1: 0x1812 BLOCKED on device (CBError 8) — E6 CONFIRMED on-device."];
                [self log:@"CONCLUSION: HID-over-GATT via public API = PROVEN BLOCKED (framework-level, entitlements do not help). Phase-3 proceeds on the chip-level HCI track only."];
                _phaseHID = NO;
            }
        } else {
            if ([uuid isEqualToString:@"1812"]) {
                [self log:@"RESULT PROBE 1: 0x1812 ACCEPTED on device — E6 does NOT hold here; BLE public-API track REOPENED!"];
            }
            [self log:@"didAddService %@ OK", uuid];
            [_pm startAdvertising:@{ CBAdvertisementDataLocalNameKey: @"ControllerA",
                                     CBAdvertisementDataServiceUUIDsKey: @[service.UUID] }];
            [self log:@"advertising '%@' as 'ControllerA' — check iPhone B Settings>Bluetooth.", uuid];
        }
    } @catch (NSException *e) {
        [self log:@"!!! didAddService THREW: %@ — %@", e.name, e.reason ?: @""];
    }
}

- (void)peripheralManagerDidStartAdvertising:(CBPeripheralManager *)peripheral error:(NSError *)error {
    if (error) [self log:@"startAdvertising FAILED: %@ (%ld)", error.localizedDescription, (long)error.code];
    else       [self log:@"advertising OK"];
}

- (void)peripheralManager:(CBPeripheralManager *)peripheral central:(CBCentral *)central didSubscribeToCharacteristic:(CBCharacteristic *)characteristic {
    [self log:@"central %@ subscribed %@", central.identifier.UUIDString, characteristic.UUID.UUIDString];
}
- (void)peripheralManager:(CBPeripheralManager *)peripheral central:(CBCentral *)central didUnsubscribeFromCharacteristic:(CBCharacteristic *)characteristic {
    [self log:@"central %@ unsubscribed", central.identifier.UUIDString];
}
- (void)peripheralManager:(CBPeripheralManager *)peripheral didReceiveReadRequest:(CBATTRequest *)request {
    NSData *v = _readValues[request.characteristic.UUID] ?: [NSData data];
    if (request.offset < v.length) {
        request.value = [v subdataWithRange:NSMakeRange(request.offset, v.length - request.offset)];
    } else {
        request.value = [NSData data];
    }
    [_pm respondToRequest:request withResult:CBATTErrorSuccess];
}
- (void)peripheralManager:(CBPeripheralManager *)peripheral didReceiveWriteRequests:(NSArray<CBATTRequest *> *)requests {
    for (CBATTRequest *r in requests) [_pm respondToRequest:r withResult:CBATTErrorSuccess];
}

@end
