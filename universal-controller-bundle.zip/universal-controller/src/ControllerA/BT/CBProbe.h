#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

/* CBProbe v2 — on-device evidence harness for the BLE tracks.
   v2 changes after the REAL-DEVICE bug report (T3, iOS 15.8.8/TrollStore):
   v1 observed: CBPeripheralManager init -> state stuck at Unknown(0) forever,
   no TCC prompt, then a delayed crash. v2 is instrumented to DISCRIMINATE
   between the candidate causes:
     H1 bluetoothd/TCC cannot resolve the TrollStore-permasigned app identity
        (prompt never shown, authorization never resolves)
     H2 jailbreak TCC/permission infrastructure swallows the prompt
     H3 Info.plist usage-description keys not visible to bluetoothd
     H4 separate defect (tweak conflict / CoreBluetooth exception) — needs .ips
   Evidence v2 collects:
     - CBManager.authorization BEFORE any manager exists (iOS 13.1+, no prompt)
     - CBCentralManager as a cross-check vs CBPeripheralManager
       (both stuck = XPC/daemon level; only peripheral stuck = role/TCC level)
     - 6 s stuck-watchdog with a verdict message + user-side checks
     - @try guards + in-app crash journal (Documents/ControllerA-crash.txt) */
@interface CBProbe : NSObject <CBPeripheralManagerDelegate, CBCentralManagerDelegate>
- (void)runHOGPProbe;            /* probe 1: peripheral manager + HID service (guarded) */
- (void)runCustomServiceProbe;   /* probe 2: custom 128-bit service + advertise        */
+ (NSString *)logText;
+ (void)clearLog;
+ (NSString *)crashJournalText;  /* in-app exception journal (may be empty) */
@end
