#import <UIKit/UIKit.h>

@interface DPadView : UIView
/* hat: 0..7 eight-way, 8 neutral; u/d/l/r booleans for button bits */
@property (nonatomic, copy) void (^onChange)(uint8_t hat, BOOL u, BOOL d, BOOL l, BOOL r);
@end
