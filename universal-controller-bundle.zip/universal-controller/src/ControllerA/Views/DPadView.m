#import "DPadView.h"

@implementation DPadView {
    BOOL _u, _d, _l, _r;
}

- (instancetype)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        self.backgroundColor = [UIColor clearColor];
        self.userInteractionEnabled = YES;
    }
    return self;
}

/* plus shape hit test */
- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event {
    CGFloat w = self.bounds.size.width, h = self.bounds.size.height;
    CGFloat arm = w * 0.34;
    BOOL inVertical = point.x > (w - arm) / 2 && point.x < (w + arm) / 2;
    BOOL inHorizontal = point.y > (h - arm) / 2 && point.y < (h + arm) / 2;
    return inVertical || inHorizontal;
}

- (int)zoneForPoint:(CGPoint)p {
    CGFloat w = self.bounds.size.width, h = self.bounds.size.height;
    CGFloat arm = w * 0.34;
    CGFloat x0 = (w - arm) / 2, x1 = (w + arm) / 2;
    CGFloat y0 = (h - arm) / 2, y1 = (h + arm) / 2;
    if (p.x >= x0 && p.x <= x1 && p.y < y0) return 0;          // up
    if (p.y >= y0 && p.y <= y1 && p.x > x1) return 2;          // right
    if (p.x >= x0 && p.x <= x1 && p.y > y1) return 4;          // down
    if (p.y >= y0 && p.y <= y1 && p.x < x0) return 6;          // left
    // diagonals: quadrant of corner space
    BOOL leftHalf = p.x < w / 2, topHalf = p.y < h / 2;
    if (leftHalf && topHalf) return 7;
    if (!leftHalf && topHalf) return 1;
    if (!leftHalf && !topHalf) return 3;
    return 5;
}

- (void)applyZone:(int)z {
    _u = _d = _l = _r = NO;
    switch (z) {
        case 0: _u = YES; break;
        case 1: _u = _r = YES; break;
        case 2: _r = YES; break;
        case 3: _d = _r = YES; break;
        case 4: _d = YES; break;
        case 5: _d = _l = YES; break;
        case 6: _l = YES; break;
        case 7: _l = _u = YES; break;
        default: break;
    }
    uint8_t hat = 8;
    if (_u && _r) hat = 1; else if (_r && _d) hat = 3; else if (_d && _l) hat = 5;
    else if (_l && _u) hat = 7; else if (_u) hat = 0; else if (_r) hat = 2;
    else if (_d) hat = 4; else if (_l) hat = 6;
    if (self.onChange) self.onChange(hat, _u, _d, _l, _r);
    [self setNeedsDisplay];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self applyZone:[self zoneForPoint:[touches.anyObject locationInView:self]]];
}
- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self applyZone:[self zoneForPoint:[touches.anyObject locationInView:self]]];
}
- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self applyZone:8];
}
- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self applyZone:8];
}

- (void)drawRect:(CGRect)rect {
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGFloat w = rect.size.width, h = rect.size.height;
    CGFloat arm = w * 0.34;
    CGFloat cx = w / 2, cy = h / 2;
    UIColor *idle = [UIColor colorWithWhite:1 alpha:0.12];
    UIColor *act = [UIColor colorWithWhite:1 alpha:0.55];
    CGContextSetLineWidth(ctx, 1.5);
    // up
    void (^armRect)(BOOL active, CGRect r) = ^(BOOL active, CGRect r) {
        CGContextSetFillColorWithColor(ctx, (active ? act : idle).CGColor);
        UIBezierPath *p = [UIBezierPath bezierPathWithRoundedRect:r cornerRadius:8];
        [p fill];
        CGContextSetStrokeColorWithColor(ctx, [UIColor colorWithWhite:1 alpha:0.3].CGColor);
        [p stroke];
    };
    armRect(_u, CGRectMake(cx - arm / 2, 0, arm, h / 2 + arm / 2));
    armRect(_d, CGRectMake(cx - arm / 2, cy - arm / 2, arm, h / 2 + arm / 2));
    armRect(_l, CGRectMake(0, cy - arm / 2, w / 2 + arm / 2, arm));
    armRect(_r, CGRectMake(cx - arm / 2, cy - arm / 2, w / 2 + arm / 2, arm));
    // center hub
    CGContextSetFillColorWithColor(ctx, [UIColor colorWithWhite:1 alpha:0.2].CGColor);
    [[UIBezierPath bezierPathWithOvalInRect:CGRectMake(cx - 8, cy - 8, 16, 16)] fill];
}

@end
