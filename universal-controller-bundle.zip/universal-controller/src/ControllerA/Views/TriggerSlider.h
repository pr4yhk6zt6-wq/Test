#import <UIKit/UIKit.h>

/* Vertical analog trigger (0 at bottom, 1 at top) */
@interface TriggerSlider : UIView
@property (nonatomic, copy) void (^onValue)(CGFloat v);
@property (nonatomic, readonly) CGFloat value;
- (instancetype)initWithFrame:(CGRect)frame label:(NSString *)label;
@end
