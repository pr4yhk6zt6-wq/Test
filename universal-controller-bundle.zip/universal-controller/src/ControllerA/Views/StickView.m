#import "StickView.h"

@interface StickView ()
@property (nonatomic, strong, readwrite) UIView *knob;
@end

@implementation StickView {
    CGFloat _radius;
}

- (instancetype)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        self.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.10];
        self.layer.cornerRadius = frame.size.width / 2.0;
        self.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.25].CGColor;
        self.layer.borderWidth = 1.5;
        self.userInteractionEnabled = YES;
        _radius = frame.size.width / 2.0 - 27;

        UIView *k = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 54, 54)];
        k.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.45];
        k.layer.cornerRadius = 27;
        k.userInteractionEnabled = NO;
        k.center = CGPointMake(frame.size.width / 2.0, frame.size.height / 2.0);
        self.knob = k;
        [self addSubview:k];
    }
    return self;
}

/* frame starts as CGRectZero — radius/corner must follow the FINAL frame */
- (void)layoutSubviews {
    [super layoutSubviews];
    self.layer.cornerRadius = self.bounds.size.width / 2.0;
    _radius = MAX(10.0, self.bounds.size.width / 2.0 - 27);
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self track:touches.anyObject];
}
- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self track:touches.anyObject];
}
- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self reset];
}
- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self reset];
}

- (void)track:(UITouch *)t {
    CGPoint p = [t locationInView:self];
    CGFloat dx = p.x - self.bounds.size.width / 2.0;
    CGFloat dy = p.y - self.bounds.size.height / 2.0;
    CGFloat dist = sqrt(dx * dx + dy * dy);
    if (dist > _radius && dist > 0) {
        dx = dx / dist * _radius;
        dy = dy / dist * _radius;
    }
    self.knob.center = CGPointMake(self.bounds.size.width / 2.0 + dx, self.bounds.size.height / 2.0 + dy);
    CGFloat nx = _radius > 0 ? dx / _radius : 0;
    CGFloat ny = _radius > 0 ? -dy / _radius : 0;
    if (self.onMove) self.onMove(nx, ny);
}

- (void)reset {
    self.knob.center = CGPointMake(self.bounds.size.width / 2.0, self.bounds.size.height / 2.0);
    if (self.onMove) self.onMove(0, 0);
    if (self.onEnd) self.onEnd();
}

@end
