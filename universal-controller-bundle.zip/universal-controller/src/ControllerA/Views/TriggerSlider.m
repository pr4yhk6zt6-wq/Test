#import "TriggerSlider.h"

@implementation TriggerSlider {
    UIView *_fill;
    UILabel *_label;
}

- (instancetype)initWithFrame:(CGRect)frame label:(NSString *)label {
    if ((self = [super initWithFrame:frame])) {
        self.backgroundColor = [UIColor colorWithWhite:1 alpha:0.06];
        self.layer.cornerRadius = 6;
        self.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.25].CGColor;
        self.layer.borderWidth = 1;
        self.clipsToBounds = YES;
        self.userInteractionEnabled = YES;

        _fill = [[UIView alloc] initWithFrame:CGRectMake(0, frame.size.height, frame.size.width, 0)];
        _fill.backgroundColor = [UIColor colorWithWhite:1 alpha:0.35];
        _fill.autoresizingMask = UIViewAutoresizingFlexibleHeight;
        _fill.userInteractionEnabled = NO;
        [self addSubview:_fill];

        _label = [[UILabel alloc] initWithFrame:CGRectMake(0, 4, frame.size.width, 14)];
        _label.text = label;
        _label.font = [UIFont boldSystemFontOfSize:11];
        _label.textAlignment = NSTextAlignmentCenter;
        _label.textColor = [UIColor colorWithWhite:1 alpha:0.9];
        _label.userInteractionEnabled = NO;
        [self addSubview:_label];
    }
    return self;
}

- (CGFloat)value {
    return self.bounds.size.height > 0 ? (self.bounds.size.height - _fill.frame.origin.y) / self.bounds.size.height : 0;
}

- (void)setValueAt:(CGFloat)v {
    v = MAX(0, MIN(1, v));
    CGFloat h = self.bounds.size.height * v;
    _fill.frame = CGRectMake(0, self.bounds.size.height - h, self.bounds.size.width, h);
    if (self.onValue) self.onValue(v);
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self track:touches.anyObject];
}
- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self track:touches.anyObject];
}
- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self setValueAt:0];
    if (self.onValue) self.onValue(0);
}
- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self setValueAt:0];
    if (self.onValue) self.onValue(0);
}
- (void)track:(UITouch *)t {
    CGFloat y = [t locationInView:self].y;
    CGFloat v = 1.0 - y / self.bounds.size.height;
    [self setValueAt:v];
}

@end
