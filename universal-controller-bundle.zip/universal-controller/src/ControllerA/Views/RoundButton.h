#import <UIKit/UIKit.h>

@interface RoundButton : UIView
@property (nonatomic, copy) void (^onPress)(BOOL down);
@property (nonatomic, assign) BOOL pressed;
- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title;
@end
