#import "RoundButton.h"

@implementation RoundButton

- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title {
    if ((self = [super initWithFrame:frame])) {
        self.userInteractionEnabled = YES;
        self.layer.cornerRadius = MIN(frame.size.width, frame.size.height) / 2.0;
        self.layer.borderWidth = 1.5;
        self.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.50].CGColor;
        self.backgroundColor = [UIColor colorWithWhite:1 alpha:0.06];

        UILabel *l = [[UILabel alloc] initWithFrame:self.bounds];
        l.text = title;
        l.textAlignment = NSTextAlignmentCenter;
        l.font = [UIFont boldSystemFontOfSize:frame.size.width * 0.38];
        l.textColor = [UIColor colorWithWhite:1 alpha:0.85];
        l.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        l.userInteractionEnabled = NO;
        [self addSubview:l];
    }
    return self;
}

/* frames start as CGRectZero; radius+font must follow the FINAL frame */
- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat side = MIN(self.bounds.size.width, self.bounds.size.height);
    self.layer.cornerRadius = side / 2.0;
    for (UIView *v in self.subviews) {
        if ([v isKindOfClass:[UILabel class]]) {
            UILabel *l = (UILabel *)v;
            l.frame = self.bounds;
            l.font = [UIFont boldSystemFontOfSize:side * 0.36];
        }
    }
}

- (void)setPressed:(BOOL)pressed {
    _pressed = pressed;
    self.backgroundColor = pressed ? [UIColor colorWithWhite:1 alpha:0.45] : [UIColor colorWithWhite:1 alpha:0.10];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    self.pressed = YES;
    if (self.onPress) self.onPress(YES);
}
- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    self.pressed = NO;
    if (self.onPress) self.onPress(NO);
}
- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    self.pressed = NO;
    if (self.onPress) self.onPress(NO);
}

@end
