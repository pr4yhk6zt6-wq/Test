#import <UIKit/UIKit.h>

@interface StickView : UIView
@property (nonatomic, copy) void (^onMove)(CGFloat x, CGFloat y); /* -1..1, up = +1 */
@property (nonatomic, copy) void (^onEnd)(void);
@property (nonatomic, strong, readonly) UIView *knob;
@end
