#import "GamepadViewController.h"
#import "InputManager.h"
#import "Views/StickView.h"
#import "Views/DPadView.h"
#import "Views/RoundButton.h"
#import "Views/TriggerSlider.h"
#import "Transports/UDPTransport.h"
#import "Transports/UDSTransport.h"
#import "BT/CBProbe.h"

@interface GamepadViewController ()
@property (strong) StickView *stickL, *stickR;
@property (strong) DPadView *dpad;
@property (strong) RoundButton *btnA, *btnB, *btnX, *btnY, *btnL1, *btnR1, *btnMenu, *btnView;
@property (strong) TriggerSlider *trigL2, *trigR2;
@property (strong) UILabel *status, *stats;
@property (strong) UIButton *gear, *probeBtn;
@property (strong) UITextView *probeLog;
@property (strong) dispatch_source_t hudTimer;
@end

@implementation GamepadViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithWhite:0.08 alpha:1];
    [self buildUI];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(logChanged:) name:@"CBProbeLogChanged" object:nil];

    self.hudTimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
    dispatch_source_set_timer(self.hudTimer, DISPATCH_TIME_NOW, 250 * NSEC_PER_MSEC, 100 * NSEC_PER_MSEC);
    __weak typeof(self) wself = self;
    dispatch_source_set_event_handler(self.hudTimer, ^{
        [wself refreshHUD];
    });
    dispatch_resume(self.hudTimer);
}

- (UIRectEdge)preferredScreenEdgesDeferringSystemGestures { return UIRectEdgeAll; }
- (BOOL)prefersStatusBarHidden { return YES; }
- (BOOL)prefersHomeIndicatorAutoHidden { return YES; }

- (void)buildUI {
    CGFloat W = 100, H = 100; /* relative percentages resolved in layout */

    self.stickL = [[StickView alloc] initWithFrame:CGRectZero];
    self.stickR = [[StickView alloc] initWithFrame:CGRectZero];
    __weak typeof(self) wself = self;
    self.stickL.onMove = ^(CGFloat x, CGFloat y) { [[InputManager shared] setLeftStickX:x y:y]; };
    self.stickR.onMove = ^(CGFloat x, CGFloat y) { [[InputManager shared] setRightStickX:x y:y]; };
    [self.view addSubview:self.stickL];
    [self.view addSubview:self.stickR];

    self.dpad = [[DPadView alloc] initWithFrame:CGRectZero];
    self.dpad.onChange = ^(uint8_t hat, BOOL u, BOOL d, BOOL l, BOOL r) {
        [[InputManager shared] setDPadUp:u down:d left:l right:r];
    };
    [self.view addSubview:self.dpad];

    RoundButton *(^mkBtn)(NSString *, uint8_t) = ^RoundButton *(NSString *title, uint8_t mask) {
        RoundButton *b = [[RoundButton alloc] initWithFrame:CGRectZero title:title];
        b.onPress = ^(BOOL down) { [[InputManager shared] setButtonMaskA:mask on:down]; };
        [wself.view addSubview:b];
        return b;
    };
    self.btnA = mkBtn(@"A", IC_BTN_A);
    self.btnB = mkBtn(@"B", IC_BTN_B);
    self.btnX = mkBtn(@"X", IC_BTN_X);
    self.btnY = mkBtn(@"Y", IC_BTN_Y);
    self.btnL1 = mkBtn(@"L1", IC_BTN_L1);
    self.btnR1 = mkBtn(@"R1", IC_BTN_R1);
    self.btnMenu = mkBtn(@"≡", IC_BTN_MENU);
    self.btnView = mkBtn(@"⊟", IC_BTN_VIEW);

    self.trigL2 = [[TriggerSlider alloc] initWithFrame:CGRectZero label:@"L2"];
    self.trigR2 = [[TriggerSlider alloc] initWithFrame:CGRectZero label:@"R2"];
    self.trigL2.onValue = ^(CGFloat v) { [[InputManager shared] setTriggersL2:v r2:[wself trigR2].value]; };
    self.trigR2.onValue = ^(CGFloat v) { [[InputManager shared] setTriggersL2:[wself trigL2].value r2:v]; };
    [self.view addSubview:self.trigL2];
    [self.view addSubview:self.trigR2];

    self.status = [[UILabel alloc] initWithFrame:CGRectZero];
    self.status.textAlignment = NSTextAlignmentCenter;
    self.status.textColor = [UIColor colorWithWhite:1 alpha:0.9];
    self.status.font = [UIFont monospacedDigitSystemFontOfSize:11 weight:UIFontWeightMedium];
    [self.view addSubview:self.status];

    self.stats = [[UILabel alloc] initWithFrame:CGRectZero];
    self.stats.textAlignment = NSTextAlignmentCenter;
    self.stats.textColor = [UIColor colorWithWhite:1 alpha:0.6];
    self.stats.font = [UIFont monospacedDigitSystemFontOfSize:9 weight:UIFontWeightRegular];
    [self.view addSubview:self.stats];

    self.gear = [UIButton buttonWithType:UIButtonTypeSystem];
    [self.gear setTitle:@"UDP" forState:UIControlStateNormal];
    self.gear.tintColor = [UIColor whiteColor];
    self.gear.titleLabel.font = [UIFont boldSystemFontOfSize:11];
    [self.gear addTarget:self action:@selector(openSettings) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.gear];

    self.probeBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [self.probeBtn setTitle:@"BLE" forState:UIControlStateNormal];
    self.probeBtn.tintColor = [UIColor whiteColor];
    self.probeBtn.titleLabel.font = [UIFont boldSystemFontOfSize:11];
    [self.probeBtn addTarget:self action:@selector(runProbe) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.probeBtn];

    self.probeLog = [[UITextView alloc] init];
    self.probeLog.backgroundColor = [UIColor colorWithWhite:0 alpha:0.85];
    self.probeLog.textColor = [UIColor greenColor];
    self.probeLog.font = [UIFont monospacedSystemFontOfSize:9 weight:UIFontWeightRegular];
    self.probeLog.hidden = YES;
    self.probeLog.editable = NO;
    [self.view addSubview:self.probeLog];

    (void)W; (void)H;
    [self viewDidLayoutSubviews];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    CGFloat W = self.view.bounds.size.width, H = self.view.bounds.size.height;
    if (W < H) return; /* portrait not supported */

    CGFloat u = H / 100.0; /* unit */

    self.stickL.frame  = CGRectMake(W * 0.245, H * 0.42, 15 * u * 1.6, 15 * u * 1.6);
    self.stickR.frame  = CGRectMake(W * 0.615, H * 0.42, 15 * u * 1.6, 15 * u * 1.6);

    CGFloat dpadSize = 13 * u;
    self.dpad.frame = CGRectMake(W * 0.045, H * 0.38, dpadSize, dpadSize);

    /* face buttons as a proper diamond: A right, B bottom, X top, Y left */
    CGFloat bs = 6.8 * u;
    CGFloat cx = W * 0.858, cy = H * 0.52, d = bs * 1.05;
    void (^place)(RoundButton *, CGFloat, CGFloat) = ^(RoundButton *b, CGFloat px, CGFloat py) {
        b.frame = CGRectMake(px - bs / 2, py - bs / 2, bs, bs);
    };
    place(self.btnA, cx + d, cy);
    place(self.btnB, cx, cy + d);
    place(self.btnX, cx, cy - d);
    place(self.btnY, cx - d, cy);

    self.btnL1.frame = CGRectMake(W * 0.10, 2 * u, 9 * u, 4.6 * u);
    self.btnR1.frame = CGRectMake(W * 0.90 - 9 * u, 2 * u, 9 * u, 4.6 * u);
    self.trigL2.frame = CGRectMake(W * 0.015, 2 * u, 3.6 * u, 9 * u);
    self.trigR2.frame = CGRectMake(W * 0.985 - 3.6 * u, 2 * u, 3.6 * u, 9 * u);

    self.btnMenu.frame = CGRectMake(W / 2 - 7.5 * u, 3 * u, 5.6 * u, 5.6 * u);
    self.btnView.frame = CGRectMake(W / 2 + 2.2 * u, 3 * u, 5.6 * u, 5.6 * u);

    self.status.frame = CGRectMake(W * 0.25, H * 0.885, W * 0.5, 3 * u);
    self.stats.frame  = CGRectMake(W * 0.05, H * 0.925, W * 0.9, 2 * u);
    self.gear.frame   = CGRectMake(W * 0.5 - 13 * u, 4 * u, 6 * u, 4 * u);
    self.probeBtn.frame = CGRectMake(W * 0.5 + 7 * u, 4 * u, 6 * u, 4 * u);
    self.probeLog.frame = CGRectMake(W * 0.12, H * 0.10, W * 0.76, H * 0.72);
}

- (void)openSettings {
    UIAlertController *a = [UIAlertController alertControllerWithTitle:@"UDP lab target"
                                                               message:@"host:port for the ds4bridge echo/relay (diagnostic only)"
                                                        preferredStyle:UIAlertControllerStyleAlert];
    [a addTextFieldWithConfigurationHandler:^(UITextField *tf) { tf.text = self.udpTransport.host; tf.placeholder = @"192.168.1.50"; }];
    [a addTextFieldWithConfigurationHandler:^(UITextField *tf) { tf.text = @(self.udpTransport.port).stringValue; tf.placeholder = @"37564"; }];
    __weak typeof(self) wself = self;
    [a addAction:[UIAlertAction actionWithTitle:@"Save" style:UIAlertActionStyleDefault handler:^(UIAlertAction *act) {
        NSString *host = a.textFields[0].text ?: @"";
        uint16_t port = (uint16_t)(a.textFields[1].text.intValue ?: 37564);
        if (wself.settingsHandler) wself.settingsHandler(host, port);
    }]];
    [a addAction:[UIAlertAction actionWithTitle:@"Close" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:a animated:YES completion:nil];
}

- (void)runProbe {
    self.probeLog.hidden = NO;
    self.probeLog.text = [CBProbe logText];
    [CBProbe clearLog];
    if (self.bleProbeHandler) self.bleProbeHandler();
}

- (void)logChanged:(NSNotification *)n {
    self.probeLog.text = [CBProbe logText];
    NSRange r = NSMakeRange(self.probeLog.text.length, 0);
    [self.probeLog scrollRangeToVisible:r];
}

- (void)refreshHUD {
    InputManager *im = [InputManager shared];
    UDPTransport *u = self.udpTransport;
    NSString *udpState = u && u.active
        ? [NSString stringWithFormat:@"UDP→%@:%u rtt %.0fms avg %.0fms", u.host, u.port, u.lastRttMs, u.avgRttMs]
        : @"UDP idle";
    self.status.text = [NSString stringWithFormat:@"%@ · pkts %u seq %u", udpState, im.sentPackets, [InputManager seq16]];
    self.stats.text = [NSString stringWithFormat:@"uds: %@ · dpad/13btn · 120Hz", [UDSTransport socketPath]];
}

@end
