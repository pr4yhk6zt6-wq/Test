#!/bin/sh
# package-ipa.sh — reproducible IPA packaging for ControllerA (rule 21/22).
# Build first:  make -j2   (Theos). Then run this script from src/ControllerA.
set -e
export THEOS=${THEOS:-/home/user/.cache/theos}
APP=.theos/obj/debug/ControllerA.app
[ -f "$APP/ControllerA" ] || { echo "binary missing — run make first"; exit 1; }

# Info.plist (kept in-repo so TrollStore receives exact keys — includes both
# NSBluetoothAlwaysUsageDescription (iOS 13+) and the legacy peripheral key)
cat > "$APP/Info.plist" <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>CFBundleDevelopmentRegion</key><string>en</string>
	<key>CFBundleDisplayName</key><string>ControllerA</string>
	<key>CFBundleExecutable</key><string>ControllerA</string>
	<key>CFBundleIdentifier</key><string>com.research.controllera</string>
	<key>CFBundleInfoDictionaryVersion</key><string>6.0</string>
	<key>CFBundleName</key><string>ControllerA</string>
	<key>CFBundlePackageType</key><string>APPL</string>
	<key>CFBundleShortVersionString</key><string>0.3.2</string>
	<key>CFBundleVersion</key><string>5</string>
	<key>MinimumOSVersion</key><string>15.0</string>
	<key>NSBluetoothAlwaysUsageDescription</key><string>ControllerA uses Bluetooth to act as a game controller for another device.</string>
	<key>NSBluetoothPeripheralUsageDescription</key><string>ControllerA uses Bluetooth to act as a game controller for another device.</string>
	<key>UIBackgroundModes</key>
	<array>
		<string>bluetooth-central</string>
		<string>bluetooth-peripheral</string>
	</array>
	<key>UIRequiresFullScreen</key><true/>
	<key>UISupportedInterfaceOrientations</key>
	<array>
		<string>UIInterfaceOrientationLandscapeLeft</string>
		<string>UIInterfaceOrientationLandscapeRight</string>
	</array>
	<key>UIStatusBarHidden</key><true/>
</dict>
</plist>
EOF

"$THEOS/bin/ldid" -S "$APP/ControllerA"
rm -rf Payload
mkdir Payload
cp -r "$APP" Payload/
OUT=../../artifacts/ControllerA.ipa
rm -f "$OUT"
zip -qry "$OUT" Payload
echo "packaged: $OUT"
unzip -l "$OUT"
