#import "InputManager.h"
#import <os/log.h>

uint16_t ic_crc16(const uint8_t *data, size_t len) {
    uint16_t crc = 0xFFFF;
    for (size_t i = 0; i < len; i++) {
        crc ^= (uint16_t)(data[i] << 8);
        for (int b = 0; b < 8; b++) {
            crc = (crc & 0x8000) ? (uint16_t)((crc << 1) ^ 0x1021) : (uint16_t)(crc << 1);
        }
    }
    return crc;
}

static uint32_t ic_uptime_ms(void) {
    static struct timespec start;
    static BOOL haveStart = NO;
    if (!haveStart) {
        clock_gettime(CLOCK_MONOTONIC, &start);
        haveStart = YES;
    }
    struct timespec now;
    clock_gettime(CLOCK_MONOTONIC, &now);
    return (uint32_t)((now.tv_sec - start.tv_sec) * 1000 + (now.tv_nsec - start.tv_nsec) / 1000000);
}

static inline int8_t ic_scale(CGFloat v, CGFloat deadzone) {
    CGFloat m = fabs(v);
    if (m <= deadzone) return 0;
    CGFloat s = (m - deadzone) / (1.0 - deadzone);
    if (s > 1.0) s = 1.0;
    return (int8_t)lround((v < 0 ? -s : s) * 127.0);
}

@interface InputManager ()
@property (nonatomic, strong) dispatch_queue_t queue;
@property (nonatomic, strong) dispatch_source_t timer;
@property (nonatomic, strong) NSMutableArray *handlers;
@property (nonatomic, assign) uint32_t sentPackets;
@property (nonatomic, assign) uint16_t seq;
@property (nonatomic, assign) uint32_t lastActivityMs;
@property (nonatomic, assign) uint8_t mA, mB;
@property (nonatomic, assign) CGPoint l, r;
@property (nonatomic, assign) float tl2, tr2;
@property (nonatomic, assign) BOOL dU, dD, dL, dR;
@end

@implementation InputManager

+ (instancetype)shared {
    static InputManager *s;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ s = [[InputManager alloc] init]; });
    return s;
}

- (instancetype)init {
    if ((self = [super init])) {
        _queue = dispatch_queue_create("com.research.controllera.input", DISPATCH_QUEUE_SERIAL);
        _handlers = [NSMutableArray new];
        _l = CGPointMake(0, 0);
        _r = CGPointMake(0, 0);
        _seq = 0;
        _mA = 0; _mB = 0;
        _lastActivityMs = 0;
    }
    return self;
}

- (void)touch {
    dispatch_async(self.queue, ^{ self->_lastActivityMs = ic_uptime_ms(); });
}

- (void)setLeftStickX:(CGFloat)x y:(CGFloat)y {
    dispatch_async(self.queue, ^{
        self.l = CGPointMake(MAX(-1, MIN(1, x)), MAX(-1, MIN(1, y)));
        [self touch];
    });
}
- (void)setRightStickX:(CGFloat)x y:(CGFloat)y {
    dispatch_async(self.queue, ^{
        self.r = CGPointMake(MAX(-1, MIN(1, x)), MAX(-1, MIN(1, y)));
        [self touch];
    });
}
- (void)setDPadUp:(BOOL)up down:(BOOL)down left:(BOOL)left right:(BOOL)right {
    dispatch_async(self.queue, ^{
        self.dU = up; self.dD = down; self.dL = left; self.dR = right;
        [self touch];
    });
}
- (void)setButtonMaskA:(uint8_t)mask on:(BOOL)on {
    dispatch_async(self.queue, ^{
        if (on) self.mA |= mask; else self.mA &= ~mask;
        [self touch];
    });
}
- (void)setTriggersL2:(CGFloat)l2 r2:(CGFloat)r2 {
    dispatch_async(self.queue, ^{
        self.tl2 = MAX(0, MIN(1, l2));
        self.tr2 = MAX(0, MIN(1, r2));
        [self touch];
    });
}

+ (uint16_t)seq16 { return [InputManager shared]->_seq; }
- (uint8_t)buttonMaskA { return self->_mA; }
- (uint8_t)buttonMaskB { return self->_mB; }
- (CGPoint)leftStick { return self->_l; }
- (CGPoint)rightStick { return self->_r; }
- (float)triggerL2 { return self->_tl2; }
- (float)triggerR2 { return self->_tr2; }

- (void)addTickHandler:(void (^)(const ICInputPacket *))handler {
    dispatch_async(self.queue, ^{ [self.handlers addObject:handler]; });
}

- (void)start {
    dispatch_async(self.queue, ^{
        self->_timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, self->_queue);
        dispatch_source_set_timer(self->_timer, DISPATCH_TIME_NOW, (uint64_t)(1000 / 120.0) * NSEC_PER_MSEC, 2 * NSEC_PER_MSEC);
        dispatch_source_set_event_handler(self->_timer, ^{ [self emit]; });
        dispatch_resume(self->_timer);
    });
}

- (void)emit {
    uint32_t now = ic_uptime_ms();
    BOOL stale = (now - _lastActivityMs) > IC_STALE_MS;

    uint8_t bA = stale ? 0 : _mA;
    uint8_t bB = stale ? 0 : _mB;
    CGFloat lx = stale ? 0 : _l.x, ly = stale ? 0 : _l.y;
    CGFloat rx = stale ? 0 : _r.x, ry = stale ? 0 : _r.y;
    float tl2 = stale ? 0 : _tl2, tr2 = stale ? 0 : _tr2;

    uint8_t hat = IC_HAT_NEUTRAL;
    BOOL u = stale ? NO : _dU, d = stale ? NO : _dD, l = stale ? NO : _dL, r = stale ? NO : _dR;
    if (!stale) {
        if (u && r) hat = 1; else if (r && d) hat = 3; else if (d && l) hat = 5;
        else if (l && u) hat = 7; else if (u) hat = 0; else if (r) hat = 2;
        else if (d) hat = 4; else if (l) hat = 6;
    }
    if (!stale) {
        if (u) bB |= IC_BTN_DUP;
        if (d) bB |= IC_BTN_DDOWN;
        if (l) bB |= IC_BTN_DLEFT;
        if (r) bB |= IC_BTN_DRIGHT;
    }

    ICInputPacket p;
    memset(&p, 0, sizeof(p));
    p.magic = IC_MAGIC;
    p.version = IC_VERSION;
    p.buttonsA = bA;
    p.buttonsB = bB;
    p.lx = ic_scale(lx, 0.12);
    p.ly = ic_scale(ly, 0.12);
    p.rx = ic_scale(rx, 0.12);
    p.ry = ic_scale(ry, 0.12);
    p.l2 = (uint8_t)lround(tl2 * 255.0);
    p.r2 = (uint8_t)lround(tr2 * 255.0);
    p.hat = hat;
    _seq++;
    p.seq8 = (uint8_t)(_seq & 0xFF);
    p.seq16 = _seq & 0xFFFF;
    p.t_ms = now;
    p.crc = ic_crc16((const uint8_t *)&p, offsetof(ICInputPacket, crc));
    p.reserved = 0;

    _sentPackets++;
    for (void (^h)(const ICInputPacket *) in _handlers) h(&p);
}

- (uint32_t)sentPackets { return self->_sentPackets; }

@end
