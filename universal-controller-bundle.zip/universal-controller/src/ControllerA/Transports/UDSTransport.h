#import <Foundation/Foundation.h>

/* Unix-domain-socket transport to the (future, Phase-3) ds4bridged daemon.
   Path: /var/mobile/Library/ControllerA/ds4bridge.sock
   The app only acts as a client; the daemon owns the socket. */
@interface UDSTransport : NSObject
+ (NSString *)socketPath;   /* human-readable path for UI/status */
- (void)start;
- (void)stop;
- (void)sendPacket:(const void *)pkt len:(size_t)len;
@property (nonatomic, readonly) BOOL connected;
@end
