#import "UDPTransport.h"
#import "../InputManager.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <fcntl.h>

static NSString * const kUDPHost = @"controllera.udp.host";
static NSString * const kUDPPort = @"controllera.udp.port";
#define UDP_DEFAULT_PORT 37564

@interface UDPTransport ()
@property (nonatomic, assign) int fd;
@property (nonatomic, strong) dispatch_queue_t q;
@property (nonatomic, strong) dispatch_source_t timer;
@property (nonatomic, copy) NSString *host;
@property (nonatomic, assign) uint16_t port;
@property (nonatomic, assign) struct sockaddr_in dest;
@property (nonatomic, assign) BOOL haveDest;
@property (nonatomic, assign) double lastRtt;
@property (nonatomic, assign) double rttSum;
@property (nonatomic, assign) uint32_t rttN;
@property (nonatomic, assign) uint32_t ackCount;
@property (nonatomic, strong) NSMutableDictionary *inFlight; /* seq16 -> sendTimeMs */
@property (nonatomic, assign) BOOL running;
@end

@implementation UDPTransport

- (instancetype)init {
    if ((self = [super init])) {
        _fd = -1;
        _host = [[NSUserDefaults standardUserDefaults] objectForKey:kUDPHost] ?: @"";
        _port = (uint16_t)[[[NSUserDefaults standardUserDefaults] objectForKey:kUDPPort] ?: @(UDP_DEFAULT_PORT) intValue];
        _q = dispatch_queue_create("com.research.controllera.udp", DISPATCH_QUEUE_SERIAL);
        _inFlight = [NSMutableDictionary new];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(pump:) name:@"ICUDPTick" object:nil];
    }
    return self;
}

- (void)dealloc { [self stop]; }

- (NSString *)host { return self->_host; }
- (uint16_t)port { return self->_port; }
- (double)lastRttMs { return self->_lastRtt; }
- (double)avgRttMs { return self->_rttN ? self->_rttSum / self->_rttN : 0; }
- (uint32_t)acks { return self->_ackCount; }
- (BOOL)active { return self->_haveDest; }

- (void)setHost:(NSString *)host port:(uint16_t)port {
    dispatch_async(self->_q, ^{
        self->_host = [host copy];
        self->_port = port;
        [[NSUserDefaults standardUserDefaults] setObject:self->_host forKey:kUDPHost];
        [[NSUserDefaults standardUserDefaults] setObject:@(port) forKey:kUDPPort];
        self->_haveDest = NO;
        if (self->_host.length) {
            struct addrinfo hints, *res = NULL;
            memset(&hints, 0, sizeof(hints));
            hints.ai_family = AF_INET;
            hints.ai_socktype = SOCK_DGRAM;
            char portStr[8];
            snprintf(portStr, sizeof(portStr), "%u", port);
            if (getaddrinfo(self->_host.UTF8String, portStr, &hints, &res) == 0 && res) {
                memcpy(&self->_dest, res->ai_addr, MIN(sizeof(self->_dest), res->ai_addrlen));
                self->_haveDest = YES;
            }
            if (res) freeaddrinfo(res);
        }
    });
}

- (void)start {
    dispatch_async(self->_q, ^{
        self->_fd = socket(AF_INET, SOCK_DGRAM, 0);
        int fl = fcntl(self->_fd, F_GETFL, 0);
        fcntl(self->_fd, F_SETFL, fl | O_NONBLOCK);
        struct sockaddr_in local;
        memset(&local, 0, sizeof(local));
        local.sin_family = AF_INET;
        local.sin_addr.s_addr = htonl(INADDR_ANY);
        local.sin_port = 0;
        bind(self->_fd, (struct sockaddr *)&local, sizeof(local));
        self->_running = YES;
        self->_timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, self->_q);
        dispatch_source_set_timer(self->_timer, DISPATCH_TIME_NOW, 16 * NSEC_PER_MSEC, 4 * NSEC_PER_MSEC);
        dispatch_source_set_event_handler(self->_timer, ^{ [self pump:nil]; });
        dispatch_resume(self->_timer);
    });
}

- (void)stop {
    dispatch_async(self->_q, ^{
        if (self->_timer) { dispatch_source_cancel(self->_timer); self->_timer = nil; }
        if (self->_fd >= 0) { close(self->_fd); self->_fd = -1; }
        self->_running = NO;
    });
}

- (void)sendPacket:(const void *)pkt len:(size_t)len {
    if (!self->_haveDest || self->_fd < 0) return;
    const ICInputPacket *p = (const ICInputPacket *)pkt;
    if (p->magic == IC_MAGIC) {
        self->_inFlight[@(p->seq16)] = @(p->t_ms);
        if (self->_inFlight.count > 512) {
            NSArray *keys = self->_inFlight.allKeys;
            for (NSUInteger i = 0; i < 256; i++) [self->_inFlight removeObjectForKey:keys[i]];
        }
    }
    sendto(self->_fd, pkt, len, 0, (struct sockaddr *)&self->_dest, sizeof(self->_dest));
}

- (void)pump:(NSNotification *)n {
    if (!self->_running) return;
    /* drain echo replies */
    uint8_t buf[256];
    struct sockaddr_in from;
    socklen_t fl = sizeof(from);
    ssize_t r;
    while ((r = recvfrom(self->_fd, buf, sizeof(buf), 0, (struct sockaddr *)&from, &fl)) > 0) {
        if ((size_t)r >= sizeof(ICInputPacket)) {
            ICInputPacket *p = (ICInputPacket *)buf;
            if (p->magic == IC_MAGIC_RPLY) {
                NSNumber *sent = self->_inFlight[@(p->seq16)];
                if (sent) {
                    struct timespec ts;
                    clock_gettime(CLOCK_MONOTONIC, &ts);
                    uint32_t now = (uint32_t)(ts.tv_sec * 1000 + ts.tv_nsec / 1000000);
                    double rtt = (double)(now - sent.unsignedIntValue);
                    if (rtt >= 0 && rtt < 5000) {
                        self->_lastRtt = rtt;
                        self->_rttSum += rtt;
                        self->_rttN++;
                        self->_ackCount++;
                    }
                    [self->_inFlight removeObjectForKey:@(p->seq16)];
                }
            }
        }
        fl = sizeof(from);
    }
}

@end
