#import "UDSTransport.h"
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <fcntl.h>

#define UDS_PATH "/var/mobile/Library/ControllerA/ds4bridge.sock"

@interface UDSTransport ()
@property (nonatomic, assign) int fd;
@property (nonatomic, assign) BOOL conn;
@property (nonatomic, strong) dispatch_queue_t q;
@property (nonatomic, strong) dispatch_source_t retryTimer;
@end

@implementation UDSTransport

+ (NSString *)socketPath { return @UDS_PATH; }

- (instancetype)init {
    if ((self = [super init])) {
        _fd = -1;
        _q = dispatch_queue_create("com.research.controllera.uds", DISPATCH_QUEUE_SERIAL);
    }
    return self;
}
- (void)dealloc { [self stop]; }
- (BOOL)connected { return self->_conn; }

- (void)start {
    dispatch_async(self->_q, ^{
        self->_retryTimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, self->_q);
        dispatch_source_set_timer(self->_retryTimer, DISPATCH_TIME_NOW, 5 * NSEC_PER_SEC, 1 * NSEC_PER_SEC);
        dispatch_source_set_event_handler(self->_retryTimer, ^{ [self tryConnect]; });
        dispatch_resume(self->_retryTimer);
        [self tryConnect];
    });
}

- (void)stop {
    dispatch_async(self->_q, ^{
        if (self->_retryTimer) { dispatch_source_cancel(self->_retryTimer); self->_retryTimer = nil; }
        [self closeSock];
    });
}

- (void)closeSock {
    if (self->_fd >= 0) { close(self->_fd); self->_fd = -1; }
    self->_conn = NO;
}

- (void)tryConnect {
    if (self->_conn) return;
    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (fd < 0) return;
    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, UDS_PATH, sizeof(addr.sun_path) - 1);
    if (connect(fd, (struct sockaddr *)&addr, sizeof(addr)) == 0) {
        int fl = fcntl(fd, F_GETFL, 0);
        fcntl(fd, F_SETFL, fl | O_NONBLOCK);
        self->_fd = fd;
        self->_conn = YES;
    } else {
        close(fd);
    }
}

- (void)sendPacket:(const void *)pkt len:(size_t)len {
    dispatch_async(self->_q, ^{
        if (!self->_conn) return;
        ssize_t r = write(self->_fd, pkt, len);
        if (r < 0 && (errno == EPIPE || errno == ECONNRESET || errno == ENOTCONN)) [self closeSock];
    });
}

@end
