#import <Foundation/Foundation.h>

/* UDP lab transport — diagnostic instrument, NOT the product path to iPhone B.
   Sends ICInputPacket datagrams to a configurable host, receives 'ICRT' echo
   replies and measures RTT (for latency instrumentation per requirement 27). */
@interface UDPTransport : NSObject
- (instancetype)init;
- (void)start;
- (void)stop;
- (void)setHost:(NSString *)host port:(uint16_t)port;
- (NSString *)host;
- (uint16_t)port;
- (void)sendPacket:(const void *)pkt len:(size_t)len;
@property (nonatomic, readonly) double lastRttMs;
@property (nonatomic, readonly) double avgRttMs;
@property (nonatomic, readonly) uint32_t acks;
@property (nonatomic, readonly) BOOL active;
@end
