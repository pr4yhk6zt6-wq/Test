#import <UIKit/UIKit.h>

@class UDPTransport;

@interface GamepadViewController : UIViewController
@property (nonatomic, strong) UDPTransport *udpTransport;
@property (nonatomic, copy) void (^settingsHandler)(NSString *host, uint16_t port);
@property (nonatomic, copy) void (^bleProbeHandler)(void);
@end
