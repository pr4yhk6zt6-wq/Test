#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

// Wire format shared with ds4bridge (see src/ds4bridge/include/ds4bridge/ic_packet.h)
#define IC_MAGIC      0x4943544Cu /* 'ICTL' */
#define IC_MAGIC_RPLY 0x49435452u /* 'ICRT' echo reply */
#define IC_VERSION    1

#pragma pack(push, 1)
typedef struct {
    uint32_t magic;
    uint8_t  version;
    uint8_t  buttonsA; /* A B X Y L1 R1 MENU VIEW */
    uint8_t  buttonsB; /* LS RS DU DD DL DR */
    int8_t   lx, ly, rx, ry;
    uint8_t  l2, r2;   /* 0..255 */
    uint8_t  hat;      /* 0..7 eight-way, 8 = neutral */
    uint8_t  seq8;
    uint16_t seq16;
    uint32_t t_ms;     /* ms since InputManager start */
    uint16_t crc;      /* CRC-16/CCITT-FALSE over bytes [0, offsetof(crc)) */
    uint16_t reserved;
} ICInputPacket; /* 25 bytes */

typedef struct {
    uint32_t magic;
    uint16_t seq16;
    uint32_t t_ms;
} ICAckPacket; /* 10 bytes */
#pragma pack(pop)

// buttonsA
#define IC_BTN_A     (1 << 0)
#define IC_BTN_B     (1 << 1)
#define IC_BTN_X     (1 << 2)
#define IC_BTN_Y     (1 << 3)
#define IC_BTN_L1    (1 << 4)
#define IC_BTN_R1    (1 << 5)
#define IC_BTN_MENU  (1 << 6)  /* Start / Menu      */
#define IC_BTN_VIEW  (1 << 7)  /* Select / Share    */
// buttonsB
#define IC_BTN_LS    (1 << 0)
#define IC_BTN_RS    (1 << 1)
#define IC_BTN_DUP   (1 << 2)
#define IC_BTN_DDOWN (1 << 3)
#define IC_BTN_DLEFT (1 << 4)
#define IC_BTN_DRIGHT (1 << 5)

#define IC_HAT_NEUTRAL 8
#define IC_STALE_MS 250

uint16_t ic_crc16(const uint8_t *data, size_t len);

@interface InputManager : NSObject
+ (instancetype)shared;

/* Raw control surface, all values normalised. sticks -1..1 (up = +1), triggers 0..1 */
- (void)setLeftStickX:(CGFloat)x y:(CGFloat)y;
- (void)setRightStickX:(CGFloat)x y:(CGFloat)y;
- (void)setDPadUp:(BOOL)up down:(BOOL)down left:(BOOL)left right:(BOOL)right;
- (void)setButtonMaskA:(uint8_t)mask on:(BOOL)on;
- (void)setTriggersL2:(CGFloat)l2 r2:(CGFloat)r2;

/* Current logical state (UI reads it for visuals) */
@property (nonatomic, readonly) uint8_t buttonMaskA;
@property (nonatomic, readonly) uint8_t buttonMaskB;
@property (nonatomic, readonly) CGPoint leftStick;
@property (nonatomic, readonly) CGPoint rightStick;
@property (nonatomic, readonly) float triggerL2;
@property (nonatomic, readonly) float triggerR2;

/* Engine */
- (void)start;                                     /* 120 Hz emit loop */
- (void)addTickHandler:(void (^)(const ICInputPacket *pkt))handler;
@property (nonatomic, readonly) uint32_t sentPackets;

+ (uint16_t)seq16;
@end
