#!/bin/sh
# package-ipa.sh — reproducible IPA packaging for ProbeBLE (E21 UUID-form probe).
# Build first:  make -j2   (Theos). Then run this script from src/ProbeBLE.
set -e
export THEOS=${THEOS:-/home/user/.cache/theos}
export PATH="$THEOS/bin:$PATH"
APP=.theos/obj/debug/ProbeBLE.app
[ -f "$APP/ProbeBLE" ] || { echo "binary missing — run make first"; exit 1; }

# Info.plist — same BT permission keys as ControllerA (iOS 13+ rule)
cat > "$APP/Info.plist" <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>CFBundleDevelopmentRegion</key><string>en</string>
	<key>CFBundleDisplayName</key><string>ProbeBLE</string>
	<key>CFBundleExecutable</key><string>ProbeBLE</string>
	<key>CFBundleIdentifier</key><string>com.research.probeble</string>
	<key>CFBundleInfoDictionaryVersion</key><string>6.0</string>
	<key>CFBundleName</key><string>ProbeBLE</string>
	<key>CFBundlePackageType</key><string>APPL</string>
	<key>CFBundleShortVersionString</key><string>0.1.0</string>
	<key>CFBundleVersion</key><string>1</string>
	<key>MinimumOSVersion</key><string>15.0</string>
	<key>NSBluetoothAlwaysUsageDescription</key><string>ProbeBLE tests whether iOS allows publishing an HID service with long-form (128-bit) UUIDs.</string>
	<key>NSBluetoothPeripheralUsageDescription</key><string>ProbeBLE tests HID service publish rules.</string>
	<key>UIBackgroundModes</key>
	<array>
		<string>bluetooth-peripheral</string>
	</array>
	<key>UIRequiresFullScreen</key><true/>
	<key>UISupportedInterfaceOrientations</key>
	<array>
		<string>UIInterfaceOrientationPortrait</string>
	</array>
</dict>
</plist>
EOF

"$THEOS/bin/ldid" -S "$APP/ProbeBLE"
rm -rf Payload
mkdir Payload
cp -r "$APP" Payload/
OUT=../../artifacts/ProbeBLE.ipa
rm -f "$OUT"
zip -qry "$OUT" Payload
echo "packaged: $OUT"
unzip -l "$OUT"
