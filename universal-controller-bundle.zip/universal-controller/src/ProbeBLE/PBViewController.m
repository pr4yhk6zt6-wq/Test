#import "PBViewController.h"

/* E21 probe — which UUID spellings does iOS reject at addService?
   Context: E20 proved the SHORT form "1812" is refused (CBError 8) on this
   device. External evidence (Bluetouch on App Store, HemiPad PR 2026, conath
   gist comments 2024) says modern iOS accepts the LONG form
   00001812-0000-1000-8000-00805F9B34FB; iOS 7/8 (2014) refused BOTH forms.
   On iOS 15.8.8 this is UNKNOWN -> this probe measures it.

   Lessons baked in from earlier rounds:
   - E19: characteristics with cached values must be read-only -> every
     characteristic is created value:nil; reads served dynamically via
     request.value = [v subdataWithRange:] (CBATTRequest.offset is readonly).
   - E20 messaging bug: the FAILED branch prints "ADD FAILED...", the OK
     branch prints "ADD OK..." — verified both sides match the condition. */

static NSString *const kLong = @"00001812-0000-1000-8000-00805F9B34FB";
static NSString *const kLong2A4B = @"00002A4B-0000-1000-8000-00805F9B34FB";
static NSString *const kLong2A4D = @"00002A4D-0000-1000-8000-00805F9B34FB";
static NSString *const kLong2A4E = @"00002A4E-0000-1000-8000-00805F9B34FB";
static NSString *const kLong2A4A = @"00002A4A-0000-1000-8000-00805F9B34FB";
static NSString *const kLong2908 = @"00002908-0000-1000-8000-00805F9B34FB";

@implementation PBViewController {
    CBPeripheralManager *_pm;
    UITextView *_log;
    NSMutableArray<UIButton *> *_btns;
    NSMutableDictionary<CBUUID *, NSData *> *_readValues;
    CBMutableCharacteristic *_reportChar;
    NSTimer *_reportTimer;
    uint8_t _counter;
    CBMutableService *_addedLongFull;
    BOOL _longFullAdded;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];
    _readValues = [NSMutableDictionary new];
    _btns = [NSMutableArray new];

    UILabel *title = [[UILabel alloc] init];
    title.text = @"ProbeBLE — E21 UUID-form probe";
    title.textColor = [UIColor cyanColor];
    title.font = [UIFont boldSystemFontOfSize:15];
    title.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:title];

    _log = [[UITextView alloc] init];
    _log.editable = NO;
    _log.backgroundColor = [UIColor colorWithWhite:0.08 alpha:1];
    _log.textColor = [UIColor greenColor];
    _log.font = [UIFont monospacedSystemFontOfSize:11 weight:UIFontWeightRegular];
    _log.layer.cornerRadius = 8;
    _log.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:_log];

    [self button:@"T1: add 1812 (SHORT form)" action:@selector(t1)];
    [self button:@"T2: add LONG-form 1812 (svc only)" action:@selector(t2)];
    [self button:@"T3: add LONG-form 1812 (full HOGP)" action:@selector(t3)];
    [self button:@"T4: add 1812 SHORT (full HOGP)" action:@selector(t4)];
    [self button:@"T5: advertise added services" action:@selector(t5)];
    [self button:@"T6: stop + copy log" action:@selector(t6)];

    [NSLayoutConstraint activateConstraints:@[
        [title.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:8],
        [title.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:14],
        [_log.topAnchor constraintEqualToAnchor:title.bottomAnchor constant:8],
        [_log.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:10],
        [_log.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-10],
    ]];
    // buttons row at bottom in two columns
    NSArray *btns = [_btns copy];
    for (int i = 0; i < (int)btns.count; i++) {
        UIButton *b = btns[i];
        [b.topAnchor constraintEqualToAnchor:_log.bottomAnchor constant:8 + (i / 2) * 46].active = YES;
        if (i % 2 == 0)
            [b.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:10].active = YES;
        else
            [b.leadingAnchor constraintEqualToAnchor:self.view.centerXAnchor constant:6].active = YES;
        [b.widthAnchor constraintEqualToAnchor:self.view.widthAnchor multiplier:0.46].active = YES;
        [b.heightAnchor constraintEqualToConstant:40].active = YES;
    }

    _pm = [[CBPeripheralManager alloc] initWithDelegate:self queue:nil];
    [self log:[NSString stringWithFormat:@"PM init state=%ld (poweredOn=%d, usually ~5-6s on this device — E19)",
        (long)_pm.state, _pm.state == CBManagerStatePoweredOn]];
}

- (UIButton *)button:(NSString *)t action:(SEL)a {
    UIButton *b = [UIButton buttonWithType:UIButtonTypeSystem];
    b.layer.borderColor = [UIColor cyanColor].CGColor;
    b.layer.borderWidth = 1;
    b.layer.cornerRadius = 8;
    b.tintColor = [UIColor cyanColor];
    b.titleLabel.font = [UIFont boldSystemFontOfSize:11];
    [b setTitle:t forState:UIControlStateNormal];
    [b addTarget:self action:a forControlEvents:UIControlEventTouchUpInside];
    b.translatesAutoresizingMaskIntoConstraints = NO;
    b.enabled = NO;
    [self.view addSubview:b];
    [_btns addObject:b];
    return b;
}

- (void)log:(NSString *)s {
    NSString *line = [NSString stringWithFormat:@"%@\n", s];
    dispatch_async(dispatch_get_main_queue(), ^{
        _log.text = [_log.text stringByAppendingString:line];
        NSRange r = NSMakeRange(_log.text.length, 0);
        [_log scrollRangeToVisible:r];
    });
    NSLog(@"ProbeBLE: %@", s);
}

- (void)setButtons:(BOOL)on {
    for (UIButton *b in _btns) b.enabled = on;
}

/* ---------- PM delegate ---------- */

- (void)peripheralManagerDidUpdateState:(CBPeripheralManager *)peripheral {
    if (peripheral.state == CBManagerStatePoweredOn) {
        [self log:@"PM poweredOn — buttons enabled"];
        [self setButtons:YES];
    } else {
        [self log:[NSString stringWithFormat:@"PM state=%ld", (long)peripheral.state]];
    }
}

- (void)peripheralManager:(CBPeripheralManager *)peripheral didAddService:(CBService *)service error:(NSError *)error {
    NSString *uuid = service.UUID.UUIDString;
    if (error != nil) {
        /* FAILED branch (E20 rule: branch text must match branch condition) */
        [self log:[NSString stringWithFormat:@"RESULT: addService %@ FAILED — %@ code=%ld (%@)",
            uuid, error.domain, (long)error.code, error.localizedDescription]];
    } else {
        /* OK branch */
        [self log:[NSString stringWithFormat:@"RESULT: addService %@ OK (published)", uuid]];
        if ([uuid isEqualToString:kLong] && _addedLongFull == (CBMutableService *)service) {
            _longFullAdded = YES;
            [self log:@"LONG-form full HOGP service is live on this device."];
        }
    }
}

- (void)peripheralManager:(CBPeripheralManager *)peripheral didReceiveReadRequest:(CBATTRequest *)request {
    NSData *v = _readValues[request.characteristic.UUID];
    if (v) {
        NSUInteger off = request.offset < v.length ? request.offset : v.length;
        request.value = [v subdataWithRange:NSMakeRange(off, v.length - off)];
    } else {
        request.value = [NSData data];
    }
    [peripheral respondToRequest:request withResult:CBATTErrorSuccess];
}

- (void)peripheralManager:(CBPeripheralManager *)peripheral didReceiveWriteRequests:(NSArray<CBATTRequest *> *)requests {
    for (CBATTRequest *r in requests) {
        [self log:[NSString stringWithFormat:@"WRITE %@ len=%lu: %@",
            r.characteristic.UUID.UUIDString, (unsigned long)r.value.length, r.value]];
    }
    for (CBATTRequest *r in requests)
        [peripheral respondToRequest:r withResult:CBATTErrorSuccess];
}

- (void)peripheralManager:(CBPeripheralManager *)peripheral central:(CBCentral *)central didSubscribeToCharacteristic:(CBCharacteristic *)characteristic {
    [self log:[NSString stringWithFormat:@"SUBSCRIBED %@ by %@", characteristic.UUID.UUIDString, central]];
    [_reportTimer invalidate];
    _reportTimer = [NSTimer timerWithTimeInterval:1.0 / 60.0 repeats:YES block:^(__unused NSTimer *t) {
        [self sendReport];
    }];
    [[NSRunLoop mainRunLoop] addTimer:_reportTimer forMode:NSRunLoopCommonModes];
}

- (void)peripheralManager:(CBPeripheralManager *)peripheral central:(CBCentral *)central didUnsubscribeFromCharacteristic:(CBCharacteristic *)characteristic {
    [self log:[NSString stringWithFormat:@"UNSUBSCRIBED %@", characteristic.UUID.UUIDString]];
    [_reportTimer invalidate];
    _reportTimer = nil;
}

- (void)sendReport {
    /* matches our T3 report map: reportID 1, X/Y/Z/RZ i8, hat 4-bit, 16 buttons */
    uint8_t rep[8] = { 0x01, 0, 0, 0, 0, 0x08, 0x00, 0x00 };
    rep[1] = (uint8_t)(_counter % 2 == 0 ? 0x30 : 0x00); /* wiggle X so the host visibly reacts */
    rep[6] = (uint8_t)(1u << (_counter % 16));
    _counter++;
    NSData *d = [NSData dataWithBytes:rep length:8];
    [_pm updateValue:d forCharacteristic:_reportChar onSubscribedCentrals:nil];
}

/* ---------- report map (gamepad) ---------- */

- (NSData *)gamepadReportMap {
    static const uint8_t map[] = {
        0x05, 0x01, 0x09, 0x05, 0xA1, 0x01, 0xA1, 0x00,
        0x85, 0x01,
        0x09, 0x30, 0x09, 0x31, 0x09, 0x32, 0x09, 0x35,
        0x15, 0x81, 0x25, 0x7F, 0x75, 0x08, 0x95, 0x04, 0x81, 0x02,
        0x09, 0x39, 0x15, 0x00, 0x25, 0x07, 0x35, 0x00, 0x46, 0x3B, 0x01, 0x65, 0x14,
        0x75, 0x04, 0x95, 0x01, 0x81, 0x42, 0x65, 0x00,
        0x75, 0x04, 0x95, 0x01, 0x81, 0x01,
        0x05, 0x09, 0x19, 0x01, 0x29, 0x10,
        0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x10, 0x81, 0x02,
        0xC0, 0xC0
    };
    return [NSData dataWithBytes:map length:sizeof(map)];
}

/* ---------- tests ---------- */

- (CBMutableService *)fullHOGPWithServiceUUID:(NSString *)svcStr longForm:(BOOL)longForm {
    CBUUID *svcID = [CBUUID UUIDWithString:svcStr];
    CBMutableService *svc = [[CBMutableService alloc] initWithType:svcID primary:YES];

    CBUUID *uB = [CBUUID UUIDWithString:(longForm ? kLong2A4B : @"2A4B")];
    CBUUID *uD = [CBUUID UUIDWithString:(longForm ? kLong2A4D : @"2A4D")];
    CBUUID *uE = [CBUUID UUIDWithString:(longForm ? kLong2A4E : @"2A4E")];
    CBUUID *uA = [CBUUID UUIDWithString:(longForm ? kLong2A4A : @"2A4A")];

    _readValues[uB] = [self gamepadReportMap];
    _readValues[uA] = [NSData dataWithBytes:(uint8_t[]){0x01, 0x01, 0x00, 0x02} length:4];
    _readValues[uE] = [NSData dataWithBytes:(uint8_t[]){0x01} length:1];

    CBMutableCharacteristic *reportMap =
        [[CBMutableCharacteristic alloc] initWithType:uB
                                           properties:CBCharacteristicPropertyRead
                                                value:nil
                                          permissions:CBAttributePermissionsReadEncryptionRequired];
    _reportChar =
        [[CBMutableCharacteristic alloc] initWithType:uD
                                           properties:CBCharacteristicPropertyRead | CBCharacteristicPropertyNotify
                                                value:nil
                                          permissions:CBAttributePermissionsReadEncryptionRequired];
    /* Report Reference descriptor {id=1, input=1} (HemiPad: hosts need it) */
    CBMutableDescriptor *rr =
        [[CBMutableDescriptor alloc] initWithType:[CBUUID UUIDWithString:(longForm ? kLong2908 : @"2908")]
                                            value:[NSData dataWithBytes:(uint8_t[]){0x01, 0x01} length:2]];
    _reportChar.descriptors = @[ rr ];

    CBMutableCharacteristic *proto =
        [[CBMutableCharacteristic alloc] initWithType:uE
                                           properties:CBCharacteristicPropertyRead | CBCharacteristicPropertyWriteWithoutResponse
                                                value:nil
                                          permissions:CBAttributePermissionsReadable | CBAttributePermissionsWriteable];
    CBMutableCharacteristic *info =
        [[CBMutableCharacteristic alloc] initWithType:uA
                                           properties:CBCharacteristicPropertyRead
                                                value:nil
                                          permissions:CBAttributePermissionsReadEncryptionRequired];

    svc.characteristics = @[ reportMap, _reportChar, proto, info ];
    return svc;
}

- (void)runAdd:(NSString *)label svc:(CBMutableService *)svc {
    [self log:[NSString stringWithFormat:@"--- %@: addService %@ ---", label, svc.UUID.UUIDString]];
    _addedLongFull = [svc.UUID.UUIDString isEqualToString:kLong] ? svc : nil;
    [_pm addService:svc];
}

- (void)t1 { [self runAdd:@"T1" svc:[[CBMutableService alloc] initWithType:[CBUUID UUIDWithString:@"1812"] primary:YES]]; }
- (void)t2 { [self runAdd:@"T2" svc:[[CBMutableService alloc] initWithType:[CBUUID UUIDWithString:kLong] primary:YES]]; }
- (void)t3 { [self runAdd:@"T3" svc:[self fullHOGPWithServiceUUID:kLong longForm:YES]]; }
- (void)t4 { [self runAdd:@"T4" svc:[self fullHOGPWithServiceUUID:@"1812" longForm:NO]]; }

- (void)t5 {
    NSMutableArray *uuids = [NSMutableArray new];
    for (UIButton *b in _btns) (void)b;
    [self log:@"--- T5: startAdvertising (LocalName=ProbeBLE + added svc UUIDs) ---"];
    [uuids addObject:[CBUUID UUIDWithString:kLong]];
    NSMutableDictionary *adv = [NSMutableDictionary new];
    adv[CBAdvertisementDataLocalNameKey] = @"ProbeBLE";
    adv[CBAdvertisementDataServiceUUIDsKey] = uuids;
    [_pm startAdvertising:adv];
    [self log:@"T5: startAdvertising called — check iPhone B > Settings > Bluetooth"];
}

- (void)t6 {
    [_pm stopAdvertising];
    [_reportTimer invalidate];
    UIPasteboard.generalPasteboard.string = _log.text;
    [self log:@"T6: advertising stopped; FULL LOG COPIED to clipboard — paste it to the chat."];
}

@end
