#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>

@interface PBViewController : UIViewController <CBPeripheralManagerDelegate>
@end
