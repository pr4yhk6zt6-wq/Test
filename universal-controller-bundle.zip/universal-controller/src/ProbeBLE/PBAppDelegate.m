#import "PBAppDelegate.h"
#import "PBViewController.h"

@implementation PBAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.rootViewController = [[PBViewController alloc] init];
    [self.window makeKeyAndVisible];
    return YES;
}

@end
