/* idiag — iPhone A device & jailbreak capability audit tool (rule 0 / 0.2)
   Builds for iOS 15 (arm64) with Theos, rootless (.deb via Procursus bootstrap).
   Run as root for full IOKit access:  sudo /var/jb/usr/bin/idiag
   Exit code 0 always; prints UNKNOWN for anything it cannot determine. */

#import <Foundation/Foundation.h>
#include <sys/sysctl.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#include <dlfcn.h>
#include <mach/mach.h>

#define UNK @"UNKNOWN"

static NSMutableString *out;

#define P(...) do { [out appendString:[NSString stringWithFormat:__VA_ARGS__]]; [out appendString:@"\n"]; } while (0)

static NSString *sysctlStr(NSString *name) {
    size_t len = 0;
    if (sysctlbyname(name.UTF8String, NULL, &len, NULL, 0) != 0 || len == 0) return UNK;
    char buf[512];
    if (len > sizeof(buf) - 1) len = sizeof(buf) - 1;
    if (sysctlbyname(name.UTF8String, buf, &len, NULL, 0) != 0) return UNK;
    return [NSString stringWithUTF8String:buf] ?: UNK;
}

static BOOL pathExists(const char *p) {
    struct stat st;
    return stat(p, &st) == 0;
}

/* ---------- IOKit (via dlsym; keep working without headers) ---------- */
typedef mach_port_t io_object_t;
typedef io_object_t io_iterator_t;
typedef io_object_t io_registry_entry_t;
typedef char io_name_t[128];
typedef kern_return_t (*fn_IORegistryGetRootEntry)(mach_port_t, io_registry_entry_t *);
typedef kern_return_t (*fn_IORegistryEntryGetChildEntry)(io_registry_entry_t, const char *, io_iterator_t *);
typedef kern_return_t (*fn_IOIteratorNext)(io_iterator_t, io_object_t *);
typedef kern_return_t (*fn_IOObjectGetClass)(io_object_t, io_name_t);
typedef kern_return_t (*fn_IOObjectRelease)(io_object_t);
typedef CFTypeRef (*fn_IORegistryEntryCreateCFProperty)(io_registry_entry_t, CFStringRef, CFAllocatorRef, uint32_t);
typedef kern_return_t (*fn_IORegistryEntryCreateCFProperties)(io_registry_entry_t, CFMutableDictionaryRef *, CFAllocatorRef, uint32_t);

static void *iokit = NULL;
static fn_IORegistryGetRootEntry pRoot;
static fn_IORegistryEntryGetChildEntry pChild;
static fn_IOIteratorNext pNext;
static fn_IOObjectGetClass pClass;
static fn_IOObjectRelease pRelease;
static fn_IORegistryEntryCreateCFProperty pProp;
static fn_IORegistryEntryCreateCFProperties pProps;

static BOOL loadIOKit(void) {
    iokit = dlopen("/System/Library/Frameworks/IOKit.framework/IOKit", RTLD_LAZY);
    if (!iokit) iokit = dlopen("/usr/lib/libIOKit.A.dylib", RTLD_LAZY);
    if (!iokit) return NO;
    pRoot   = (fn_IORegistryGetRootEntry)dlsym(iokit, "IORegistryGetRootEntry");
    pChild  = (fn_IORegistryEntryGetChildEntry)dlsym(iokit, "IORegistryEntryGetChildEntry");
    pNext   = (fn_IOIteratorNext)dlsym(iokit, "IOIteratorNext");
    pClass  = (fn_IOObjectGetClass)dlsym(iokit, "IOObjectGetClass");
    pRelease= (fn_IOObjectRelease)dlsym(iokit, "IOObjectRelease");
    pProp   = (fn_IORegistryEntryCreateCFProperty)dlsym(iokit, "IORegistryEntryCreateCFProperty");
    pProps  = (fn_IORegistryEntryCreateCFProperties)dlsym(iokit, "IORegistryEntryCreateCFProperties");
    return pRoot && pChild && pNext && pClass && pRelease && pProp;
}

static void dumpBTEntries(io_registry_entry_t node, int depth, int maxDepth, int *hits) {
    if (depth > maxDepth || *hits > 12) return;
    io_iterator_t iter = 0;
    if (pChild(node, "IOService", &iter) != KERN_SUCCESS) return;
    io_object_t child;
    while (pNext(iter, &child) == KERN_SUCCESS && *hits <= 12) {
        io_name_t cls = {0};
        pClass(child, cls);
        NSString *c = [NSString stringWithUTF8String:cls] ?: @"";
        if ([c rangeOfString:@"Bluetooth" options:NSCaseInsensitiveSearch].length ||
            [c rangeOfString:@"BCM4" options:NSCaseInsensitiveSearch].length ||
            [c rangeOfString:@"BCMSerial" options:NSCaseInsensitiveSearch].length) {
            (*hits)++;
            P(@"  IOKit class: %@", c);
            if (pProps) {
                CFMutableDictionaryRef d = NULL;
                if (pProps(child, &d, kCFAllocatorDefault, 0) == KERN_SUCCESS && d) {
                    for (NSString *k in @[@"Bluetooth Firmware Version", @"HardwareVersion", @"Chipset", @"Vendor", @"Product", @"Transport"]) {
                        id v = (__bridge id)CFDictionaryGetValue(d, (__bridge const void *)k);
                        if (v) {
                            if ([v isKindOfClass:[NSData class]])
                                P(@"    %@ = %@", k, [[NSString alloc] initWithData:v encoding:NSUTF8StringEncoding] ?: [v base64EncodedStringWithOptions:0]);
                            else
                                P(@"    %@ = %@", k, v);
                        }
                    }
                    CFRelease(d);
                }
            }
        }
        dumpBTEntries(child, depth + 1, maxDepth, hits);
        pRelease(child);
    }
    pRelease(iter);
}


/* ---- mode: -c  collect latest ControllerA/SpringBoard crash report ---- */
static int modeCrash(void) {
    @autoreleasepool {
        P(@"=== idiag v0.4.0 - crash reporter collector (-c) ===");
        NSFileManager *fm = [NSFileManager defaultManager];
        NSString *dir = @"/var/mobile/Library/Logs/CrashReporter";
        NSArray *items = [fm contentsOfDirectoryAtPath:dir error:nil];
        if (!items) {
            P(@"CrashReporter dir not readable: %@", dir);
        } else {
            NSMutableArray *mine = [NSMutableArray new];
            for (NSString *f in items)
                if ([f hasSuffix:@".ips"] && ([f containsString:@"ControllerA"] || [f containsString:@"SpringBoard"]))
                    [mine addObject:f];
            [mine sortUsingComparator:^NSComparisonResult(NSString *a, NSString *b) {
                NSDictionary *sa = [fm attributesOfItemAtPath:[dir stringByAppendingPathComponent:a] error:nil];
                NSDictionary *sb = [fm attributesOfItemAtPath:[dir stringByAppendingPathComponent:b] error:nil];
                return [sb[NSFileModificationDate] compare:sa[NSFileModificationDate]];
            }];
            P(@"matching .ips files (newest first): %lu", (unsigned long)mine.count);
            for (NSString *f in mine) P(@"  %@", f);
            if (mine.count) {
                NSString *p2 = [dir stringByAppendingPathComponent:mine.firstObject];
                NSString *txt = [NSString stringWithContentsOfFile:p2 encoding:NSUTF8StringEncoding error:nil];
                if (txt) {
                    NSArray *lines = [txt componentsSeparatedByString:@"\n"];
                    P(@"--- newest: %@ (%lu lines, showing up to 80) ---", mine.firstObject, (unsigned long)lines.count);
                    NSUInteger n = MIN(80, lines.count);
                    for (NSUInteger i = 0; i < n; i++) P(@"%@", lines[i]);
                    NSString *dst = @"/var/mobile/Library/idiag-latest-crash.txt";
                    [txt writeToFile:dst atomically:YES encoding:NSUTF8StringEncoding error:nil];
                    P(@"--- full copy saved to %@ ---", dst);
                }
            } else {
                P(@"no ControllerA/SpringBoard .ips found - re-run a minute after the crash");
            }
        }
        fprintf(stdout, "%s\n", out.UTF8String);
    }
    return 0;
}

/* ---- mode: -p  Bluetooth permission / identity storage audit ---- */
static int modePerms(void) {
    @autoreleasepool {
        P(@"=== idiag v0.4.0 - Bluetooth permission storage audit (-p) ===");
        NSFileManager *fm = [NSFileManager defaultManager];
        NSArray *cands = @[
            @"/var/containers/Shared/SystemGroup/systemgroup.com.apple.bluetooth/Library/Preferences/com.apple.bluetooth.plist",
            @"/var/mobile/Library/Preferences/com.apple.bluetooth.plist",
        ];
        for (NSString *p2 in cands) {
            NSDictionary *d = [NSDictionary dictionaryWithContentsOfFile:p2];
            if (!d) { P(@"%@ : not readable/absent", p2); continue; }
            P(@"%@ : %lu keys", p2, (unsigned long)d.count);
            for (NSString *k in d) {
                NSString *lo = k.lowercaseString;
                if ([lo containsString:@"controllera"] || [k containsString:@"Permission"] ||
                    [lo containsString:@"hostcontroller"] || [lo containsString:@"transport"] ||
                    [lo containsString:@"pairing"])
                    P(@"  %@ = %@", k, d[k]);
            }
        }
        NSString *tcc = @"/private/var/mobile/Library/TCC/TCC.db";
        if ([fm isReadableFileAtPath:tcc]) {
            P(@"TCC.db readable - inspect with:");
            P(@"  sqlite3 %@ 'select service,client,auth_value from access;'", tcc);
        } else {
            P(@"TCC.db: not readable (Bluetooth permission may be stored by bluetoothd instead of TCC on this iOS - UNKNOWN)");
        }
        /* container sanity: identity resolution for the CB prompt keys off the app container */
        NSString *bundleRoot = @"/var/containers/Bundle/Application";
        P(@"Bundle containers readable: %@", [fm isReadableFileAtPath:bundleRoot] ? @"YES" : @"no");
        fprintf(stdout, "%s\n", out.UTF8String);
    }
    return 0;
}

int main(int argc, char **argv) {
    out = [NSMutableString new];
    @autoreleasepool {
        if (argc > 1 && !strcmp(argv[1], "-c")) return modeCrash();
        if (argc > 1 && !strcmp(argv[1], "-p")) return modePerms();
        P(@"=== idiag v0.4.0 — iPhone A capability audit ===");
        P(@"# NOTE: fields the tool cannot determine are printed as UNKNOWN.");
        P(@"");

        P(@"--- Hardware / OS ---");
        P(@"hw.machine       = %@", sysctlStr(@"hw.machine"));
        P(@"hw.model         = %@", sysctlStr(@"hw.model"));
        P(@"hw.cputype/subtype = %@ / %@", sysctlStr(@"hw.cputype"), sysctlStr(@"hw.cpusubtype"));
        P(@"hw.ncpu          = %@", sysctlStr(@"hw.ncpu"));
        P(@"hw.memsize       = %@", sysctlStr(@"hw.memsize"));
        P(@"cpu.brand        = %@", sysctlStr(@"machdep.cpu.brand_string"));
        P(@"kern.osrelease   = %@", sysctlStr(@"kern.osrelease"));
        P(@"kern.osversion   = %@", sysctlStr(@"kern.osversion"));   /* build number */
        P(@"kern.osproductversion = %@", sysctlStr(@"kern.osproductversion"));
        P(@"kern.bootargs    = %@", sysctlStr(@"kern.bootargs"));
        P(@"kern.uuid?       = %@", sysctlStr(@"kern.uuid"));
        struct utsname un;
        if (uname(&un) == 0) P(@"uname            = %s %s %s %s", un.sysname, un.nodename, un.release, un.machine);
        P(@"");

        P(@"--- Jailbreak markers ---");
        BOOL rootlessJB = pathExists("/var/jb");
        P(@"rootless /var/jb           = %@", rootlessJB ? @"YES (rootless bootstrap, e.g. palera1n rootless / Dopamine)" : @"no");
        P(@"rootful /.procursus        = %@", pathExists("/.procursus") ? @"YES (rootful Procursus)" : @"no");
        P(@"/var/jb/.installed_dopamine= %@", pathExists("/var/jb/.installed_dopamine") ? @"YES" : @"no");
        P(@"/var/jb/usr/bin/palera1n*  = %@", pathExists("/var/jb/usr/bin/palera1n") ? @"YES" : @"no");
        P(@"/var/mobile/.bootstrap*    = %@", pathExists("/var/mobile/.bootstrap") ? @"YES" : @"no");
        P(@"/usr/lib/substrate         = %@", pathExists("/usr/lib/substrate") || pathExists("/var/jb/usr/lib/TweakInject") ? @"YES (Substrate/ElleKit TweakInject)" : @"no");
        P(@"/usr/lib/TweakInject       = %@", pathExists("/usr/lib/TweakInject") || pathExists("/var/jb/usr/lib/TweakInject") ? @"YES" : @"no");
        P(@"/usr/lib/ellekit           = %@", pathExists("/usr/lib/ellekit") || pathExists("/var/jb/usr/lib/ellekit") ? @"YES" : @"no");
        P(@"/var/jb/basebin            = %@", pathExists("/var/jb/basebin") ? @"YES (palera1n basebin)" : @"no");
        P(@"/usr/lib/libhooker.dylib   = %@", pathExists("/usr/lib/libhooker.dylib") || pathExists("/var/jb/usr/lib/libhooker.dylib") ? @"YES" : @"no");
        P(@"");

        P(@"--- Package manager / bootstrap ---");
        const char *dpkgStatus = rootlessJB ? "/var/jb/var/lib/dpkg/status" : "/var/lib/dpkg/status";
        NSError *err = nil;
        NSString *st = [NSString stringWithContentsOfFile:[NSString stringWithUTF8String:dpkgStatus] encoding:NSUTF8StringEncoding error:&err];
        if (st) {
            NSArray *pkgs = [st componentsSeparatedByString:@"\n\n"];
            P(@"dpkg status      = %s (%lu packages)", dpkgStatus, (unsigned long)pkgs.count);
            for (NSString *p in pkgs) {
                NSString *l = [p componentsSeparatedByString:@"\n"].firstObject ?: @"";
                if ([l containsString:@"ellekit"] || [l containsString:@"substrate"] || [l containsString:@"palera1n"] ||
                    [l containsString:@"dopamine"] || [l containsString:@"trollstore"]) P(@"  notable: %@", l);
            }
        } else P(@"dpkg status      = not found (%@)", err.localizedDescription ?: @"");

        NSArray *sileoPaths = @[@"/var/jb/Applications/Sileo.app", @"/Applications/Sileo.app", @"/var/jb/usr/bin/sileo", @"/var/jb/Applications/Zebra.app"];
        BOOL sileo = NO;
        for (NSString *s in sileoPaths) if (pathExists(s.UTF8String)) { sileo = YES; P(@"Sileo/Zebra      = YES (%@)", s); }
        if (!sileo) P(@"Sileo/Zebra      = no");
        P(@"");

        P(@"--- TrollStore ---");
        NSArray *tsMarkers = @[
            @"/var/mobile/Library/Preferences/com.opa334.trollstore.plist",
            @"/var/jb/Applications/TrollStore.app",
            @"/Applications/TrollStore.app",
        ];
        BOOL ts = NO;
        for (NSString *m in tsMarkers) if (pathExists(m.UTF8String)) { ts = YES; P(@"TrollStore marker= YES (%@)", m); }
        NSFileManager *fm = [NSFileManager defaultManager];
        NSString *bundleRoot = @"/var/containers/Bundle/Application";
        if (!ts && [fm isReadableFileAtPath:bundleRoot]) {
            for (NSString *d in [fm contentsOfDirectoryAtPath:bundleRoot error:nil]) {
                for (NSString *f in [fm contentsOfDirectoryAtPath:[bundleRoot stringByAppendingPathComponent:d] error:nil]) {
                    if ([f containsString:@"TrollStore"] || [f containsString:@"TrollInstaller"] || [f containsString:@"TrollMisaka"]) {
                        ts = YES; P(@"TrollStore app   = YES (%@/%@)", d, f);
                    }
                }
            }
        }
        if (!ts) P(@"TrollStore       = not detected by filesystem heuristic (can be UNKNOWN if restricted)");
        P(@"");

        P(@"--- IOKit / Bluetooth chip ---");
        if (loadIOKit()) {
            io_registry_entry_t root = 0;
            mach_port_t master = 0; /* kIOMasterPortDefault */
            if (pRoot(master, &root) != KERN_SUCCESS || root == 0) {
                P(@"  IOKit root not accessible -> UNKNOWN (run as root)");
            } else {
                int hits = 0;
                dumpBTEntries(root, 0, 4, &hits);
                if (!hits) P(@"  no Bluetooth-class entries visible (may need root; mark UNKNOWN)");
                CFTypeRef model = pProp(root, CFSTR("model"), kCFAllocatorDefault, 0);
                if (model) { P(@"  IODeviceTree model = %@", (__bridge NSString *)model); CFRelease(model); }
                CFTypeRef platform = pProp(root, CFSTR("platform-name"), kCFAllocatorDefault, 0);
                if (platform) { P(@"  platform-name      = %@", (__bridge NSString *)platform); CFRelease(platform); }
                pRelease(root);
            }
        } else {
            P(@"  IOKit dylib not loadable -> UNKNOWN");
        }
        P(@"");

        P(@"--- Bluetooth stack / chip / HCI surfaces (Phase-3 audit, v0.3) ---");
        P(@"blued            = %@", pathExists("/usr/libexec/blued") ? @"YES (/usr/libexec/blued present)" : UNK);

        // key Phase-3 files (internalblued/BlueTool research: see docs/11 E14-E16)
        NSArray *btFiles = @[
            @"/usr/sbin/BlueTool", @"/usr/sbin/BlueTool.sbin",
            @"/dev/uart.bluetooth", @"/dev/btreset",
            @"/var/jb/usr/libexec/internalblued",
            @"/var/mobile/Library/Preferences/com.ttdennis.internalblued.plist",
        ];
        NSFileManager *fmBT = [NSFileManager defaultManager];
        for (NSString *f in btFiles) {
            NSDictionary *at = [fmBT attributesOfItemAtPath:f error:nil];
            if (at) P(@"  EXISTS: %@ (%@ bytes)", f, at[NSFileSize] ?: @"?");
        }
        if (!pathExists("/usr/sbin/BlueTool") && !pathExists("/usr/sbin/BlueTool.sbin"))
            P(@"  BlueTool            = not found (UNKNOWN if path differs on this iOS)");

        // UART/Bluetooth device nodes (root): the internalblued transport surface
        NSArray *devs = [fmBT contentsOfDirectoryAtPath:@"/dev" error:nil];
        if (devs) {
            NSMutableArray *hits = [NSMutableArray new];
            for (NSString *d in devs) {
                NSString *lo = d.lowercaseString;
                if ([lo containsString:@"bluetooth"] || [lo containsString:@"uart"] ||
                    [lo hasPrefix:@"cu."] || [lo hasPrefix:@"tty."])
                    [hits addObject:d];
            }
            P(@"  /dev entries of interest (%lu): %@", (unsigned long)hits.count,
              [hits count] ? [hits subarrayWithRange:NSMakeRange(0, MIN(12, hits.count))] : @"(none visible)");
        } else P(@"  /dev not readable -> run as root");

        // BlueTool-embedded BT firmware (iOS >= 13.6 keeps .hcd inside BlueTool) -> chip identity
        NSString *btPath = pathExists("/usr/sbin/BlueTool") ? @"/usr/sbin/BlueTool" :
                           (pathExists("/usr/sbin/BlueTool.sbin") ? @"/usr/sbin/BlueTool.sbin" : nil);
        if (btPath) {
            NSData *bd = [NSData dataWithContentsOfFile:btPath options:NSDataReadingMappedIfSafe error:nil];
            if (bd) {
                NSMutableSet *chips = [NSMutableSet new];
                const uint8_t *bytes = (const uint8_t *)bd.bytes;
                NSUInteger len = bd.length, i = 0, cap = MIN(len, (NSUInteger)64 * 1024 * 1024);
                while (i < cap && chips.count < 12) {
                    if (bytes[i] >= 0x20 && bytes[i] <= 0x7E) {
                        NSUInteger j = i;
                        while (j < cap && bytes[j] >= 0x20 && bytes[j] <= 0x7E) j++;
                        if (j - i >= 6 && j - i < 128) {
                            NSString *tok = [[NSString alloc] initWithBytes:bytes + i length:j - i encoding:NSASCIIStringEncoding];
                            if (tok && ([tok containsString:@"BCM4"] || [tok containsString:@"CYW"] ||
                                        [tok containsString:@"bcm4"] || [tok.lowercaseString containsString:@".hcd"]))
                                [chips addObject:tok];
                        }
                        i = j;
                    } else i++;
                }
                P(@"  BlueTool firmware/chip tokens: %@", chips.count ? [chips allObjects] : @"none found (UNKNOWN)");
            } else P(@"  BlueTool not readable -> run as root");
        }
        P(@"");
        P(@"=== END idiag ===");
        fprintf(stdout, "%s\n", out.UTF8String);

        NSString *dst = @"/var/mobile/Library/idiag-report.txt";
        [out writeToFile:dst atomically:YES encoding:NSUTF8StringEncoding error:nil];
        fprintf(stdout, "[idiag] report also saved to %s\n", dst.UTF8String);
    }
    return 0;
}
