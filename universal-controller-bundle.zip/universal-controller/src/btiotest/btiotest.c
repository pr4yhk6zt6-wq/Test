/* btiotest v0.2.0 — /dev/uart.bluetooth probe with termios + baud sweep.
   WHY: v0.1.0 proved open() works (G1.6 round 2) but sent HCI Reset without
   configuring the tty; the BCM4350-class chip was left by BlueTool at some
   vendor baud (likely 3M-class) with HW flow control, so the bytes probably
   reached it as garbage. v0.2.0 sweeps baud x HW-flow combos, sending
   HCI Reset at each and listening for Command Complete (04 0E ...).
   READ/WRITE on the device node only. */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <termios.h>
#include <sys/select.h>
#include <sys/ioctl.h>

static const int bauds[] = { 115200, 921600, 1000000, 2000000, 3000000, 4000000 };
static const int nbauds = (int)(sizeof(bauds) / sizeof(bauds[0]));

#ifndef IOSSIOSPEED
#define IOSSIOSPEED _IOW('O', 2, speed_t)   /* Apple serial: arbitrary baud */
#endif

/* returns 0 on success; sets *sp if an ioctl speed must be applied instead */
static int baud_const(int b, speed_t *out, long *ioctl_speed) {
    *ioctl_speed = 0;
    switch (b) {
        case 9600: *out = B9600; return 0;
        case 57600: *out = B57600; return 0;
        case 115200: *out = B115200; return 0;
        case 230400: *out = B230400; return 0;
#ifdef B460800
        case 460800: *out = B460800; return 0;
#endif
#ifdef B921600
        case 921600: *out = B921600; return 0;
#endif
#ifdef B1000000
        case 1000000: *out = B1000000; return 0;
#endif
#ifdef B2000000
        case 2000000: *out = B2000000; return 0;
#endif
#ifdef B3000000
        case 3000000: *out = B3000000; return 0;
#endif
#ifdef B4000000
        case 4000000: *out = B4000000; return 0;
#endif
        default:
            *out = B115200;          /* placeholder; real speed via IOSSIOSPEED */
            *ioctl_speed = b;
            return 0;
    }
}

static int set_raw(int fd, int baud, int hwflow) {
    struct termios t;
    if (tcgetattr(fd, &t) != 0) {
        if (errno == ENOTTY) return 0;
        return -1;
    }
    /* raw mode, done manually for portability (iOS BSD/glibc) */
    t.c_iflag &= ~(IGNBRK | BRKINT | PARMRK | ISTRIP | INLCR | IGNCR | ICRNL | IXON);
    t.c_oflag &= ~OPOST;
    t.c_lflag &= ~(ECHO | ECHONL | ICANON | ISIG | IEXTEN);
    t.c_cflag |= CLOCAL | CREAD;
    t.c_cflag &= ~CSTOPB;
    t.c_cflag &= ~CSIZE;
    t.c_cflag |= CS8;
    t.c_cflag &= ~PARENB;
#ifdef CCTS_OFLOW
    if (hwflow) t.c_cflag |= CCTS_OFLOW; else t.c_cflag &= ~CCTS_OFLOW;
#endif
#ifdef CRTSCTS
    if (hwflow) t.c_cflag |= CRTSCTS; else t.c_cflag &= ~CRTSCTS;
#endif
    t.c_cc[VMIN] = 1;
    t.c_cc[VTIME] = 0;
    speed_t s = 0; long ispeed = 0;
    if (baud_const(baud, &s, &ispeed) != 0) return -1;
    cfsetispeed(&t, s);
    cfsetospeed(&t, s);
    if (tcsetattr(fd, TCSANOW, &t) != 0) return -1;
#ifdef TIOCSERSPEED
    (void)0;
#endif
    if (ispeed) {
        if (ioctl(fd, IOSSIOSPEED, &ispeed) != 0)
            printf("    (note: IOSSIOSPEED %ld failed errno=%d)\n", ispeed, errno);
    }
    tcflush(fd, TCIOFLUSH);
    return 0;
}

/* returns 1 if a Command Complete was seen; 0 if idle; prints bytes either way */
static int listen_reset_reply(int fd, const char *tag) {
    uint8_t buf[128];
    fd_set rf;
    struct timeval tv = { 1, 500000 };
    FD_ZERO(&rf);
    FD_SET(fd, &rf);
    int r = select(fd + 1, &rf, NULL, NULL, &tv);
    if (r == 0) { printf("    [%s] no reply in 1.5s\n", tag); return 0; }
    if (r < 0)  { printf("    [%s] select errno=%d\n", tag, errno); return 0; }
    ssize_t n = read(fd, buf, sizeof(buf));
    if (n <= 0) { printf("    [%s] read %zd (errno %d)\n", tag, n, errno); return 0; }
    printf("    [%s] read %zd bytes:", tag, n);
    for (ssize_t i = 0; i < n && i < 24; i++) printf(" %02X", buf[i]);
    printf("\n");
    for (ssize_t i = 0; i + 1 < n; i++)
        if (buf[i] == 0x04 && buf[i + 1] == 0x0E) return 1;
    if (n == 1 && buf[0] == 0x04) return 1; /* event code alone is enough signal */
    return 0;
}

int main(int argc, char **argv) {
    const char *path = "/dev/uart.bluetooth";
    int do_write = 0, single_baud = 0;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-w")) do_write = 1;
        else if (!strcmp(argv[i], "-b") && i + 1 < argc) single_baud = atoi(argv[++i]);
        else path = argv[i];
    }
    printf("btiotest v0.2.0 — target %s%s\n", path, do_write ? " (baud sweep + reset)" : " (read only)");
    int fd = open(path, O_RDWR | O_NOCTTY | O_NONBLOCK);
    if (fd < 0) {
        printf("open() FAILED errno=%d (%s)\n", errno, strerror(errno));
        if (errno == EBUSY)
            printf("-> EBUSY: bootout com.apple.bluetoothd + com.apple.BlueTool first (runbook round 2)\n");
        return 1;
    }
    printf("open() OK fd=%d\n", fd);

    static const uint8_t reset[4] = { 0x01, 0x03, 0x0C, 0x00 };
    int found = 0;

    if (!do_write) {
        drain_again:;
        uint8_t b[64];
        fd_set rf; FD_ZERO(&rf); FD_SET(fd, &rf);
        struct timeval tv = { 2, 0 };
        int r = select(fd + 1, &rf, NULL, NULL, &tv);
        if (r > 0) {
            ssize_t n = read(fd, b, sizeof(b));
            printf("read %zd bytes:", n);
            for (ssize_t i = 0; i < n && i < 32; i++) printf(" %02X", b[i]);
            printf("\n");
            if (n > 0) goto drain_again;
        } else printf("no data within 2s (port open but idle)\n");
        close(fd);
        printf("close OK\n");
        return 0;
    }

    int nb = single_baud ? 1 : nbauds;
    for (int bi = 0; bi < nb && !found; bi++) {
        int baud = single_baud ? single_baud : bauds[bi];
        for (int fl = 0; fl < 2 && !found; fl++) {
            char tag[48];
            snprintf(tag, sizeof(tag), "baud=%d hwflow=%s", baud, fl ? "on" : "off");
            printf("  trying %s\n", tag);
            if (set_raw(fd, baud, fl) != 0) {
                printf("    [%s] tcsetattr failed errno=%d\n", tag, errno);
                continue;
            }
            ssize_t w = 0;
            for (int attempt = 0; attempt < 10 && w < 4; attempt++) {
                w = write(fd, reset, sizeof(reset));
                if (w < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) { usleep(100000); w = 0; continue; }
                if (w < 0) break;
            }
            if (w != 4) { printf("    [%s] write=%zd errno=%d (CTS may be held) — skipping\n", tag, w, errno); continue; }
            printf("    [%s] wrote HCI Reset\n", tag);
            usleep(30000);
            if (listen_reset_reply(fd, tag)) {
                found = 1;
                printf("\n>>> COMMAND COMPLETE at %s — controller ALIVE over raw UART <<<\n", tag);
                printf(">>> record this baud+flow: it is the config for hci_io_uart/daemon <<<\n");
            }
        }
    }
    if (!found) printf("\nno Command Complete in any combo — port opens but chip not answering yet\n");
    close(fd);
    printf("close OK\n");
    return found ? 0 : 2;
}
