/* ds4bridged — Phase-3 research daemon for iPhone A (rootless palera1n/Dopamine).
   STATUS: protocol core VERIFIED (host unit tests). This binary runs the
   state machine against the NULL transport to prove the arm64 on-device
   build; the real Bluetooth HCI/L2CAP device-role backend is the remaining
   research task (docs/05-architecture.md §Phase-3). It must NOT be presented
   as a working iPhone-B controller path. */
#import <Foundation/Foundation.h>
#include "ds4bridge/hiddev.h"
#include "ds4bridge/sdp.h"
#include "ds4bridge/transport_null.h"

static uint32_t mono_ms(void) {
    static struct timespec t0;
    static int init = 0;
    if (!init) { clock_gettime(CLOCK_MONOTONIC, &t0); init = 1; }
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return (uint32_t)((t.tv_sec - t0.tv_sec) * 1000 + (t.tv_nsec - t0.tv_nsec) / 1000000);
}

int main(int argc, char **argv) {
    @autoreleasepool {
        NSLog(@"ds4bridged starting (protocol core: build-verified, transport: NULL/loopback)");
        uint8_t sdpBuf[2048];
        size_t sdpLen = sdp_build_hid_gamepad_record(sdpBuf, sizeof(sdpBuf));
        NSLog(@"SDP record built: %zu bytes (would be registered over L2CAP in a real backend)", sdpLen);

        null_ctx n;
        hiddev_t *h = hiddev_new(hiddev_transport_null(&n));
        NSLog(@"listening (null): control PSM %d, interrupt PSM %d", 0x0011, 0x0013);

        uint32_t t = mono_ms();
        uint32_t simStart = t;
        NSLog(@"self-test: simulating a host connect + 2s of reporting");
        hiddev_on_connected(h, 0x0011);
        hiddev_on_connected(h, 0x0013);
        while (mono_ms() - simStart < 2000) {
            uint32_t now = mono_ms();
            ICInputPacket p; memset(&p, 0, sizeof(p));
            p.magic = IC_MAGIC; p.version = IC_VERSION;
            p.lx = (int8_t)((now / 10) % 127); p.hat = 8;
            p.seq16 = (uint16_t)(now & 0xFFFF); p.t_ms = now;
            p.crc = ic_crc16((const uint8_t *)&p, offsetof(ICInputPacket, crc));
            hiddev_set_input(h, &p);
            hiddev_tick(h, now);
            usleep(8000);
        }
        NSLog(@"self-test done: state=%d reports=%u bytes=%u — exiting (daemon is a research shell)",
              hiddev_state(h), hiddev_reports_sent(h), hiddev_bytes_sent(h));
        hiddev_free(h);
        (void)argc; (void)argv; (void)t;
    }
    return 0;
}
