/* bthelper — root helper for BTKit (TrollStore app).
   Installed setuid-root inside the .app; does the privileged parts:
     stop     - bootout com.apple.bluetoothd + com.apple.BlueTool, then test open()
     sweep    - open UART, sweep baud x HW-flow, HCI Reset at each, detect Command Complete
     restore  - bootstrap the daemons back (fallback: Userspace Reboot)
   Prints a machine+human readable log to stdout. Read/write only on the UART node. */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <termios.h>
#include <sys/select.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/sysctl.h>
#include <signal.h>
#include <sys/wait.h>
/* libproc.h is absent in the iOS 14.5 SDK tarball -> inline the minimal,
   ABI-stable definitions from Apple's sys/proc_info.h + libproc.h. */
#ifndef PROC_PIDLISTFDS
#define PROC_PIDLISTFDS 1
#endif
#ifndef PROC_PIDFDVNODEINFO
#define PROC_PIDFDVNODEINFO 1
#endif
#ifndef PROX_FDTYPE_VNODE
#define PROX_FDTYPE_VNODE 1
#endif
struct vinfo_stat {
    uint32_t vst_dev; uint16_t vst_mode; uint16_t vst_nlink; uint64_t vst_ino;
    uid_t vst_uid; gid_t vst_gid;
    int64_t vst_atime; int64_t vst_atimensec; int64_t vst_mtime; int64_t vst_mtimensec;
    int64_t vst_ctime; int64_t vst_ctimensec; int64_t vst_birthtime; int64_t vst_birthtimensec;
    off_t vst_size; int64_t vst_blocks; int32_t vst_blksize; uint32_t vst_flags;
    uint32_t vst_gen; uint32_t vst_rdev; int64_t vst_qspare[2];
};
struct proc_fileinfo { uint32_t fi_openflags; uint32_t fi_status; off_t fi_offset; int32_t fi_fstype; int32_t fi_fdflags; };
struct vnode_info { struct vinfo_stat vi_stat; fsid_t vi_fsid; };
struct vnode_fdinfo { struct proc_fileinfo pfi; struct vnode_info vi; };
struct proc_fdinfo { int32_t proc_fd; uint32_t proc_fdtype; };
extern int proc_pidinfo(int pid, int flavor, uint64_t arg, void *buffer, int buffersize);
extern int proc_pidfdinfo(int pid, int fd, int flavor, void *buffer, int buffersize);

static const char *kLctl[] = { "/var/jb/bin/launchctl", "/usr/bin/launchctl", "/bin/launchctl", NULL };
static const char *kDaemons[] = { "com.apple.bluetoothd", "com.apple.BlueTool", NULL };
static const char *kPlists[] = {
    "/System/Library/LaunchDaemons/com.apple.bluetoothd.plist",
    "/System/Library/LaunchDaemons/com.apple.BlueTool.plist", NULL
};

#ifndef IOSSIOSPEED
#define IOSSIOSPEED _IOW('O', 2, speed_t)
#endif

static speed_t baud_const(int b, long *ioctl_speed) {
    *ioctl_speed = 0;
    switch (b) {
        case 9600: return B9600;
        case 57600: return B57600;
        case 115200: return B115200;
        case 230400: return B230400;
#ifdef B460800
        case 460800: return B460800;
#endif
#ifdef B921600
        case 921600: return B921600;
#endif
#ifdef B1000000
        case 1000000: return B1000000;
#endif
#ifdef B2000000
        case 2000000: return B2000000;
#endif
#ifdef B3000000
        case 3000000: return B3000000;
#endif
#ifdef B4000000
        case 4000000: return B4000000;
#endif
        default: *ioctl_speed = b; return B115200;
    }
}

static int set_raw(int fd, int baud, int hwflow) {
    struct termios t;
    if (tcgetattr(fd, &t) != 0) {
        if (errno == ENOTTY) return 0;
        return -1;
    }
    t.c_iflag &= ~(IGNBRK | BRKINT | PARMRK | ISTRIP | INLCR | IGNCR | ICRNL | IXON);
    t.c_oflag &= ~OPOST;
    t.c_lflag &= ~(ECHO | ECHONL | ICANON | ISIG | IEXTEN);
    t.c_cflag |= CLOCAL | CREAD;
    t.c_cflag &= ~(CSTOPB | CSIZE | PARENB);
    t.c_cflag |= CS8;
#ifdef CCTS_OFLOW
    if (hwflow) t.c_cflag |= CCTS_OFLOW; else t.c_cflag &= ~CCTS_OFLOW;
#endif
#ifdef CRTSCTS
    if (hwflow) t.c_cflag |= CRTSCTS; else t.c_cflag &= ~CRTSCTS;
#endif
    t.c_cc[VMIN] = 1;
    t.c_cc[VTIME] = 0;
    long ispeed = 0;
    speed_t s = baud_const(baud, &ispeed);
    cfsetispeed(&t, s);
    cfsetospeed(&t, s);
    if (tcsetattr(fd, TCSANOW, &t) != 0) return -1;
    if (ispeed) {
        if (ioctl(fd, IOSSIOSPEED, &ispeed) != 0)
            printf("    (note: IOSSIOSPEED %ld failed errno=%d)\n", ispeed, errno);
    }
    tcflush(fd, TCIOFLUSH);
    return 0;
}

static int open_uart(void) {
    int fd = open("/dev/uart.bluetooth", O_RDWR | O_NOCTTY | O_NONBLOCK);
    if (fd < 0) {
        printf("open() FAILED errno=%d (%s)\n", errno, strerror(errno));
        if (errno == EBUSY) printf("-> daemons still hold the port; run STOP first\n");
        return -1;
    }
    printf("open() OK fd=%d\n", fd);
    return fd;
}

static int detect_cc(int fd, const char *tag) {
    uint8_t buf[128];
    fd_set rf;
    FD_ZERO(&rf);
    FD_SET(fd, &rf);
    struct timeval tv = { 1, 500000 };
    int r = select(fd + 1, &rf, NULL, NULL, &tv);
    if (r == 0) { printf("    [%s] no reply in 1.5s\n", tag); return 0; }
    if (r < 0)  { printf("    [%s] select errno=%d\n", tag, errno); return 0; }
    ssize_t n = read(fd, buf, sizeof(buf));
    if (n <= 0) { printf("    [%s] read %zd\n", tag, n); return 0; }
    printf("    [%s] read %zd:", tag, n);
    for (ssize_t i = 0; i < n && i < 24; i++) printf(" %02X", buf[i]);
    printf("\n");
    for (ssize_t i = 0; i + 1 < n; i++)
        if (buf[i] == 0x04 && buf[i + 1] == 0x0E) return 1;
    return (n == 1 && buf[0] == 0x04);
}

/* run a program WITHOUT /bin/sh: fork + execv of a proper argv array.
   LESSON (v0.2.0 on device): passing "bootout system/X" as ONE argv item made
   launchctl see a bogus single-word subcommand. argv must be split exactly as
   a shell would split it. */
static int run_argv(char *const argv[]) {
    int p[2];
    if (pipe(p) != 0) { printf("pipe errno=%d\n", errno); return -1; }
    pid_t pid = fork();
    if (pid == 0) {
        close(p[0]);
        dup2(p[1], 1); dup2(p[1], 2); close(p[1]);
        char *env[] = { (char *)"PATH=/var/jb/bin:/var/jb/usr/bin:/usr/bin:/bin:/usr/sbin:/sbin", NULL };
        execve(argv[0], argv, env);
        int e = errno;
        char m[64];
        int l = snprintf(m, sizeof(m), "EXEC_FAIL errno=%d (%s)\n", e, strerror(e));
        write(p[1], m, l);
        _exit(127);
    }
    close(p[1]);
    FILE *fp = fdopen(p[0], "r");
    char line[256];
    while (fgets(line, sizeof(line), fp)) fputs(line, stdout);
    fclose(fp);
    int st = 0;
    waitpid(pid, &st, 0);
    return WIFEXITED(st) ? WEXITSTATUS(st) : -1;
}

/* kill processes whose lowercase name contains one of the given substrings.
   DEVICE-LESSONS baked in: iOS BT daemon = "blued" (no t); a STUCK btiotest
   from an earlier terminal round held the UART for hours (seen in dump:
   8784 btiotest). p_comm truncates at 16 chars (WirelessRadioManagerd ->
   "WirelessRadioMan") so substrings are prefix-safe. */
static void kill_matching(const char **names, int sig) {
    int mib[4] = { CTL_KERN, KERN_PROC, KERN_PROC_ALL, 0 };
    size_t len = 0;
    if (sysctl(mib, 3, NULL, &len, NULL, 0) != 0) { printf("sysctl size errno=%d\n", errno); return; }
    struct kinfo_proc *procs = (struct kinfo_proc *)malloc(len * 2);
    if (!procs) return;
    if (sysctl(mib, 3, procs, &len, NULL, 0) != 0) { printf("sysctl errno=%d\n", errno); free(procs); return; }
    size_t count = len / sizeof(struct kinfo_proc);
    for (size_t i = 0; i < count; i++) {
        char name[17];
        snprintf(name, sizeof(name), "%s", procs[i].kp_proc.p_comm);
        pid_t pid = procs[i].kp_proc.p_pid;
        if (pid == getpid()) continue;
        char low[17];
        for (int c = 0; c < 17; c++) low[c] = (char)((name[c] >= 'A' && name[c] <= 'Z') ? name[c] + 32 : name[c]);
        for (const char **n = names; *n; n++) {
            if (strstr(low, *n)) {
                printf("  kill(%d, %s) <- %s\n", pid, sig == SIGTERM ? "TERM" : "KILL", name);
                kill(pid, sig);
                break;
            }
        }
    }
    free(procs);
}

/* KERNEL-TRUTH lsof: scan every process fd table via proc_pidinfo and name
   whoever actually holds the UART device open. Prints each holder
   (pid/comm/fd) or a single NONE line (= driver-level latch). */
/* SELF-TEST: can we spot OUR OWN fd on /dev/null? Validates the hand-inlined
   struct layouts before we trust any holder report. */
static int lsof_selftest(void) {
    int tfd = open("/dev/null", O_RDWR);
    if (tfd < 0) return -1;
    struct stat st;
    if (fstat(tfd, &st) != 0) { close(tfd); return -1; }
    size_t need = (size_t)proc_pidinfo(getpid(), PROC_PIDLISTFDS, 0, NULL, 0);
    if (need <= 0 || need > (4u << 20)) { close(tfd); return -1; }
    struct proc_fdinfo *fds = (struct proc_fdinfo *)malloc(need);
    if (!fds) { close(tfd); return -1; }
    int ok = -2;
    if ((size_t)proc_pidinfo(getpid(), PROC_PIDLISTFDS, 0, fds, need) == need) {
        int nf = (int)(need / sizeof(struct proc_fdinfo));
        for (int f = 0; f < nf; f++) {
            if (fds[f].proc_fdtype != PROX_FDTYPE_VNODE) continue;
            struct vnode_fdinfo vi;
            if (proc_pidfdinfo(getpid(), fds[f].proc_fd, PROC_PIDFDVNODEINFO, &vi, sizeof(vi)) <= 0) continue;
            if (!S_ISCHR(vi.vi.vi_stat.vst_mode)) continue;
            if ((dev_t)vi.vi.vi_stat.vst_rdev == st.st_rdev) { ok = 0; break; }
        }
    }
    free(fds); close(tfd);
    return ok;
}

static void report_port_holders(void) {
    if (lsof_selftest() != 0) { printf("  [lsof] SELFTEST FAILED (struct mismatch?)\n"); return; }
    struct stat st;
    if (stat("/dev/uart.bluetooth", &st) != 0) { printf("  [lsof] stat errno=%d\n", errno); return; }
    int mib[4] = { CTL_KERN, KERN_PROC, KERN_PROC_ALL, 0 };
    size_t len = 0;
    if (sysctl(mib, 3, NULL, &len, NULL, 0) != 0) { printf("  [lsof] sysctl errno=%d\n", errno); return; }
    struct kinfo_proc *procs = (struct kinfo_proc *)malloc(len * 2);
    if (!procs) return;
    if (sysctl(mib, 3, procs, &len, NULL, 0) != 0) { free(procs); return; }
    size_t count = len / sizeof(struct kinfo_proc);
    int found = 0;
    for (size_t i = 0; i < count; i++) {
        pid_t pid = procs[i].kp_proc.p_pid;
        size_t need = (size_t)proc_pidinfo(pid, PROC_PIDLISTFDS, 0, NULL, 0);
        if (need <= 0 || need > (4u << 20)) continue;
        struct proc_fdinfo *fds = (struct proc_fdinfo *)malloc(need);
        if (!fds) break;
        if ((size_t)proc_pidinfo(pid, PROC_PIDLISTFDS, 0, fds, need) != need) { free(fds); continue; }
        int nf = (int)(need / sizeof(struct proc_fdinfo));
        for (int f = 0; f < nf; f++) {
            if (fds[f].proc_fdtype != PROX_FDTYPE_VNODE) continue;
            struct vnode_fdinfo vi;
            if (proc_pidfdinfo(pid, fds[f].proc_fd, PROC_PIDFDVNODEINFO, &vi, sizeof(vi)) <= 0) continue;
            if (!S_ISCHR(vi.vi.vi_stat.vst_mode)) continue;
            if ((dev_t)vi.vi.vi_stat.vst_rdev != st.st_rdev) continue;
            printf("  [lsof] HOLDER: pid %d (%s) fd %d\n", pid, procs[i].kp_proc.p_comm, fds[f].proc_fd);
            found++;
        }
        free(fds);
    }
    free(procs);
    if (!found) printf("  [lsof] holders: NONE -> port latched at DRIVER level (Userspace Reboot resets it)\n");
}

static const char *kTier1[] = { "blue", "btiotest", "bthelper", NULL };
static const char *kTier2[] = { "btleserver", "wirelessradioman", "findmydeviced", "fmfd", "nearbyd", "rapportd", NULL };

static void do_stop(void) {
    printf("== STOP BT daemons ==\n");
    const char *lctl = NULL;
    for (int i = 0; kLctl[i]; i++)
        if (access(kLctl[i], X_OK) == 0) { lctl = kLctl[i]; break; }
    if (!lctl) { printf("launchctl not found — cannot stop daemons\n"); }
    else {
        printf("launchctl = %s\n", lctl);
        for (int i = 0; kDaemons[i]; i++) {
            printf("- bootout %s\n", kDaemons[i]);
            char a[4][96];
            snprintf(a[0], 96, "%s", lctl);
            snprintf(a[1], 96, "bootout");
            snprintf(a[2], 96, "system/%s", kDaemons[i]);
            char *argv[] = { a[0], a[1], a[2], NULL };
            run_argv(argv); /* "No such process" = already out = fine */
        }
    }
    printf("tier 1 kill (blue*, btiotest, stale bthelper):\n");
    kill_matching(kTier1, SIGTERM);
    sleep(1);
    kill_matching(kTier1, SIGKILL);
    sleep(1);
    printf("port test:\n");
    int fd = open_uart();
    if (fd >= 0) {
        close(fd);
        printf("PORT FREE — press 2 UART SWEEP now\n");
        printf("== STOP done ==\n");
        return;
    }
    report_port_holders();
    printf("tier 2 kill (BT-adjacent: BTLEServer, WirelessRadioManagerd,\n");
    printf("  FindMy/Nearby/Rapport — all restart on Userspace Reboot):\n");
    kill_matching(kTier2, SIGTERM);
    sleep(1);
    kill_matching(kTier2, SIGKILL);
    sleep(1);
    printf("port test:\n");
    fd = open_uart();
    if (fd >= 0) {
        close(fd);
        printf("PORT FREE — press 2 UART SWEEP now\n");
        printf("== STOP done ==\n");
        return;
    }
    if (1) {
        printf("STILL BUSY — full process dump (find the holder):\n");
        int mib[4] = { CTL_KERN, KERN_PROC, KERN_PROC_ALL, 0 };
        size_t len = 0;
        if (sysctl(mib, 3, NULL, &len, NULL, 0) == 0) {
            struct kinfo_proc *procs = (struct kinfo_proc *)malloc(len);
            if (procs && sysctl(mib, 3, procs, &len, NULL, 0) == 0) {
                size_t count = len / sizeof(struct kinfo_proc);
                for (size_t i = 0; i < count; i++)
                    printf("  %d %s\n", procs[i].kp_proc.p_pid, procs[i].kp_proc.p_comm);
            }
            if (procs) free(procs);
        }
    } else {
        close(fd);
        printf("PORT FREE — press 2 UART SWEEP now\n");
    }
    /* EVIDENCE (v0.1.8 run): every known userland holder dead yet port still
       EBUSY; tier2 respawners come back in <1 s. Two hypotheses remain:
       (a) a respawner grabs the port between kill and test -> probes catch it,
       (b) stale driver-level latch because daemons were signal-killed without
       a clean radio-down first (round 2 ALWAYS had airplane mode ON first).
       Probes discriminate: re-kill respawners + test, 4x. */
    for (int r = 1; r <= 4; r++) {
        printf("=== probe %d/4: re-kill tier1+tier2 + lsof + port test ===\n", r);
        kill_matching(kTier1, SIGKILL);
        kill_matching(kTier2, SIGKILL);
        sleep(3);
        fd = open_uart();
        if (fd >= 0) {
            close(fd);
            printf("PORT FREE after probe %d — press 2 UART SWEEP now\n", r);
            printf("== STOP done ==\n");
            return;
        }
        printf("  attempt %d: open() still EBUSY\n", r);
        report_port_holders();
    }
    printf("ALL PROBES FAILED — no known holder alive.\n");
    printf("  if [lsof] said NONE -> driver latch: do Userspace Reboot\n");
    printf("  (Dopamine app), then Airplane ON -> 1 STOP -> 2 SWEEP.\n");
    printf("  if [lsof] named a pid -> send that name to the chat.\n");
    printf("== STOP done (restore via RESTORE button or Userspace Reboot) ==\n");
}

static void do_sweep(void) {
    printf("== UART sweep ==\n");
    int fd = open_uart();
    if (fd < 0) { report_port_holders(); return; }
    static const int bauds[] = { 115200, 921600, 1000000, 2000000, 3000000, 4000000 };
    static const uint8_t reset[4] = { 0x01, 0x03, 0x0C, 0x00 };
    int found = 0;
    for (size_t bi = 0; bi < sizeof(bauds)/sizeof(bauds[0]) && !found; bi++) {
        for (int fl = 0; fl < 2 && !found; fl++) {
            char tag[48];
            snprintf(tag, sizeof(tag), "baud=%d hwflow=%s", bauds[bi], fl ? "on" : "off");
            printf("  trying %s\n", tag);
            if (set_raw(fd, bauds[bi], fl) != 0) { printf("    [%s] tcsetattr errno=%d\n", tag, errno); continue; }
            ssize_t w = -1;
            for (int a = 0; a < 10; a++) {
                w = write(fd, reset, 4);
                if (w == 4) break;
                if (w < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) { usleep(100000); continue; }
                break;
            }
            if (w != 4) { printf("    [%s] write=%zd errno=%d (CTS held?)\n", tag, w, errno); continue; }
            usleep(30000);
            if (detect_cc(fd, tag)) {
                found = 1;
                printf("\n>>> COMMAND COMPLETE at %s — controller ALIVE <<<\n", tag);
                printf(">>> CONFIG baud=%d hwflow=%s <<<\n", bauds[bi], fl ? "on" : "off");
            }
        }
    }
    if (!found) printf("\nno Command Complete in any combo — send this whole log\n");
    close(fd);
    printf("== sweep done ==\n");
}

static void do_restore(void) {
    printf("== RESTORE BT daemons ==\n");
    const char *lctl = NULL;
    for (int i = 0; kLctl[i]; i++)
        if (access(kLctl[i], X_OK) == 0) { lctl = kLctl[i]; break; }
    if (!lctl) { printf("launchctl not found\n"); return; }
    for (int i = 0; kPlists[i]; i++) {
        struct stat st;
        if (stat(kPlists[i], &st) != 0) { printf("- %s : plist absent, skip\n", kPlists[i]); continue; }
        char a[4][160];
        snprintf(a[0], 160, "%s", lctl);
        snprintf(a[1], 160, "bootstrap");
        snprintf(a[2], 160, "system");
        snprintf(a[3], 160, "%s", kPlists[i]);
        char *argv[] = { a[0], a[1], a[2], a[3], NULL };
        printf("- bootstrap %s\n", kPlists[i]);
        run_argv(argv);
    }
    printf("if anything failed: Userspace Reboot from the Dopamine app restores everything\n");
    printf("== restore done ==\n");
}

static const char *find_first(const char **paths) {
    struct stat sb;
    for (int i = 0; paths[i]; i++)
        if (stat(paths[i], &sb) == 0) return paths[i];
    return NULL;
}
/* DEVICE-LESSON: Dopamine/Procursus installs EVERYTHING under /var/jb —
   v0.2.7 only checked stock paths (/usr/bin/ssh) and reported a successful
   install as missing. Always check both trees. */
static const char *kSshPaths[] = { "/var/jb/usr/bin/ssh", "/usr/bin/ssh", NULL };
static const char *kSshdPaths[] = { "/var/jb/usr/sbin/sshd", "/usr/sbin/sshd", NULL };

static void kill_by_name(const char *nm) {
    int mib[4] = { CTL_KERN, KERN_PROC, KERN_PROC_ALL, 0 };
    size_t len = 0;
    if (sysctl(mib, 3, NULL, &len, NULL, 0) != 0) return;
    struct kinfo_proc *procs = (struct kinfo_proc *)malloc(len * 2);
    if (!procs) return;
    if (sysctl(mib, 3, procs, &len, NULL, 0) != 0) { free(procs); return; }
    size_t count = len / sizeof(struct kinfo_proc);
    for (size_t i = 0; i < count; i++) {
        pid_t pid = procs[i].kp_proc.p_pid;
        if (pid == getpid()) continue;
        if (strcmp(procs[i].kp_proc.p_comm, nm) == 0) {
            printf("  kill(%d, TERM) <- %s\n", pid, nm);
            kill(pid, SIGTERM);
        }
    }
    free(procs);
}

static void cat_head(const char *path, size_t cap) {
    FILE *f = fopen(path, "r");
    if (!f) return;
    char buf[2048];
    size_t n = fread(buf, 1, sizeof(buf) - 1, f);
    fclose(f);
    buf[n] = 0;
    printf("--- %s (head) ---\n%.*s\n", path, (int)(n < cap ? n : cap), buf);
}

static const char *kSshdCfg[] = { "/var/jb/etc/ssh/sshd_config", "/etc/ssh/sshd_config", NULL };

/* OpenSSH honors the FIRST occurrence of a directive -> PREPEND our rules and
   comment out conflicting lines. Original backed up once as .btkit.bak. */
static void fix_one_sshd_config(const char *cfg) {
    FILE *f = fopen(cfg, "r");
    if (!f) { printf("  open %s errno=%d\n", cfg, errno); return; }
    char buf[32768];
    size_t n = fread(buf, 1, sizeof(buf) - 1, f);
    fclose(f);
    buf[n] = 0;
    printf("--- %s BEFORE fix (head) ---\n%.600s\n", cfg, buf);
    char bak[256];
    snprintf(bak, sizeof(bak), "%s.btkit.bak", cfg);
    struct stat sb;
    if (stat(bak, &sb) != 0) {
        FILE *b = fopen(bak, "w");
        if (b) { fwrite(buf, 1, n, b); fclose(b); chmod(bak, 0644); printf("  backup -> %s\n", bak); }
    } else printf("  backup exists -> %s\n", bak);
    char out[40000];
    size_t o = 0;
    o += (size_t)snprintf(out + o, sizeof(out) - o,
        "#btkit-sshfix v2\nPermitRootLogin prohibit-password\nPubkeyAuthentication yes\nAuthorizedKeysFile .ssh/authorized_keys\nUsePAM no\n");
    char *line = buf;
    while (line && *line) {
        char *nl = strchr(line, '\n');
        size_t ll = nl ? (size_t)(nl - line) : strlen(line);
        const char *kw[4] = { "PermitRootLogin", "PubkeyAuthentication", "AuthorizedKeysFile", "UsePAM" };
        int conflict = 0;
        for (int k = 0; k < 4; k++) {
            const char *q = strstr(line, kw[k]);
            if (q && (q == line || q[-1] == ' ' || q[-1] == '\t') && line[0] != '#') conflict = 1;
        }
        if (!conflict && o + ll + 2 < sizeof(out)) {
            memcpy(out + o, line, ll); o += ll;
            out[o++] = '\n';
        }
        line = nl ? nl + 1 : NULL;
    }
    FILE *w = fopen(cfg, "w");
    if (!w) { printf("  write %s errno=%d\n", cfg, errno); return; }
    fwrite(out, 1, o, w);
    fclose(w);
    chmod(cfg, 0644);
    printf("  fixed -> %s\n", cfg);
}

/* TRANSPARENCY LAYER (user-requested CCTV): agent SSH commands + outputs
   are appended to a log the device owner can read live (button 7 / Filza). */
static const char *kWrapLines[] = {
"#!/var/jb/bin/sh\n",
"# agentwrap — every agent SSH command AND its output -> activity log\n",
"LOG=/var/mobile/Documents/agent-activity.log\n",
"[ -f $LOG ] || { touch $LOG; chown 501:501 $LOG; chmod 644 $LOG; }\n",
"SZ=$(wc -c < $LOG 2>/dev/null || echo 0)\n",
"if [ $SZ -gt 300000 ]; then tail -c 120000 $LOG > $LOG.tmp && mv $LOG.tmp $LOG; fi\n",
"echo \"=== $(date '+%d/%m %H:%M:%S') AGENT >>> ${SSH_ORIGINAL_COMMAND:-(interactive shell)}\" >> $LOG\n",
"if [ -n \"$SSH_ORIGINAL_COMMAND\" ]; then\n",
"  /var/jb/bin/sh -c \"$SSH_ORIGINAL_COMMAND\" 2>&1 | tee -a $LOG\n",
"else\n",
"  exec /var/jb/bin/sh -i\n",
"fi\n",
NULL };

static void write_agent_wrap(void) {
    FILE *f = fopen("/var/root/agentwrap.sh", "w");
    if (!f) { printf("agentwrap open errno=%d\n", errno); return; }
    for (int i = 0; kWrapLines[i]; i++) fputs(kWrapLines[i], f);
    fclose(f);
    chmod("/var/root/agentwrap.sh", 0755);
    chown("/var/root/agentwrap.sh", 0, 0);
    printf("CCTV wrapper -> /var/root/agentwrap.sh OK\n");
}

static void do_agentlog(void) {
    printf("== AGENT ACTIVITY LOG (tail, live copy at Filza: Documents/agent-activity.log) ==\n");
    FILE *f = fopen("/var/mobile/Documents/agent-activity.log", "r");
    if (!f) { printf("(empty — no agent sessions yet)\n"); return; }
    fseek(f, 0, SEEK_END);
    long tot = ftell(f);
    fseek(f, tot > 9000 ? tot - 9000 : 0, SEEK_SET);
    char b[1024];
    size_t n;
    while ((n = fread(b, 1, sizeof(b), f)) > 0) fwrite(b, 1, n, stdout);
    fclose(f);
    printf("== end of tail ==\n");
}

static void do_sshfix(void) {
    printf("== SSH DOOR FIX v4 (replace launchd sshd with our own) ==\n");
    const char *sshd = find_first(kSshdPaths);
    const char *ssh = find_first(kSshPaths);
    if (!sshd || !ssh) { printf("sshd/ssh missing — install openssh-server first\n"); return; }
    /* 0) tail of the previous run log = confession of the last agent attempt */
    printf("--- previous sshd-run.log (tail) ---\n");
    FILE *r = fopen("/var/mobile/Documents/sshd-run.log", "r");
    if (r) {
        char b[2048];
        size_t nn;
        fseek(r, 0, SEEK_END);
        long tot = ftell(r);
        fseek(r, tot > 1500 ? tot - 1500 : 0, SEEK_SET);
        while ((nn = fread(b, 1, sizeof(b), r)) > 0) fwrite(b, 1, nn, stdout);
        fclose(r);
    } else printf("(none yet)\n");
    /* 1) free :22 from launchd's sshd */
    char *bo[] = { "/var/jb/bin/launchctl", "bootout", "system/com.openssh.sshd", NULL };
    run_argv(bo);
    kill_by_name("sshd");
    sleep(1);
    /* 1b) also fix sshd_config files (applies when launchd sshd returns after reboot) */
    for (int i = 0; kSshdCfg[i]; i++) {
        struct stat sb2;
        if (stat(kSshdCfg[i], &sb2) == 0) fix_one_sshd_config(kSshdCfg[i]);
    }
    /* 1c) install transparency layer and force ALL agent sessions through it */
    write_agent_wrap();
    /* 2) our own daemon, plain root, bulletproof flags, full logging */
    FILE *t = fopen("/var/mobile/Documents/sshd-run.log", "w");
    if (t) fclose(t);
    chown("/var/mobile/Documents/sshd-run.log", 501, 501);
    fflush(stdout);
    pid_t pid = fork();
    if (pid == 0) {
        setsid();
        int dn = open("/dev/null", O_RDONLY);
        if (dn >= 0) { dup2(dn, 0); if (dn > 2) close(dn); }
        int lf = open("/var/mobile/Documents/sshd-run.log", O_WRONLY | O_CREAT | O_APPEND, 0644);
        char *argv[] = { (char *)sshd, "-p", "22",
            "-o", "PermitRootLogin=prohibit-password",
            "-o", "PubkeyAuthentication=yes",
            "-o", "AuthorizedKeysFile=/var/root/.ssh/authorized_keys",
            "-o", "StrictModes=no", "-o", "UsePAM=no",
            "-o", "ForceCommand=/var/root/agentwrap.sh",
            "-E", "/var/mobile/Documents/sshd-run.log", NULL };
        execv(argv[0], argv);
        dprintf(lf >= 0 ? lf : 2, "EXEC_FAIL our-sshd errno=%d\n", errno);
        _exit(127);
    }
    sleep(2);
    printf("our sshd daemon spawned (pid=%d) on :22, logging to sshd-run.log\n", pid);
    /* 3) phone-local END-TO-END control: fresh real key, real login */
    struct stat sb;
    if (stat("/var/jb/usr/bin/ssh-keygen", &sb) == 0) {
        char *kg[] = { "/var/jb/usr/bin/ssh-keygen", "-t", "ed25519", "-f", "/var/root/.ssh/test_key", "-N", "", "-q", NULL };
        run_argv(kg);
        int fd = open("/var/root/.ssh/authorized_keys", O_WRONLY | O_CREAT | O_APPEND, 0600);
        if (fd >= 0) {
            FILE *kf = fopen("/var/root/.ssh/test_key.pub", "r");
            if (kf) {
                char line[256];
                size_t n = fread(line, 1, sizeof(line) - 1, kf);
                fclose(kf);
                line[n] = 0;
                (void)!write(fd, line, strlen(line));
                if (n == 0 || line[n - 1] != '\n') (void)!write(fd, "\n", 1);
            }
            close(fd);
        }
        printf("--- authorized_keys after control key added ---\n");
        cat_head("/var/root/.ssh/authorized_keys", 4096);
        printf("phone-local end-to-end control (real key, real login):\n");
        char *argv_l[] = { (char *)ssh, "-o", "BatchMode=yes", "-o", "StrictHostKeyChecking=no", "-i", "/var/root/.ssh/test_key", "root@localhost", "echo", "LOCAL-KEY-SSH-OK", NULL };
        run_argv(argv_l);
    } else printf("ssh-keygen not found (skip local control)\n");
    printf("== done — 5 BRIDGE -> COPY LOG -> send; agent tries now ==\n");
}

static void do_sshkey(void) {
    printf("== SSH KEY install (agent access) ==\n");
    const char *sshd = find_first(kSshdPaths);
    printf("sshd: %s\n", sshd ? sshd : "NOT FOUND (install openssh-server first)");
    const char *ssh = find_first(kSshPaths);
    printf("ssh client: %s\n", ssh ? ssh : "NOT FOUND");
    const char *key = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIPhHgd0g/OEzmk19s/2NCoryDnlwU7S37sh/Kudj1rvp arena-agent-temp\n";
    const char *dirs[2] = { "/var/root/.ssh", "/var/mobile/.ssh" };
    for (int i = 0; i < 2; i++) {
        mkdir(dirs[i], 0700);
        chmod(dirs[i], 0700);
        char path[160];
        snprintf(path, sizeof(path), "%s/authorized_keys", dirs[i]);
        int fd = open(path, O_WRONLY | O_CREAT | O_APPEND, 0600);
        if (fd < 0) { printf("  %s: open errno=%d\n", path, errno); continue; }
        (void)!write(fd, key, strlen(key));
        close(fd);
        chmod(path, 0600);
        if (i == 1) { chown(dirs[i], 501, 501); chown(path, 501, 501); }
        printf("  key -> %s OK\n", path);
    }
    if (ssh) {
        printf("self-test (root@localhost via key, BatchMode):\n");
        char *argv[9];
        int ai = 0;
        argv[ai++] = (char *)ssh; argv[ai++] = "-o"; argv[ai++] = "BatchMode=yes";
        argv[ai++] = "-o"; argv[ai++] = "StrictHostKeyChecking=no";
        argv[ai++] = "root@localhost"; argv[ai++] = "echo"; argv[ai++] = "ROOT-SSH-OK";
        argv[ai] = NULL;
        run_argv(argv);
    }
    printf("if ROOT-SSH-OK missing above -> now press 6 SSH FIX\n");
    printf("== SSH KEY done ==\n");
}

static void do_bridge(void) {
    printf("== BRIDGE (pinggy tunnel for agent SSH) ==\n");
    const char *ssh = find_first(kSshPaths);
    if (!ssh) {
        printf("ssh client NOT FOUND in /var/jb/usr/bin or /usr/bin\n");
        printf("install it with (NewTerm):\n");
        printf("  sudo /var/jb/usr/bin/apt install -y openssh-server\n");
        printf("== BRIDGE aborted ==\n");
        return;
    }
    printf("using ssh client: %s\n", ssh);
    /* kill stale tunnel clients only (p_comm exactly "ssh"; sshd untouched) */
    int mib[4] = { CTL_KERN, KERN_PROC, KERN_PROC_ALL, 0 };
    size_t len = 0;
    if (sysctl(mib, 3, NULL, &len, NULL, 0) == 0) {
        struct kinfo_proc *procs = (struct kinfo_proc *)malloc(len * 2);
        if (procs && sysctl(mib, 3, procs, &len, NULL, 0) == 0) {
            size_t count = len / sizeof(struct kinfo_proc);
            for (size_t i = 0; i < count; i++) {
                pid_t pid = procs[i].kp_proc.p_pid;
                if (pid == getpid()) continue;
                if (strcmp(procs[i].kp_proc.p_comm, "ssh") == 0) {
                    printf("  stale tunnel: kill(%d, TERM) <- ssh\n", pid);
                    kill(pid, SIGTERM);
                }
            }
        }
        if (procs) free(procs);
    }
    sleep(1);
    const char *logf = "/var/mobile/Documents/pinggy-bridge.txt";
    FILE *f = fopen(logf, "w");
    if (f) fclose(f);
    chown(logf, 501, 501);
    fflush(stdout);
    pid_t pid = fork();
    if (pid == 0) {
        setsid();
        int lf = open(logf, O_WRONLY | O_CREAT | O_APPEND, 0644);
        if (lf >= 0) { dup2(lf, 1); dup2(lf, 2); if (lf > 2) close(lf); }
        int dn = open("/dev/null", O_RDONLY);
        if (dn >= 0) { dup2(dn, 0); if (dn > 2) close(dn); }
        char *argv[11];
        int ai = 0;
        argv[ai++] = (char *)ssh; argv[ai++] = "-o";
        argv[ai++] = "StrictHostKeyChecking=no"; argv[ai++] = "-o";
        argv[ai++] = "ExitOnForwardFailure=yes"; argv[ai++] = "-p";
        argv[ai++] = "443"; argv[ai++] = "-R0:localhost:22";
        argv[ai++] = "tcp@a.pinggy.io"; argv[ai] = NULL;
        execv(argv[0], argv);
        dprintf(lf >= 0 ? lf : 2, "EXEC_FAIL ssh errno=%d\n", errno);
        _exit(127);
    }
    printf("  tunnel pid=%d detached\n", pid);
    printf("  waiting 12 s for the bridge address...\n");
    sleep(12);
    printf("--- bridge log ---\n");
    FILE *r = fopen(logf, "r");
    if (r) {
        char buf[512];
        size_t n;
        while ((n = fread(buf, 1, sizeof(buf), r)) > 0) fwrite(buf, 1, n, stdout);
        fclose(r);
    }
    printf("--- end ---\n");
    printf("found a line like tcp://....pinggy.io:NNNN ->\n");
    printf("  press COPY LOG and send it to the chat\n");
    printf("empty or error -> check internet, press 5 again\n");
    printf("== BRIDGE done (tunnel keeps running in background) ==\n");
}

int main(int argc, char **argv) {
    setvbuf(stdout, NULL, _IONBF, 0);
    printf("bthelper v0.2.13 (euid=%d uid=%d)\n", geteuid(), getuid());
    if (geteuid() != 0) {
        printf("NO_ROOT: helper is not setuid-root — reinstall BTKit.ipa via TrollStore\n");
        return 3;
    }
    if (argc < 2) { printf("usage: bthelper stop|sweep|restore|sshkey|sshfix|bridge\n"); return 2; }
    if (!strcmp(argv[1], "stop")) do_stop();
    else if (!strcmp(argv[1], "sweep")) do_sweep();
    else if (!strcmp(argv[1], "restore")) do_restore();
    else if (!strcmp(argv[1], "sshkey")) do_sshkey();
    else if (!strcmp(argv[1], "sshfix")) do_sshfix();
    else if (!strcmp(argv[1], "agentlog")) do_agentlog();
    else if (!strcmp(argv[1], "bridge")) do_bridge();
    else {
        printf("unknown cmd %s\n", argv[1]);
        printf("STALE HELPER? if this is the fixed copy at\n  /var/jb/usr/bin/bthelper it is from an older\n  BTKit — remove it in NewTerm:\n  sudo rm /var/jb/usr/bin/bthelper\n  (then this app uses its bundled helper)\n");
        return 2;
    }
    return 0;
}
