#import <UIKit/UIKit.h>
#import "BTAppDelegate.h"

/* crash capture: any uncaught exception is written to Documents so the app can
   show it on next launch — self-diagnosing, no terminal needed */
static void btCrashHandler(NSException *e) {
    @try {
        NSString *s = [NSString stringWithFormat:@"CRASH %@\n%@\n%@",
            e.name, e.reason ?: @"", e.callStackSymbols];
        [s writeToFile:@"/var/mobile/Documents/btkit-crash.txt"
            atomically:YES encoding:NSUTF8StringEncoding error:nil];
    } @catch (__unused NSException *ignored) { }
}

int main(int argc, char *argv[]) {
    @autoreleasepool {
        NSSetUncaughtExceptionHandler(btCrashHandler);
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([BTAppDelegate class]));
    }
}
