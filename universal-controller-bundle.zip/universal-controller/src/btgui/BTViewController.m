#import "BTViewController.h"
#import <spawn.h>
#import <signal.h>
#import <sys/wait.h>
#import <fcntl.h>
#import <unistd.h>
#import <errno.h>

/* BTKit v0.1.4 — privilege resolution with TWO device-local paths (no secrets in chat):
   (1) FIXED SETUID COPY (password-free, one-time 2-line setup in NewTerm):
       /var/jb/usr/bin/bthelper — outside the app bundle the setuid bit IS honored
       (sudo itself is setuid on the rootless jb, proving the mount allows it).
   (2) IN-APP PASSWORD FIELD: sudo -S with the password typed into the app
       (kept in memory only, never saved, never leaves the device).
   Resolution order: fixed copy if present (auto-fallback to sudo if its banner
   shows NO_ROOT and a password is available) -> sudo with typed password ->
   instructions. Auth-failure detection retained from v0.1.3. */
@implementation BTViewController {
    UITextView *_log;
    NSMutableArray<UIButton *> *_btns;
    NSTimer *_liveTimer;
    UITextField *_pw;
    BOOL _busy;
    int _childPid;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];
    _btns = [NSMutableArray new];
    _childPid = -1;

    UILabel *t = [[UILabel alloc] init];
    t.text = @"BTKit — Bluetooth HCI helper";
    t.textColor = [UIColor cyanColor];
    t.font = [UIFont boldSystemFontOfSize:15];
    t.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:t];

    _pw = [[UITextField alloc] init];
    _pw.secureTextEntry = YES;
    _pw.placeholder = @"sudo password (optional — stays on this device)";
    _pw.textColor = [UIColor whiteColor];
    _pw.font = [UIFont systemFontOfSize:13];
    _pw.backgroundColor = [UIColor colorWithWhite:0.12 alpha:1];
    _pw.layer.cornerRadius = 8;
    _pw.autocorrectionType = UITextAutocorrectionTypeNo;
    _pw.autocapitalizationType = UITextAutocapitalizationTypeNone;
    _pw.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:_pw];

    _log = [[UITextView alloc] init];
    _log.editable = NO;
    _log.backgroundColor = [UIColor colorWithWhite:0.08 alpha:1];
    _log.textColor = [UIColor greenColor];
    _log.font = [UIFont monospacedSystemFontOfSize:10 weight:UIFontWeightRegular];
    _log.layer.cornerRadius = 8;
    _log.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:_log];

    [self button:@"1 STOP" action:@selector(stopDaemons)];
    [self button:@"2 SWEEP" action:@selector(sweep)];
    [self button:@"3 RESTORE" action:@selector(restore)];
    [self button:@"4 KEY" action:@selector(sshKey)];
    [self button:@"5 BRIDGE" action:@selector(bridge)];
    [self button:@"6 FIX" action:@selector(sshFix)];
    [self button:@"7 LIVE" action:@selector(agentLog)];
    [self button:@"COPY" action:@selector(copyLog)];

    UIButton *b0 = _btns[0], *b1 = _btns[1], *b2 = _btns[2], *b3 = _btns[3], *b4 = _btns[4], *b5 = _btns[5], *b6 = _btns[6], *b7 = _btns[7];
    for (UIButton *btn in _btns) {
        [btn.widthAnchor constraintEqualToAnchor:self.view.widthAnchor multiplier:0.232].active = YES;
        [btn.heightAnchor constraintEqualToConstant:36].active = YES;
    }
    [NSLayoutConstraint activateConstraints:@[
        [t.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:6],
        [t.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:14],
        [_pw.topAnchor constraintEqualToAnchor:t.bottomAnchor constant:6],
        [_pw.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:12],
        [_pw.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-12],
        [_pw.heightAnchor constraintEqualToConstant:34],
        [b0.bottomAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor constant:-8],
        [b0.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:8],
        [b1.leadingAnchor constraintEqualToAnchor:b0.trailingAnchor constant:6],
        [b1.topAnchor constraintEqualToAnchor:b0.topAnchor],
        [b2.leadingAnchor constraintEqualToAnchor:b1.trailingAnchor constant:6],
        [b2.topAnchor constraintEqualToAnchor:b0.topAnchor],
        [b3.leadingAnchor constraintEqualToAnchor:b2.trailingAnchor constant:6],
        [b3.topAnchor constraintEqualToAnchor:b0.topAnchor],
        [b4.bottomAnchor constraintEqualToAnchor:b0.topAnchor constant:-6],
        [b4.leadingAnchor constraintEqualToAnchor:b0.leadingAnchor],
        [b5.leadingAnchor constraintEqualToAnchor:b4.trailingAnchor constant:6],
        [b5.topAnchor constraintEqualToAnchor:b4.topAnchor],
        [b6.leadingAnchor constraintEqualToAnchor:b5.trailingAnchor constant:6],
        [b6.topAnchor constraintEqualToAnchor:b4.topAnchor],
        [b7.leadingAnchor constraintEqualToAnchor:b6.trailingAnchor constant:6],
        [b7.topAnchor constraintEqualToAnchor:b4.topAnchor],
        [_log.topAnchor constraintEqualToAnchor:_pw.bottomAnchor constant:8],
        [_log.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:10],
        [_log.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-10],
        [_log.bottomAnchor constraintEqualToAnchor:b4.topAnchor constant:-8],
    ]];

    NSString *crash = [NSString stringWithContentsOfFile:@"/var/mobile/Documents/btkit-crash.txt" encoding:NSUTF8StringEncoding error:nil];
    NSString *intro = @"BTKit v0.1.19 ready.\n\nFIRST TIME ONLY (pick one):\n"
        @"A) type your sudo password in the box above\n   (in memory only, never saved/sent)\n"
        @"B) OR one-time setup in NewTerm (2 lines, see\n   chat runbook) — then no password ever\n\n"
        @"LIVE VIEW: กด 7 = ดูสิ่งที่ agent ทำ สด ๆ ทุกวินาที\nUART (later): Airplane ON -> 1 STOP -> 2 SWEEP\n";
    if (crash.length) {
        intro = [NSString stringWithFormat:@"[LAST CRASH CAPTURED — send this log]\n%@\n\n%@", crash, intro];
        [[NSFileManager defaultManager] removeItemAtPath:@"/var/mobile/Documents/btkit-crash.txt" error:nil];
    }
    _log.text = intro;
}

- (void)button:(NSString *)title action:(SEL)a {
    UIButton *b = [UIButton buttonWithType:UIButtonTypeSystem];
    [b setTitle:title forState:UIControlStateNormal];
    b.tintColor = [UIColor cyanColor];
    b.titleLabel.font = [UIFont boldSystemFontOfSize:11];
    b.layer.borderColor = [UIColor cyanColor].CGColor;
    b.layer.borderWidth = 1;
    b.layer.cornerRadius = 8;
    b.translatesAutoresizingMaskIntoConstraints = NO;
    [b addTarget:self action:a forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:b];
    [_btns addObject:b];
}

- (void)append:(NSString *)s {
    dispatch_async(dispatch_get_main_queue(), ^{
        _log.text = [_log.text stringByAppendingString:s];
        [_log scrollRangeToVisible:NSMakeRange(_log.text.length, 0)];
    });
}

- (void)copyLog {
    UIPasteboard.generalPasteboard.string = _log.text;
    [self append:@"\n[COPY] log copied — paste it to the chat\n"];
}

- (void)setBusy:(BOOL)busy {
    _busy = busy;
    for (UIButton *b in _btns) b.enabled = !busy;
}

/* spawn a binary with merged output piped into the log; returns after exit.
   password (optional) is written to its stdin then closed. */
- (void)spawnPath:(NSString *)path args:(NSArray<NSString *> *)args password:(NSString *)password label:(NSString *)label {
    [self append:[NSString stringWithFormat:@"\n===== %@ =====\nspawn: %@\n", label, path]];
    int outp[2], inp[2];
    if (pipe(outp) != 0 || pipe(inp) != 0) {
        [self append:[NSString stringWithFormat:@"[ERROR] pipe() errno=%d\n", errno]];
        return;
    }
    pid_t pid = fork();
    if (pid == 0) {
        close(outp[0]); close(inp[1]);
        dup2(inp[0], 0); close(inp[0]);
        dup2(outp[1], 1); dup2(outp[1], 2); close(outp[1]);
        setpgid(0, 0);
        char *argvv[8] = { (char *)[path UTF8String], NULL, NULL, NULL, NULL, NULL, NULL, NULL };
        int n = 1;
        for (NSString *a in args) argvv[n++] = (char *)[a UTF8String];
        char *env[] = {
            (char *)"PATH=/var/jb/bin:/var/jb/usr/bin:/usr/bin:/bin:/usr/sbin:/sbin",
            (char *)"HOME=/var/root", NULL };
        execve(argvv[0], argvv, env);
        int e = errno;
        char m[96];
        int l = snprintf(m, sizeof(m), "EXEC_FAIL errno=%d (%s)\n", e, strerror(e));
        write(outp[1], m, l);
        _exit(127);
    }
    if (pid < 0) {
        [self append:[NSString stringWithFormat:@"[ERROR] fork() errno=%d\n", errno]];
        close(outp[0]); close(outp[1]); close(inp[0]); close(inp[1]);
        return;
    }
    _childPid = pid;
    close(outp[1]);
    close(inp[0]);
    if (password.length) {
        NSString *pl = [password stringByAppendingString:@"\n"];
        (void)!write(inp[1], [pl UTF8String], [pl lengthOfBytesUsingEncoding:NSUTF8StringEncoding]);
    }
    close(inp[1]);
    [self append:[NSString stringWithFormat:@"[child pid=%d]\n", pid]];

    NSMutableString *collected = [NSMutableString new];
    FILE *fp = fdopen(outp[0], "r");
    char line[512];
    int sawExecFail = 0;
    while (fgets(line, sizeof(line), fp)) {
        NSString *s = [NSString stringWithUTF8String:line] ?: @"(binary)\n";
        [collected appendString:s];
        [self append:s];
        if (strncmp(line, "EXEC_FAIL", 9) == 0) sawExecFail = 1;
    }
    fclose(fp);

    int status = 0;
    pid_t w = 0;
    BOOL timedOut = NO;
    for (int i = 0; i < 1200; i++) {
        w = waitpid(pid, &status, WNOHANG);
        if (w == pid || w < 0) break;
        usleep(100000);
        if (i == 1199) {
            timedOut = YES;
            kill(-pid, SIGKILL);
            waitpid(pid, &status, 0);
        }
    }
    if (timedOut) [self append:@"[TIMEOUT] helper killed after 120s\n"];
    else if (WIFEXITED(status)) [self append:[NSString stringWithFormat:@"[exit %d]\n", WEXITSTATUS(status)]];
    else if (WIFSIGNALED(status)) [self append:[NSString stringWithFormat:@"[killed by signal %d]\n", WTERMSIG(status)]];
    _childPid = -1;

    if ([collected containsString:@"Sorry, try again"] ||
        [collected containsString:@"incorrect password"]) {
        [self append:@"\n[AUTH FAILED] wrong sudo password — fix the box and press again (password stays on-device).\n"];
    } else if ([collected containsString:@"NO_ROOT"] && !timedOut) {
        [self append:@"[NOTE] that copy ran without root.\n"];
    }
    (void)sawExecFail;

    NSString *dir = @"/var/mobile/Documents";
    [[NSFileManager defaultManager] createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil];
    dispatch_async(dispatch_get_main_queue(), ^{
        [_log.text writeToFile:[dir stringByAppendingPathComponent:@"btkit-log.txt"]
                    atomically:YES encoding:NSUTF8StringEncoding error:nil];
    });
}

- (void)runHelper:(NSString *)mode {
    if (_liveTimer) { [_liveTimer invalidate]; _liveTimer = nil; }
    if (_busy) return;
    [self setBusy:YES];

    NSString *appHelper = [[NSBundle mainBundle] pathForResource:@"bthelper" ofType:nil];
    NSString *fixed = @"/var/jb/usr/bin/bthelper";
    NSString *pw = _pw.text ?: @"";

    if ([[NSFileManager defaultManager] fileExistsAtPath:fixed]) {
        /* password-free path: setuid copy at the stable jb location */
        [self spawnPath:fixed args:@[mode] password:nil label:[NSString stringWithFormat:@"%@ (fixed setuid copy)", mode]];
    } else if (pw.length) {
        NSString *sudoPath = nil;
        for (NSString *c in @[@"/var/jb/usr/bin/sudo", @"/var/jb/bin/sudo", @"/usr/bin/sudo"]) {
            if ([[NSFileManager defaultManager] fileExistsAtPath:c]) { sudoPath = c; break; }
        }
        if (!sudoPath) {
            [self append:@"[ERROR] sudo not found — open the Dopamine app first (load the jailbreak), then press again.\n"];
            dispatch_async(dispatch_get_main_queue(), ^{ [self setBusy:NO]; });
            return;
        }
        [self spawnPath:sudoPath args:@[@"-S", @"-p", @"", appHelper, mode] password:pw label:[NSString stringWithFormat:@"%@ (via sudo)", mode]];
    } else {
        [self append:@"\n[NO CREDENTIALS YET]\nPick ONE:\n"
            @"A) type your sudo password in the box above (stays on this device)\n"
            @"B) one-time password-free setup — in NewTerm type these 2 lines:\n"
            @"sudo cp /private/var/containers/Bundle/Application/*/BTKit.app/bthelper /var/jb/usr/bin/bthelper\n"
            @"sudo chmod 6755 /var/jb/usr/bin/bthelper\n"
            @"(re-run those 2 lines whenever you update BTKit)\n"];
        dispatch_async(dispatch_get_main_queue(), ^{ [self setBusy:NO]; });
        return;
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self setBusy:NO];
    });
}

- (void)stopDaemons { [self runHelper:@"stop"]; }
- (void)sweep       { [self runHelper:@"sweep"]; }
- (void)restore     { [self runHelper:@"restore"]; }
- (void)sshKey      { [self runHelper:@"sshkey"]; }
- (void)bridge      { [self runHelper:@"bridge"]; }
- (void)sshFix      { [self runHelper:@"sshfix"]; }
- (void)pollAgent {
    NSString *path = @"/var/mobile/Documents/agent-activity.log";
    if (![[NSFileManager defaultManager] fileExistsAtPath:path])
        [@"" writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];
    NSString *s = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
    NSString *body = (s.length ? s : @"(ยังไม่มีกิจกรรม — รอ agent เชื่อมสาย 5 BRIDGE ก่อน)");
    if (body.length > 7000) body = [body substringFromIndex:body.length - 7000];
    _log.text = [@"--- LIVE: กิจกรรม agent (อัปเดตทุก 1 วิ) ---\n" stringByAppendingString:body];
    [_log scrollRangeToVisible:NSMakeRange(_log.text.length, 0)];
}
- (void)agentLog {
    if (_liveTimer) {
        [_liveTimer invalidate]; _liveTimer = nil;
        [self append:@"\n[LIVE OFF] หยุดจอสดแล้ว (กด 7 เพื่อเปิดใหม่)\n"];
        return;
    }
    _liveTimer = [NSTimer timerWithTimeInterval:1.0 target:self selector:@selector(pollAgent) userInfo:nil repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:_liveTimer forMode:NSRunLoopCommonModes];
    [self append:@"\n[LIVE ON] จอสดเปิดแล้ว — กด 7 ซ้ำเพื่อปิด\n"];
    [self pollAgent];
}

@end
