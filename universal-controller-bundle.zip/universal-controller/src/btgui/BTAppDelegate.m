#import "BTAppDelegate.h"
#import "BTViewController.h"

@implementation BTAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.rootViewController = [[BTViewController alloc] init];
    [self.window makeKeyAndVisible];
    return YES;
}

@end
