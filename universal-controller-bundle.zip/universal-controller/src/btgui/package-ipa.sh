#!/bin/sh
# package-ipa.sh — BTKit (app + setuid root helper), TrollStore install.
set -e
export THEOS=${THEOS:-/home/user/.cache/theos}
export PATH="$THEOS/bin:$PATH"

HELPER=helper/.theos/obj/debug/bthelper
APP=.theos/obj/debug/BTKit.app
[ -f "$HELPER" ] || { echo "helper missing — make it in helper/ first"; exit 1; }
[ -f "$APP/BTKit" ] || { echo "app missing — run make first"; exit 1; }

cat > "$APP/Info.plist" <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>CFBundleDevelopmentRegion</key><string>en</string>
	<key>CFBundleDisplayName</key><string>BTKit</string>
	<key>CFBundleExecutable</key><string>BTKit</string>
	<key>CFBundleIdentifier</key><string>com.research.btkit</string>
	<key>CFBundleInfoDictionaryVersion</key><string>6.0</string>
	<key>CFBundleName</key><string>BTKit</string>
	<key>CFBundlePackageType</key><string>APPL</string>
	<key>CFBundleShortVersionString</key><string>0.1.19</string>
	<key>CFBundleVersion</key><string>20</string>
	<key>MinimumOSVersion</key><string>15.0</string>
	<key>UIRequiresFullScreen</key><true/>
	<key>UISupportedInterfaceOrientations</key>
	<array>
		<string>UIInterfaceOrientationPortrait</string>
	</array>
</dict>
</plist>
EOF

cat > /tmp/btkit.ent.plist <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>platform-application</key><true/>
	<key>com.apple.private.security.no-container</key><true/>
	<key>com.apple.private.security.no-sandbox</key><true/>
</dict>
</plist>
EOF

# helper: sign WITH entitlements, then setuid bit
cp "$HELPER" "$APP/bthelper"
"$THEOS/bin/ldid" -S/tmp/btkit.ent.plist "$APP/bthelper"
chmod 4755 "$APP/bthelper"
"$THEOS/bin/ldid" -S/tmp/btkit.ent.plist "$APP/BTKit"

rm -rf Payload
mkdir Payload
cp -r "$APP" Payload/
OUT=../../artifacts/BTKit.ipa
rm -f "$OUT"
zip -qry "$OUT" Payload
echo "packaged: $OUT"
ls -la "$APP/bthelper" | awk '{print "helper mode:", $1}'
