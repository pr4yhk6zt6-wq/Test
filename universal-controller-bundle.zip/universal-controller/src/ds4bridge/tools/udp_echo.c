/* udp_echo — lab echo server for latency instrumentation of the ControllerA
   UDP transport. Receives ICInputPacket datagrams, flips magic to 'ICRT'
   (IC_MAGIC_RPLY) and sends them back. Prints stats on SIGINT.
   LAB INSTRUMENT (runs on a PC on the same Wi-Fi as iPhone A) — it is NOT part
   of the shipped A→B system and never runs on iPhone B. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include "../../ds4bridge/include/ds4bridge/ic_packet.h"

static volatile sig_atomic_t stopFlag;
static void onint(int s) { (void)s; stopFlag = 1; }

int main(int argc, char **argv) {
    int port = argc > 1 ? atoi(argv[1]) : 37564;
    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) { perror("socket"); return 1; }
    struct sockaddr_in a;
    memset(&a, 0, sizeof(a));
    a.sin_family = AF_INET;
    a.sin_addr.s_addr = htonl(INADDR_ANY);
    a.sin_port = htons((uint16_t)port);
    if (bind(fd, (struct sockaddr *)&a, sizeof(a)) < 0) { perror("bind"); return 1; }
    signal(SIGINT, onint);
    fprintf(stderr, "udp_echo listening on :%d\n", port);

    uint64_t n = 0, bytes = 0;
    uint8_t buf[512];
    struct sockaddr_in from;
    socklen_t fl;
    while (!stopFlag) {
        fl = sizeof(from);
        ssize_t r = recvfrom(fd, buf, sizeof(buf), 0, (struct sockaddr *)&from, &fl);
        if (r < 0) break;
        n++; bytes += (uint64_t)r;
        if ((size_t)r >= sizeof(ICInputPacket)) {
            ICInputPacket *p = (ICInputPacket *)buf;
            if (p->magic == IC_MAGIC) {
                p->magic = IC_MAGIC_RPLY;
                sendto(fd, buf, sizeof(ICInputPacket), 0, (struct sockaddr *)&from, fl);
            } else if (p->magic == IC_MAGIC_RPLY) {
                ICAckPacket *q = (ICAckPacket *)buf;
                (void)q;
            }
        }
    }
    fprintf(stderr, "udp_echo: %llu packets, %llu bytes\n",
            (unsigned long long)n, (unsigned long long)bytes);
    close(fd);
    return 0;
}
