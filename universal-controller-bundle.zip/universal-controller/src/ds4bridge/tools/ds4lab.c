/* ds4lab — BlueZ-based lab backend: a PC + BT dongle stands in for iPhone A
   to validate the FULL protocol identity against a real stock iPhone B.

   STATUS: RESEARCH-GRADE, NOT TESTED (the build sandbox has no Bluetooth
   adapter). It is a lab instrument only — it never ships to users and never
   touches iPhone B's software. If iPhone B pairs to this and shows a working
   controller, then wire format + SDP record + HID channels are validated
   end-to-end and only iPhone-A's chip transport remains (docs/12).

   Requirements on the lab PC:
     - libbluetooth-dev to compile:  make lab
     - a Bluetooth Classic (BR/EDR) adapter
     - bluetoothd STOPPED while running this (we own PSM 1/17/19):
         sudo systemctl stop bluetooth
   Run:  sudo ./tools/ds4lab [--udp 37564] [--demo]
     --udp : accept ICInputPacket datagrams from ControllerA on A (Wi-Fi lab)
     --demo: sweep the sticks automatically (no phone needed)

   Pairing expectation: iPhone B → Settings → Bluetooth → device appears as
   "Wireless Controller"; tap to pair (Just Works). */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <poll.h>
#include <time.h>
#include <stdbool.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#include <bluetooth/bluetooth.h>
#include <bluetooth/l2cap.h>

#include "ds4bridge/hiddev.h"
#include "ds4bridge/sdp.h"
#include "ds4bridge/sdp_server.h"
#include "ds4bridge/ic_packet.h"

#define NAME "Wireless Controller"

typedef struct {
    int lfd[2];  /* listening: [0]=PSM17 control, [1]=PSM19 interrupt */
    int cfd[2];  /* connected */
    int sfd;     /* SDP listener PSM 1 */
    int scfd;
    sdp_server_t *sdp;
} blz;

static uint32_t mono_ms(void) {
    static struct timespec t0; static int init = 0;
    if (!init) { clock_gettime(CLOCK_MONOTONIC, &t0); init = 1; }
    struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t);
    return (uint32_t)((t.tv_sec - t0.tv_sec) * 1000 + (t.tv_nsec - t0.tv_nsec) / 1000000);
}

static void set_nb(int fd) {
    int fl = fcntl(fd, F_GETFL, 0);
    fcntl(fd, F_SETFL, fl | O_NONBLOCK);
}

static int l2_listen(uint16_t psm) {
    int fd = socket(AF_BLUETOOTH, SOCK_SEQPACKET, BTPROTO_L2CAP);
    if (fd < 0) { perror("socket"); exit(1); }
    struct sockaddr_l2 a;
    memset(&a, 0, sizeof(a));
    a.l2_family = AF_BLUETOOTH;
    bacpy(&a.l2_bdaddr, BDADDR_ANY);
    a.l2_psm = htobs(psm);
    if (bind(fd, (struct sockaddr *)&a, sizeof(a)) < 0) { perror("bind psm"); exit(1); }
    if (listen(fd, 2) < 0) { perror("listen"); exit(1); }
    set_nb(fd);
    fprintf(stderr, "listening on L2CAP PSM %u\n", psm);
    return fd;
}

static int l2_accept(int lfd) {
    struct sockaddr_l2 c;
    socklen_t cl = sizeof(c);
    int fd = accept(lfd, (struct sockaddr *)&c, &cl);
    if (fd >= 0) {
        set_nb(fd);
        char addr[24];
        ba2str(&c.l2_bdaddr, addr);
        fprintf(stderr, "connect from %s\n", addr);
    }
    return fd;
}

static int bl_listen(void *c, uint16_t psm) {
    blz *b = (blz *)c;
    if (psm == 17)  b->lfd[0] = l2_listen(psm);
    if (psm == 19)  b->lfd[1] = l2_listen(psm);
    return 0;
}
static int bl_send(void *c, uint16_t psm, const uint8_t *d, size_t len) {
    blz *b = (blz *)c;
    int slot = (psm == 17) ? 0 : 1;
    if (b->cfd[slot] < 0) return -1;
    ssize_t r = write(b->cfd[slot], d, len);
    return (int)r;
}
static void bl_state(void *c, int ns, int os) {
    (void)c;
    fprintf(stderr, "HID state %d -> %d\n", os, ns);
}

static volatile sig_atomic_t g_stop;
static void onint(int s) { (void)s; g_stop = 1; }

int main(int argc, char **argv) {
    int udp_port = 0, demo = 0;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--udp") && i + 1 < argc) udp_port = atoi(argv[++i]);
        else if (!strcmp(argv[i], "--demo")) demo = 1;
    }
    signal(SIGINT, onint);

    uint8_t rec[2048];
    size_t rlen = sdp_build_hid_gamepad_record(rec, sizeof(rec));

    blz b;
    memset(&b, 0, sizeof(b));
    b.cfd[0] = b.cfd[1] = b.scfd = -1;
    b.sdp = sdp_server_new();
    sdp_server_set_record(b.sdp, rec, rlen);

    hiddev_transport_t t = { &b, bl_listen, bl_send, bl_state };
    hiddev_t *h = hiddev_new(&t);

    b.sfd = l2_listen(1); /* SDP — must own PSM 1: stop bluetoothd first! */

    int ufd = -1;
    if (udp_port > 0) {
        ufd = socket(AF_INET, SOCK_DGRAM, 0);
        struct sockaddr_in a;
        memset(&a, 0, sizeof(a));
        a.sin_family = AF_INET;
        a.sin_addr.s_addr = htonl(INADDR_ANY);
        a.sin_port = htons((uint16_t)udp_port);
        if (bind(ufd, (struct sockaddr *)&a, sizeof(a)) < 0) { perror("udp bind"); return 1; }
        set_nb(ufd);
        fprintf(stderr, "UDP input from ControllerA on :%d\n", udp_port);
    }

    fprintf(stderr, "%s: waiting for a phone to pair (SDP record %zu bytes)\n", NAME, rlen);
    uint32_t last = mono_ms(), t0 = last;
    uint8_t in[512], out[1024];
    ICInputPacket udpPkt;
    int haveUdp = 0;

    while (!g_stop) {
        struct pollfd pf[6];
        int n = 0;
        pf[n].fd = b.lfd[0]; pf[n++].events = POLLIN;
        pf[n].fd = b.lfd[1]; pf[n++].events = POLLIN;
        pf[n].fd = b.sfd;    pf[n++].events = POLLIN;
        if (b.cfd[0] >= 0) { pf[n].fd = b.cfd[0]; pf[n++].events = POLLIN; }
        if (b.cfd[1] >= 0) { pf[n].fd = b.cfd[1]; pf[n++].events = POLLIN; }
        if (ufd >= 0)      { pf[n].fd = ufd;      pf[n++].events = POLLIN; }
        poll(pf, (nfds_t)n, 8);

        if (b.cfd[0] < 0 && (pf[0].revents & POLLIN)) { b.cfd[0] = l2_accept(b.lfd[0]); hiddev_on_connected(h, 17); }
        if (b.cfd[1] < 0 && (pf[1].revents & POLLIN)) { b.cfd[1] = l2_accept(b.lfd[1]); hiddev_on_connected(h, 19); }
        if (b.scfd  < 0 && (pf[2].revents & POLLIN))  b.scfd  = l2_accept(b.sfd);

        if (b.cfd[0] >= 0 && (pf[3].revents & POLLIN)) {
            ssize_t r = read(b.cfd[0], in, sizeof(in));
            if (r <= 0) { close(b.cfd[0]); b.cfd[0] = -1; hiddev_on_disconnected(h, 17); }
            else hiddev_on_data(h, 17, in, (size_t)r);
        }
        if (b.cfd[1] >= 0 && (pf[4].revents & POLLIN)) {
            ssize_t r = read(b.cfd[1], in, sizeof(in));
            if (r <= 0) { close(b.cfd[1]); b.cfd[1] = -1; hiddev_on_disconnected(h, 19); }
            /* output reports (rumble/LED) — accepted, not acted on */
        }
        if (b.scfd >= 0 && (pf[2].revents & (POLLIN | POLLHUP))) {
            ssize_t r = read(b.scfd, in, sizeof(in));
            if (r <= 0) { close(b.scfd); b.scfd = -1; }
            else {
                size_t rn = sdp_server_handle(b.sdp, in, (size_t)r, out, sizeof(out));
                if (rn) write(b.scfd, out, rn);
            }
        }
        if (ufd >= 0 && (pf[n - 1].revents & POLLIN)) {
            ssize_t r = recvfrom(ufd, in, sizeof(in), 0, NULL, NULL);
            if (r == sizeof(ICInputPacket) && ic_packet_validate((const ICInputPacket *)in) == 0) {
                udpPkt = *(const ICInputPacket *)in;
                haveUdp = 1;
            }
        }

        uint32_t now = mono_ms();
        if (demo) {
            uint32_t dt = (now - t0) / 10;
            ICInputPacket p;
            memset(&p, 0, sizeof(p));
            p.magic = IC_MAGIC; p.version = IC_VERSION;
            p.lx = (int8_t)((dt % 255) - 127);
            p.ry = (int8_t)(((dt / 255) % 255) - 127);
            p.buttonsA = (uint8_t)(((dt / 2550) % 4) == 0 ? IC_BTN_A : 0);
            p.hat = IC_HAT_NEUTRAL;
            p.seq16 = (uint16_t)(now & 0xFFFF); p.t_ms = now;
            p.crc = ic_crc16((const uint8_t *)&p, offsetof(ICInputPacket, crc));
            hiddev_set_input(h, &p);
        } else if (haveUdp) {
            hiddev_set_input(h, &udpPkt);
        }
        hiddev_tick(h, now);
    }

    fprintf(stderr, "ds4lab: reports=%u bytes=%u — bye\n", hiddev_reports_sent(h), hiddev_bytes_sent(h));
    hiddev_free(h);
    sdp_server_free(b.sdp);
    return 0;
}
