#ifndef DS4BRIDGE_HCI_LINK_H
#define DS4BRIDGE_HCI_LINK_H
#include <stdint.h>
#include <stddef.h>
#include "hci_transport.h"
#include "hiddev.h"

/* Minimal HCI + L2CAP signaling engine for the DEVICE role.
   Owns: HCI command helpers (reset, read_local_version), ACL TX, L2CAP
   signaling (ConnReq/Rsp, ConfReq/Rsp, Disconnect), channel table mapping
   local CIDs to PSM 17/19, and routing into the hiddev state machine.
   The ACL link (connection handle) is established by the platform side
   (BlueTool/internalblued/BlueZ) — this engine reacts to
   HCI_Connection_Complete and then does the L2CAP work. */

/* Company-ID strings are mapped in hci_link_version_str() */

typedef struct hci_link hci_link_t;

hci_link_t *hci_link_new(hci_io_t *io);
void hci_link_free(hci_link_t *l);
void hci_link_bind_hid(hci_link_t *l, hiddev_t *h);

/* inbound (called from the IO pump) */
void hci_link_on_frame(hci_link_t *l, const hci_frame_t *f);

/* commands */
int hci_link_cmd_reset(hci_link_t *l);
int hci_link_cmd_read_local_version(hci_link_t *l);

/* L2CAP */
int hci_link_l2cap_connreq(hci_link_t *l, uint16_t psm);
int hci_link_acl_send(hci_link_t *l, uint16_t cid, const uint8_t *data, size_t len);

void hci_link_on_disconnected(hci_link_t *l);

/* hiddev transport adapter bound to this link (pass to hiddev_new) */
hiddev_transport_t *hci_link_hid_transport(hci_link_t *l);

/* status */
uint16_t    hci_link_handle(const hci_link_t *l);
int         hci_link_version_known(const hci_link_t *l);
const char *hci_link_version_str(const hci_link_t *l);
int         hci_link_psm_up(const hci_link_t *l, uint16_t psm);

#endif
