#ifndef DS4BRIDGE_HIDDEV_H
#define DS4BRIDGE_HIDDEV_H
#include "ic_packet.h"

/* Bluetooth Classic HID *device-role* state machine (HID profile, BTHF style).
   The transport vtable abstracts the L2CAP/HCI layer so the protocol core can
   be unit-tested with transport_null and later driven by an iOS HCI backend
   (research phase) or a BlueZ lab backend. */

enum hiddev_state {
    HIDDEV_IDLE = 0,        /* no control channel                    */
    HIDDEV_CONTROL_UP = 1,  /* control PSM (0x0011) connected        */
    HIDDEV_CONNECTED = 2,   /* interrupt PSM (0x0013) connected too  */
    HIDDEV_REPORTING = 3,   /* sending input reports                 */
    HIDDEV_STALE = 4        /* connected but input is stale (neutral)*/
};

#define HID_PSM_CONTROL   0x0011
#define HID_PSM_INTERRUPT 0x0013

/* HID trans types (HID profile spec, byte0 high nibble) */
#define HID_TRANS_HANDSHAKE   0x0
#define HID_TRANS_CONTROL     0x1
#define HID_TRANS_GET_REPORT  0x4
#define HID_TRANS_SET_REPORT  0x5
#define HID_TRANS_GET_PROTOCOL 0x6
#define HID_TRANS_SET_PROTOCOL 0x7
#define HID_TRANS_DATA        0xA
#define HID_PARAM_INPUT  0x1
#define HID_PARAM_OUTPUT 0x2

typedef struct hiddev_transport {
    void *ctx;
    int  (*listen)(void *ctx, uint16_t psm);
    int  (*send)(void *ctx, uint16_t psm, const uint8_t *data, size_t len);
    void (*on_state)(void *ctx, int new_state, int old_state);
} hiddev_transport_t;

typedef struct hiddev hiddev_t;

hiddev_t *hiddev_new(const hiddev_transport_t *t);
void hiddev_free(hiddev_t *h);

/* Inbound events (called by the transport backend) */
void hiddev_on_connected(hiddev_t *h, uint16_t psm);
void hiddev_on_disconnected(hiddev_t *h, uint16_t psm);
void hiddev_on_data(hiddev_t *h, uint16_t psm, const uint8_t *data, size_t len);

/* Controller input feed + engine tick */
void hiddev_set_input(hiddev_t *h, const ICInputPacket *p);
void hiddev_tick(hiddev_t *h, uint32_t now_ms);

int      hiddev_state(hiddev_t *h);
uint32_t hiddev_reports_sent(hiddev_t *h);
uint32_t hiddev_bytes_sent(hiddev_t *h);
void     hiddev_set_report_interval(hiddev_t *h, uint32_t ms);

#endif
