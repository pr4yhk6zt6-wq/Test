/* ds4bridge — iPhone A → iPhone B universal controller, Phase-3 protocol core.
   Portable C11. Host-tested on Linux x86_64; cross-compiled for iOS arm64
   via Theos (see src/ds4bridged-theos). transport backends are pluggable:
   - transport_null.c  : in-memory, used by unit tests (VERIFIED)
   - bluez / iOS HCI   : research backends (NOT IMPLEMENTED — see docs/05-architecture.md)
*/
#ifndef DS4BRIDGE_IC_PACKET_H
#define DS4BRIDGE_IC_PACKET_H

#include <stdint.h>
#include <stddef.h>
#include <string.h>

#define IC_MAGIC      0x4943544Cu /* 'ICTL' */
#define IC_MAGIC_RPLY 0x49435452u /* 'ICRT' */
#define IC_VERSION    1

#pragma pack(push, 1)
typedef struct {
    uint32_t magic;
    uint8_t  version;
    uint8_t  buttonsA; /* A B X Y L1 R1 MENU VIEW */
    uint8_t  buttonsB; /* LS RS DU DD DL DR */
    int8_t   lx, ly, rx, ry;
    uint8_t  l2, r2;
    uint8_t  hat;      /* 0..7, 8 neutral */
    uint8_t  seq8;
    uint16_t seq16;
    uint32_t t_ms;
    uint16_t crc;      /* CRC-16/CCITT-FALSE over bytes [0, offsetof(crc)) */
    uint16_t reserved;
} ICInputPacket; /* 25 bytes */

typedef struct {
    uint32_t magic;
    uint16_t seq16;
    uint32_t t_ms;
} ICAckPacket; /* 10 bytes */
#pragma pack(pop)

#define IC_BTN_A     (1 << 0)
#define IC_BTN_B     (1 << 1)
#define IC_BTN_X     (1 << 2)
#define IC_BTN_Y     (1 << 3)
#define IC_BTN_L1    (1 << 4)
#define IC_BTN_R1    (1 << 5)
#define IC_BTN_MENU  (1 << 6)
#define IC_BTN_VIEW  (1 << 7)
#define IC_BTN_LS    (1 << 0)
#define IC_BTN_RS    (1 << 1)
#define IC_BTN_DUP   (1 << 2)
#define IC_BTN_DDOWN (1 << 3)
#define IC_BTN_DLEFT (1 << 4)
#define IC_BTN_DRIGHT (1 << 5)

#define IC_HAT_NEUTRAL 8
#define IC_STALE_MS 250

uint16_t ic_crc16(const uint8_t *data, size_t len);
int ic_packet_validate(const ICInputPacket *p); /* 0 = ok, -1 bad */

#endif
