#ifndef DS4BRIDGE_TRANSPORT_NULL_H
#define DS4BRIDGE_TRANSPORT_NULL_H
#include "hiddev.h"
#include <stddef.h>

/* In-memory transport used by unit tests and the ds4bridged self-test. */
typedef struct {
    uint8_t  buf[64 * 1024];
    size_t   len;
    uint16_t psms[8];
    int      nlisten;
    int      stateCalls;
    int      lastState, prevState;
} null_ctx;

const hiddev_transport_t *hiddev_transport_null(null_ctx *ctx);
size_t null_len(null_ctx *n);
void   null_reset(null_ctx *n);
int    null_find_frame(null_ctx *n, uint16_t psm, const uint8_t **frame, size_t flen);
int    null_listened(null_ctx *n, uint16_t psm);
void   null_host_connect(hiddev_t *h, uint16_t psm);

#endif
