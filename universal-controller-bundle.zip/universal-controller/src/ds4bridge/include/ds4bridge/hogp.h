#ifndef DS4BRIDGE_HOGP_H
#define DS4BRIDGE_HOGP_H
#include <stdint.h>
#include <stddef.h>

/* HID-over-GATT (HOGP) database definition for the BLE alternative identity.
   Primary identity: Nintendo Joy-Con shaped (iOS 16+ natively supports
   Joy-Cons; BLE transport). The exact Joy-Con GATT layout requires a live
   capture for byte-accuracy — identity fields below are marked UNKNOWN where
   they are inferred. This DB is what a chip-level BLE peripheral (Phase-3
   alternative) must serve over ATT; note iOS blocks HOGP only at the
   CoreBluetooth API level, NOT at the radio/chip level. */

typedef struct {
    uint16_t handle;
    uint16_t uuid16;   /* SIG 16-bit UUID */
    const uint8_t *value;
    size_t vlen;
} hogp_att_t;

const hogp_att_t *hogp_joycon_db(size_t *count);

/* Joy-Con-shaped gamepad report map (placeholder identity: 2 axes + 14
   buttons — byte-exact map needs a capture; see docs/12 Phase-3). */
extern const uint8_t hogp_joycon_report_map[];
extern const size_t  hogp_joycon_report_map_len;

/* PnP ID (2A50) value: source=USB(2), VID 0x057E (Nintendo),
   PID 0x2006 (Joy-Con L — inferred, UNKNOWN-verify), version 0x0001.
   7 bytes little-endian per Bluetooth spec. */
void hogp_pnp_bytes(uint8_t out[7]);

/* Appearance value (2A01): Gamepad = 0x03C4 (964) */
#define HOGP_APPEARANCE_GAMEPAD 0x03C4

#endif
