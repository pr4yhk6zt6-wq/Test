#ifndef DS4BRIDGE_SDP_SERVER_H
#define DS4BRIDGE_SDP_SERVER_H
#include <stdint.h>
#include <stddef.h>

/* Minimal Bluetooth SDP responder serving ONE service record (our HID
   gamepad record). Implements ServiceSearchAttributeRequest (PDU 0x06) with
   proper continuation — exactly what a phone needs to see a HID device
   during SDP discovery. This is the piece the Phase-3 host stack (on-device
   over HCI, or the ds4lab BlueZ backend) serves on L2CAP PSM 1.
   Unit-tested at byte level (tests/test_all.c). */

typedef struct sdp_server sdp_server_t;

sdp_server_t *sdp_server_new(void);
void sdp_server_free(sdp_server_t *s);

/* record = full SDP record as built by sdp_build_hid_gamepad_record() */
void sdp_server_set_record(sdp_server_t *s, const uint8_t *record, size_t len);

/* Handle one inbound SDP PDU; writes response PDU into out.
   Returns response length, or 0 if no response (shouldn't happen). */
size_t sdp_server_handle(sdp_server_t *s, const uint8_t *in, size_t inlen,
                         uint8_t *out, size_t outcap);

/* test hooks */
size_t sdp_server_results_len(const sdp_server_t *s);
const uint8_t *sdp_server_results(const sdp_server_t *s);

#endif
