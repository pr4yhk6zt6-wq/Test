#ifndef DS4BRIDGE_HID_MAP_H
#define DS4BRIDGE_HID_MAP_H
#include <stdint.h>
#include <stddef.h>

/* DS4-shaped gamepad HID report map (Generic Desktop / Gamepad, X/Y/Z/Rz axes,
   hat, 14 buttons). DS4 v1 byte-exact clone is a Phase-3 TODO pending live
   BT capture (docs/04-research-dossier.md, R4). */
extern const uint8_t ds4_gamepad_report_map[];
extern const size_t  ds4_gamepad_report_map_len;

/* Minimal HID item-stream validator: balanced collections, sane item sizes,
   presence of Gamepad + Button usages. Returns 0 on success, -1 on failure. */
int hid_validate_report_map(const uint8_t *map, size_t len);

#endif
