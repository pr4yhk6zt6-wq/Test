#ifndef DS4BRIDGE_SDP_H
#define DS4BRIDGE_SDP_H
#include <stdint.h>
#include <stddef.h>

/* Builds a Bluetooth SDP service record for a HID device presenting as a
   gamepad (HID class 0x1124, L2CAP PSM 17 control / 19 interrupt,
   HIDDescriptorList carrying the report map).
   PnP identity lives in a SEPARATE DeviceID record (real controllers expose
   two records; attr id spaces would otherwise collide).
   Layout: one DES containing (UINT16 attr-id, element) pairs. */
size_t sdp_build_hid_gamepad_record(uint8_t *buf, size_t cap);
size_t sdp_build_pnp_record(uint8_t *buf, size_t cap);

/* Minimal structural validator: balanced DES, finds attribute by id,
   checks HIDDescriptorList contains type 0x22 element. 0 = ok. */
int sdp_validate_record(const uint8_t *buf, size_t len);
int sdp_find_attr(const uint8_t *buf, size_t len, uint16_t attr_id,
                  const uint8_t **val, size_t *val_len);

#endif
