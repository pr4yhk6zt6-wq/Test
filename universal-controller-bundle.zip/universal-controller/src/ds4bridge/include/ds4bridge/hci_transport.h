#ifndef DS4BRIDGE_HCI_TRANSPORT_H
#define DS4BRIDGE_HCI_TRANSPORT_H
#include <stdint.h>
#include <stddef.h>
#include <sys/types.h>

/* HCI IO backend interface + raw-stream framer.
   Framing: UART-style stream with 1-byte type prefixes
     0x01 CMD (opcode 2 + plen 1 + payload)
     0x02 ACL (handle|flags 2 + dlen 2 + payload)
     0x04 EVT (code 1 + plen 1 + payload)
   This is the wire format used by Broadcom UART controllers and by
   internalblued-style TCP HCI bridges [E14]. Byte-level framing is unit-tested;
   compatibility with a specific bridge deployment is UNKNOWN until G3 runs
   on-device (docs/12). */

typedef struct hci_io {
    void *ctx;
    int     (*open)(void *ctx);
    void    (*close)(void *ctx);
    ssize_t (*write)(void *ctx, const uint8_t *buf, size_t len);
    ssize_t (*read)(void *ctx, uint8_t *buf, size_t cap); /* blocking read */
} hci_io_t;

typedef struct hci_frame {
    uint8_t  type;    /* 0x01 CMD, 0x02 ACL, 0x04 EVT */
    uint16_t handle;  /* ACL: handle|flags as on wire */
    uint16_t len;     /* payload length */
    const uint8_t *data; /* payload, valid until next hci_reader_feed */
} hci_frame_t;

typedef struct hci_reader hci_reader_t;
hci_reader_t *hci_reader_new(void);
void hci_reader_free(hci_reader_t *r);
/* Feed raw stream bytes. Returns 1 when a complete frame is in *f,
   0 when more bytes are needed, -1 on protocol error. */
int hci_reader_feed(hci_reader_t *r, const uint8_t *buf, size_t len, hci_frame_t *f);

/* TCP io backend (internalblued-style bridge client) */
hci_io_t *hci_io_tcp(const char *host, uint16_t port); /* singleton ctx, free with close+free */

/* Direct UART backend (iPhone A: /dev/uart.bluetooth). Raw termios (skipped for
   non-tty fds, e.g. socketpair in tests). On open failure the returned io's
   open() reproduces the original errno. */
hci_io_t *hci_io_uart(const char *path, int baud);
hci_io_t *hci_io_uart_fd(int fd, const char *label);

#endif
