#ifndef DS4BRIDGE_DS4_REPORT_H
#define DS4BRIDGE_DS4_REPORT_H
#include "ic_packet.h"

/* Builds the DS4-style Bluetooth input report 0x11 (49 bytes total).
   Layout follows public DualShock 4 v1 documentation (see docs/04,
   evidence E9); byte-exactness against a live DS4 capture is a Phase-3
   verification step, NOT yet verified on hardware. */
#define DS4_BT_REPORT_LEN 49

void ds4_build_input_report_0x11(const ICInputPacket *in, uint8_t out[DS4_BT_REPORT_LEN]);
void ds4_build_neutral_report(uint8_t out[DS4_BT_REPORT_LEN]);

#endif
