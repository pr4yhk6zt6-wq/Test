#include "ds4bridge/sdp_server.h"
#include <stdlib.h>
#include <string.h>

#define SDP_PDU_ERROR            0x01
#define SDP_PDU_SVC_SEARCH_ATTR_REQ 0x06
#define SDP_PDU_SVC_SEARCH_ATTR_RSP 0x07
#define SDP_MAX_RESULTS_BUF 1024

struct sdp_server {
    uint8_t record[1024];
    size_t  record_len;
    uint8_t results[SDP_MAX_RESULTS_BUF];
    size_t  results_len;
    size_t  results_off; /* continuation cursor */
};

sdp_server_t *sdp_server_new(void) {
    sdp_server_t *s = (sdp_server_t *)calloc(1, sizeof(*s));
    return s;
}
void sdp_server_free(sdp_server_t *s) { free(s); }

void sdp_server_set_record(sdp_server_t *s, const uint8_t *record, size_t len) {
    if (!s || !record || len == 0 || len > sizeof(s->record)) return;
    memcpy(s->record, record, len);
    s->record_len = len;
    s->results_len = 0;
    s->results_off = 0;
}

size_t sdp_server_results_len(const sdp_server_t *s) { return s ? s->results_len : 0; }
const uint8_t *sdp_server_results(const sdp_server_t *s) { return s ? s->results : NULL; }

/* --- tiny SDP element walker --- */
typedef struct { const uint8_t *start; const uint8_t *val; size_t len; } sdp_elem;

static const uint8_t *elem_parse(const uint8_t *p, const uint8_t *end, sdp_elem *e) {
    if (!p || p >= end) return NULL;
    uint8_t b = *p++;
    uint8_t t = (uint8_t)(b >> 3), i = (uint8_t)(b & 0x07);
    size_t sz = 0, hdr = 0;
    switch (i) {
        case 0: sz = 1; break;
        case 1: sz = 2; break;
        case 2: sz = 4; break;
        case 3: sz = 8; break;
        case 4: sz = 16; break;
        case 5: if (p + 1 > end) return NULL; sz = p[0]; hdr = 1; break;
        case 6: if (p + 2 > end) return NULL; sz = (size_t)p[0] << 8 | p[1]; hdr = 2; break;
        case 7: if (p + 4 > end) return NULL; sz = (size_t)p[0] << 24 | (size_t)p[1] << 16 | (size_t)p[2] << 8 | p[3]; hdr = 4; break;
        default: return NULL;
    }
    if (p + hdr + sz > end) return NULL;
    (void)t;
    e->start = p - 1;
    e->val = p + hdr;
    e->len = sz;
    return p + hdr + sz;
}

static const uint8_t *des_payload(const uint8_t *p, const uint8_t *end, const uint8_t **dp, const uint8_t **de) {
    if (p + 2 > end) return NULL;
    if (p[0] == 0x35) { /* DES with 1-byte size (common in requests) */
        size_t payload = p[1];
        if (p + 2 + payload > end) return NULL;
        *dp = p + 2; *de = p + 2 + payload;
        return *de;
    }
    if (p[0] == 0x36) { /* DES with 2-byte size */
        size_t payload = (size_t)p[1] << 8 | p[2];
        if (p + 3 + payload > end) return NULL;
        *dp = p + 3; *de = p + 3 + payload;
        return *de;
    }
    return NULL;
}

/* iterate (attrid, value) pairs of our record: record = DES of [UINT16 id, element] */
typedef void (*pair_fn)(void *ud, uint16_t id, const uint8_t *val, size_t vlen);

static int record_walk(const uint8_t *rec, size_t len, pair_fn fn, void *ud) {
    const uint8_t *p, *pe;
    if (!des_payload(rec, rec + len, &p, &pe)) return -1;
    while (p < pe) {
        if (p + 3 > pe || p[0] != 0x09) return -1; /* attribute id = UINT16 */
        uint16_t id = (uint16_t)((p[1] << 8) | p[2]);
        p += 3;
        sdp_elem e;
        p = elem_parse(p, pe, &e);
        if (!p) return -1;
        if (fn) fn(ud, id, e.val, e.len);
    }
    return 0;
}

/* collect attr ids from AttributeIDList (DES of UINT16 min,max ranges) */
#define MAX_RANGES 32
typedef struct { uint16_t lo, hi; } range;
typedef struct { range r[MAX_RANGES]; int n; } ranges;

static int parse_ranges(const uint8_t *list, size_t len, ranges *rg) {
    const uint8_t *p, *pe;
    if (!des_payload(list, list + len, &p, &pe)) return -1;
    while (p + 3 <= pe) {
        if (p[0] != 0x09) return -1;
        uint16_t lo = (uint16_t)((p[1] << 8) | p[2]);
        p += 3;
        if (p + 3 > pe || p[0] != 0x09) return -1;
        uint16_t hi = (uint16_t)((p[1] << 8) | p[2]);
        p += 3;
        if (rg->n < MAX_RANGES) { rg->r[rg->n].lo = lo; rg->r[rg->n].hi = hi; rg->n++; }
    }
    return rg->n ? 0 : -1;
}

typedef struct {
    uint8_t *buf; size_t cap, len; int err;
    ranges rg;
} writer;

static void w_byte(writer *w, uint8_t b) { if (w->len < w->cap) w->buf[w->len++] = b; else w->err = -1; }
static void w_bytes(writer *w, const uint8_t *d, size_t n) { for (size_t i = 0; i < n; i++) w_byte(w, d[i]); }

static void pair_write(void *ud, uint16_t id, const uint8_t *val, size_t vlen) {
    writer *w = (writer *)ud;
    for (int i = 0; i < w->rg.n; i++) {
        if (id >= w->rg.r[i].lo && id <= w->rg.r[i].hi) {
            w_byte(w, 0x09);
            w_byte(w, (uint8_t)(id >> 8));
            w_byte(w, (uint8_t)id);
            w_bytes(w, val, vlen);
            return;
        }
    }
}

/* build results = DES{ DES{ (id,elem)... } } for the ranges */
static int build_results(sdp_server_t *s, const ranges *rg) {
    writer w = { s->results, sizeof(s->results), 0, 0, *rg };
    /* placeholder outer DES */
    size_t outer = 0;
    w_byte(&w, 0x36); w_byte(&w, 0); w_byte(&w, 0);
    outer = 0;
    size_t inner = w.len;
    w_byte(&w, 0x36); w_byte(&w, 0); w_byte(&w, 0);
    if (record_walk(s->record, s->record_len, pair_write, &w) != 0) return -1;
    if (w.err) return -1;
    /* close inner + outer */
    size_t ip = w.len - inner - 3, op = w.len - outer - 3;
    w.buf[inner + 1] = (uint8_t)(ip >> 8); w.buf[inner + 2] = (uint8_t)ip;
    w.buf[outer + 1] = (uint8_t)(op >> 8); w.buf[outer + 2] = (uint8_t)op;
    s->results_len = w.len;
    s->results_off = 0;
    return 0;
}

/* writer for response */
static void r_put16(uint8_t *out, size_t *n, size_t cap, uint16_t v) {
    if (*n + 2 <= cap) { out[(*n)++] = (uint8_t)(v >> 8); out[(*n)++] = (uint8_t)v; }
}

size_t sdp_server_handle(sdp_server_t *s, const uint8_t *in, size_t inlen,
                         uint8_t *out, size_t outcap) {
    if (!s || !in || inlen < 7 || !out || outcap < 10) return 0;
    uint8_t pdu = in[0];
    uint16_t tid = (uint16_t)((in[1] << 8) | in[2]);
    uint16_t plen = (uint16_t)((in[3] << 8) | in[4]);
    if ((size_t)plen + 5 > inlen) { plen = (uint16_t)(inlen - 5); } /* tolerate */

    const uint8_t *p = in + 5, *end = in + 5 + plen;

    if (pdu == SDP_PDU_SVC_SEARCH_ATTR_REQ) {
        /* ServiceSearchPattern DES */
        sdp_elem pat;
        const uint8_t *q = elem_parse(p, end, &pat);
        if (!q) goto malformed;
        if (q + 2 > end) goto malformed;
        uint16_t maxbytes = (uint16_t)((q[0] << 8) | q[1]);
        q += 2;
        /* AttributeIDList DES */
        sdp_elem list;
        const uint8_t *q2 = elem_parse(q, end, &list);
        if (!q2) goto malformed;
        /* ContinuationState */
        if (q2 >= end) goto malformed;
        uint8_t clen = *q2++;
        if (q2 + clen > end) goto malformed;

        int fresh = (clen == 0);
        if (fresh) {
            ranges rg;
            memset(&rg, 0, sizeof(rg));
            if (parse_ranges(list.start, (size_t)(list.val - list.start) + list.len, &rg) != 0) goto malformed;
            if (build_results(s, &rg) != 0) goto malformed;
        }
        /* if continuation present but we have no buffered results: malformed */
        if (!fresh && s->results_len == 0) goto malformed;

        size_t remaining = s->results_len - s->results_off;
        size_t hdrspace = 6 + 2 + 1 + 2; /* pdu+tid+plen + bytecount + contlen + cont */
        size_t cap = outcap - hdrspace;
        size_t maxc = maxbytes ? maxbytes : remaining;
        if (maxc > cap) maxc = cap;
        size_t chunk = remaining < maxc ? remaining : maxc;

        size_t n = 0;
        out[n++] = SDP_PDU_SVC_SEARCH_ATTR_RSP;
        r_put16(out, &n, outcap, tid);
        size_t plenpos = n;
        n += 2; /* fill later */
        r_put16(out, &n, outcap, (uint16_t)chunk);
        memcpy(out + n, s->results + s->results_off, chunk);
        n += chunk;
        if (s->results_off + chunk < s->results_len) {
            s->results_off += chunk;
            out[n++] = 2;
            out[n++] = (uint8_t)(s->results_off >> 8);
            out[n++] = (uint8_t)(s->results_off & 0xFF);
        } else {
            s->results_off = 0;
            out[n++] = 0;
        }
        uint16_t rplen = (uint16_t)(n - 5);
        out[plenpos] = (uint8_t)(rplen >> 8);
        out[plenpos + 1] = (uint8_t)(rplen & 0xFF);
        return n;
    }

malformed:
    {
        size_t n = 0;
        out[n++] = SDP_PDU_ERROR;
        r_put16(out, &n, outcap, tid);
        r_put16(out, &n, outcap, 2);
        r_put16(out, &n, outcap, 0x0003); /* Invalid request syntax */
        return n;
    }
}
