#include <string.h>
#include "ds4bridge/sdp.h"
#include "ds4bridge/hid_map.h"

/* ---- tiny SDP element builder ---- */
typedef struct { uint8_t *buf; size_t cap, len; int err; } sb;

static void sb_byte(sb *s, uint8_t b) {
    if (s->len + 1 <= s->cap) s->buf[s->len++] = b; else s->err = -1;
}
static void sb_bytes(sb *s, const uint8_t *d, size_t n) {
    for (size_t i = 0; i < n; i++) sb_byte(s, d[i]);
}
static size_t sb_des_open(sb *s) { /* DES with 2-byte size placeholder */
    size_t pos = s->len;
    sb_byte(s, 0x36); sb_byte(s, 0); sb_byte(s, 0);
    return pos;
}
static void sb_des_close(sb *s, size_t pos) {
    size_t payload = s->len - pos - 3;
    s->buf[pos + 1] = (uint8_t)(payload >> 8);
    s->buf[pos + 2] = (uint8_t)(payload & 0xFF);
}
static void sb_attr_u16(sb *s, uint16_t id, uint16_t v) {
    sb_byte(s, 0x09); sb_byte(s, (uint8_t)(id >> 8)); sb_byte(s, (uint8_t)id); /* UINT16 attr id */
    sb_byte(s, 0x09); sb_byte(s, (uint8_t)(v >> 8)); sb_byte(s, (uint8_t)v);   /* UINT16 value */
}
static void sb_attr_u8(sb *s, uint16_t id, uint8_t v) {
    sb_byte(s, 0x09); sb_byte(s, (uint8_t)(id >> 8)); sb_byte(s, (uint8_t)id);
    sb_byte(s, 0x08); sb_byte(s, v);
}
static void sb_attr_bool(sb *s, uint16_t id, int v) {
    sb_byte(s, 0x09); sb_byte(s, (uint8_t)(id >> 8)); sb_byte(s, (uint8_t)id);
    sb_byte(s, 0x28); sb_byte(s, (uint8_t)(v ? 1 : 0));
}
static void sb_attr_text(sb *s, uint16_t id, const char *t) {
    size_t n = strlen(t);
    sb_byte(s, 0x09); sb_byte(s, (uint8_t)(id >> 8)); sb_byte(s, (uint8_t)id);
    sb_byte(s, 0x26); sb_byte(s, (uint8_t)(n >> 8)); sb_byte(s, (uint8_t)n); /* TEXT len16 */
    sb_bytes(s, (const uint8_t *)t, n);
}

size_t sdp_build_hid_gamepad_record(uint8_t *buf, size_t cap) {
    sb s = { buf, cap, 0, 0 };
    size_t root = sb_des_open(&s);

    /* 0x0001 ServiceClassIDList */
    {
        sb_byte(&s, 0x09); sb_byte(&s, 0x00); sb_byte(&s, 0x01);
        size_t d = sb_des_open(&s);
        sb_byte(&s, 0x19); sb_byte(&s, 0x11); sb_byte(&s, 0x24); /* UUID16 0x1124 HID */
        sb_des_close(&s, d);
    }
    /* 0x0004 ProtocolDescriptorList: L2CAP/PSM17 -> HIDP */
    {
        sb_byte(&s, 0x09); sb_byte(&s, 0x00); sb_byte(&s, 0x04);
        size_t d = sb_des_open(&s);
        size_t d1 = sb_des_open(&s);
        sb_byte(&s, 0x19); sb_byte(&s, 0x01); sb_byte(&s, 0x00); /* L2CAP */
        sb_byte(&s, 0x19); sb_byte(&s, 0x00); sb_byte(&s, 0x11); /* PSM 17 */
        sb_des_close(&s, d1);
        d1 = sb_des_open(&s);
        sb_byte(&s, 0x19); sb_byte(&s, 0x00); sb_byte(&s, 0x11); /* HIDP */
        sb_des_close(&s, d1);
        sb_des_close(&s, d);
    }
    /* 0x0005 BrowseGroupList */
    {
        sb_byte(&s, 0x09); sb_byte(&s, 0x00); sb_byte(&s, 0x05);
        size_t d = sb_des_open(&s);
        sb_byte(&s, 0x19); sb_byte(&s, 0x10); sb_byte(&s, 0x02);
        sb_des_close(&s, d);
    }
    /* 0x0006 LanguageBaseAttributeIDList */
    {
        sb_byte(&s, 0x09); sb_byte(&s, 0x00); sb_byte(&s, 0x06);
        size_t d = sb_des_open(&s);
        sb_byte(&s, 0x19); sb_byte(&s, 0x65); sb_byte(&s, 0x6E); /* 'en' */
        sb_byte(&s, 0x09); sb_byte(&s, 0x00); sb_byte(&s, 0x6A);
        sb_byte(&s, 0x09); sb_byte(&s, 0x01); sb_byte(&s, 0x00);
        sb_des_close(&s, d);
    }
    /* 0x0009 BluetoothProfileDescriptorList: HID 1.00 */
    {
        sb_byte(&s, 0x09); sb_byte(&s, 0x00); sb_byte(&s, 0x09);
        size_t d = sb_des_open(&s);
        size_t d1 = sb_des_open(&s);
        sb_byte(&s, 0x19); sb_byte(&s, 0x11); sb_byte(&s, 0x24);
        sb_byte(&s, 0x09); sb_byte(&s, 0x01); sb_byte(&s, 0x00);
        sb_des_close(&s, d1);
        sb_des_close(&s, d);
    }
    /* 0x000D AdditionalProtocolDescriptorList: L2CAP/PSM19 -> HIDP (interrupt) */
    {
        sb_byte(&s, 0x09); sb_byte(&s, 0x00); sb_byte(&s, 0x0D);
        size_t d = sb_des_open(&s);
        size_t d1 = sb_des_open(&s);
        sb_byte(&s, 0x19); sb_byte(&s, 0x01); sb_byte(&s, 0x00);
        sb_byte(&s, 0x19); sb_byte(&s, 0x00); sb_byte(&s, 0x13); /* PSM 19 */
        sb_des_close(&s, d1);
        d1 = sb_des_open(&s);
        sb_byte(&s, 0x19); sb_byte(&s, 0x00); sb_byte(&s, 0x11);
        sb_des_close(&s, d1);
        sb_des_close(&s, d);
    }
    /* PnP identity (VID 0x054C Sony, PID 0x09CC DS4v2, VendorIDSource USB) */
    sb_attr_u16(&s, 0x0200, 0x0103); /* SpecificationID */
    sb_attr_u16(&s, 0x0201, 0x054C); /* VendorID        */
    sb_attr_u16(&s, 0x0202, 0x09CC); /* ProductID       */
    sb_attr_u16(&s, 0x0203, 0x8100); /* Version         */
    sb_attr_bool(&s, 0x0204, 1);     /* PrimaryRecord   */
    sb_attr_u16(&s, 0x0205, 0x0002); /* VendorIDSource  */
    /* HID attributes (ids shared with PnP in real combined records are avoided:
       0x0202..0x020C carry the HID attributes here) */
    sb_attr_u16(&s, 0x0201, 0x0111); /* HIDParserVersion (PnP VendorID kept at 0x0201? NO:
                                        PnP VendorID already at 0x0201 — use HID ids 0x0202+ only,
                                        drop the colliding pair) */
    sb_attr_u8 (&s, 0x0202, 0x08);       /* HIDDeviceSubclass: gamepad */
    sb_attr_u8 (&s, 0x0203, 0x21);       /* HIDCountryCode */
    sb_attr_bool(&s, 0x0204, 0);         /* HIDVirtualCable */
    sb_attr_bool(&s, 0x0205, 1);         /* HIDReconnectInitiate */
    /* 0x0206 HIDDescriptorList: DES[ DES[UINT8 0x22, TEXT report map] ] */
    {
        sb_byte(&s, 0x09); sb_byte(&s, 0x02); sb_byte(&s, 0x06);
        size_t d = sb_des_open(&s);
        size_t d1 = sb_des_open(&s);
        sb_byte(&s, 0x08); sb_byte(&s, 0x22);
        sb_byte(&s, 0x26); /* TEXT, 2-byte length */
        sb_byte(&s, (uint8_t)((ds4_gamepad_report_map_len >> 8) & 0xFF));
        sb_byte(&s, (uint8_t)(ds4_gamepad_report_map_len & 0xFF));
        sb_bytes(&s, ds4_gamepad_report_map, ds4_gamepad_report_map_len);
        sb_des_close(&s, d1);
        sb_des_close(&s, d);
    }
    /* 0x0207 HIDLANGIDBaseList */
    {
        sb_byte(&s, 0x09); sb_byte(&s, 0x02); sb_byte(&s, 0x07);
        size_t d = sb_des_open(&s);
        size_t d1 = sb_des_open(&s);
        sb_byte(&s, 0x19); sb_byte(&s, 0x04); sb_byte(&s, 0x09); /* lang EN-US */
        sb_byte(&s, 0x09); sb_byte(&s, 0x01); sb_byte(&s, 0x00); /* base 0x100 */
        sb_des_close(&s, d1);
        sb_des_close(&s, d);
    }
    sb_attr_bool(&s, 0x0208, 1);         /* HIDBatteryPower */
    sb_attr_bool(&s, 0x020A, 1);         /* HIDRemoteWake */
    sb_attr_bool(&s, 0x020B, 0);         /* HIDNormallyConnectable */
    sb_attr_bool(&s, 0x020C, 0);         /* HIDBootDevice */
    sb_attr_text(&s, 0x0100, "Wireless Controller");
    sb_attr_text(&s, 0x0101, "Wireless Controller");
    sb_attr_text(&s, 0x0102, "Sony Interactive Entertainment Inc.");

    sb_des_close(&s, root);
    return s.err ? 0 : s.len;
}

/* ---- minimal parser / validator ---- */
/* Separate DeviceID (PnP) record — VID 0x054C Sony, PID 0x09CC DS4v2, USB source */
size_t sdp_build_pnp_record(uint8_t *buf, size_t cap) {
    sb s = { buf, cap, 0, 0 };
    size_t root = sb_des_open(&s);
    /* 0x0001 ServiceClassIDList [0x1200 PnPInformation] */
    {
        sb_byte(&s, 0x09); sb_byte(&s, 0x00); sb_byte(&s, 0x01);
        size_t d = sb_des_open(&s);
        sb_byte(&s, 0x19); sb_byte(&s, 0x12); sb_byte(&s, 0x00);
        sb_des_close(&s, d);
    }
    /* 0x0004 ProtocolDescriptorList [L2CAP/SDP? PnP has none] — omit; PnP records use attrs 0x0200.. */
    sb_attr_u16(&s, 0x0200, 0x0103); /* SpecificationID */
    sb_attr_u16(&s, 0x0201, 0x054C); /* VendorID        */
    sb_attr_u16(&s, 0x0202, 0x09CC); /* ProductID       */
    sb_attr_u16(&s, 0x0203, 0x8100); /* Version         */
    sb_attr_bool(&s, 0x0204, 1);     /* PrimaryRecord   */
    sb_attr_u16(&s, 0x0205, 0x0002); /* VendorIDSource (USB) */
    sb_des_close(&s, root);
    return s.err ? 0 : s.len;
}
static const uint8_t *elem_size(const uint8_t *p, const uint8_t *end, size_t *sz) {
    if (p >= end) return NULL;
    uint8_t b = *p++;
    uint8_t t = (uint8_t)(b >> 3), i = (uint8_t)(b & 0x07);
    size_t hdr;
    switch (i) { /* SDP size index: 0=1B 1=2B 2=4B 3=8B 4=16B 5=+1Bl 6=+2Bl 7=+4Bl */
        case 0: *sz = 1; hdr = 0; break;
        case 1: *sz = 2; hdr = 0; break;
        case 2: *sz = 4; hdr = 0; break;
        case 3: *sz = 8; hdr = 0; break;
        case 4: *sz = 16; hdr = 0; break;
        case 5: if (p + 1 > end) return NULL; *sz = p[0]; hdr = 1; break;
        case 6: if (p + 2 > end) return NULL; *sz = (size_t)p[0] << 8 | p[1]; hdr = 2; break;
        case 7: if (p + 4 > end) return NULL; *sz = (size_t)p[0] << 24 | (size_t)p[1] << 16 | (size_t)p[2] << 8 | p[3]; hdr = 4; break;
        default: return NULL;
    }
    if (p + hdr + *sz > end) return NULL;
    if (t == 8) return NULL; /* URL not handled */
    return p + hdr + *sz;
}

int sdp_find_attr(const uint8_t *buf, size_t len, uint16_t attr_id,
                  const uint8_t **val, size_t *val_len) {
    if (!buf || len < 3 || buf[0] != 0x36) return -1;
    size_t payload = (size_t)buf[1] << 8 | buf[2];
    const uint8_t *p = buf + 3, *end = buf + 3 + payload;
    if (end > buf + len) return -1;
    while (p < end) {
        if (p + 3 > end) return -1;
        if (p[0] != 0x09) return -1;
        uint16_t id = (uint16_t)((p[1] << 8) | p[2]);
        p += 3;
        const uint8_t *vstart = p;
        const uint8_t *n = elem_size(p, end, val_len);
        if (!n) return -1;
        size_t total = (size_t)(n - vstart);
        if (id == attr_id) {
            if (val) *val = vstart;
            if (val_len) *val_len = total;
            return 0;
        }
        p = n;
    }
    return -1;
}

int sdp_validate_record(const uint8_t *buf, size_t len) {
    const uint8_t *v; size_t vl;
    if (sdp_find_attr(buf, len, 0x0206, &v, &vl) != 0) return -1; /* HIDDescriptorList */
    if (vl < 5) return -1;
    /* outer DES header */
    if (v[0] != 0x36) return -1;
    size_t payload = (size_t)v[1] << 8 | v[2];
    if (3 + payload != vl) return -1;
    /* find inner DES, then 0x22 type then TEXT with our map */
    const uint8_t *p = v + 3, *end = v + vl;
    if (p >= end || p[0] != 0x36) return -1;
    size_t ip = (size_t)p[1] << 8 | p[2];
    const uint8_t *q = p + 3, *qe = q + ip;
    if (qe > end) return -1;
    if (q >= qe || q[0] != 0x08 || q[1] != 0x22) return -1; /* UINT8 0x22 */
    q += 2;
    if (q >= qe || q[0] != 0x26) return -1; /* TEXT len16 */
    size_t ml = (size_t)q[1] << 8 | q[2];
    q += 3;
    if (q + ml != qe) return -1;
    if (memcmp(q, ds4_gamepad_report_map, ds4_gamepad_report_map_len) != 0) return -1;
    return 0;
}
