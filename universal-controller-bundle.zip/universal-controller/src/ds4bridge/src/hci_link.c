#include "ds4bridge/hci_link.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

/* ---- HCI + L2CAP device-role engine ---- */

#define HCI_OP_RESET            0x0C03
#define HCI_OP_READ_LOCAL_VER   0x1001
#define HCI_EVT_CMD_COMPLETE    0x0E
#define HCI_EVT_CONN_COMPLETE   0x03
#define HCI_EVT_DISCONN_COMPLETE 0x05
#define L2CAP_CID_SIGNALING     0x0001
#define L2CAP_CONN_REQ          0x02
#define L2CAP_CONN_RSP          0x03
#define L2CAP_CONF_REQ          0x04
#define L2CAP_CONF_RSP          0x05
#define L2CAP_DISC_REQ          0x06
#define L2CAP_DISC_RSP          0x07
#define MAX_CH 8

typedef struct {
    uint16_t local_cid, remote_cid;
    uint16_t psm;
    int conf_in, conf_out, up;
} ch_t;

struct hci_link {
    hci_io_t io;
    hiddev_t *hid;
    uint16_t handle;
    int handle_valid;
    ch_t ch[MAX_CH];
    uint8_t next_cid;
    uint8_t next_ident;
    char version[64];
    int version_known;
    /* hiddev transport adapter routed through us */
    hiddev_transport_t hidt;
};

hci_link_t *hci_link_new(hci_io_t *io) {
    hci_link_t *l = (hci_link_t *)calloc(1, sizeof(*l));
    l->io = *io;
    l->next_cid = 0x40;
    l->next_ident = 1;
    return l;
}
void hci_link_free(hci_link_t *l) { free(l); }
void hci_link_bind_hid(hci_link_t *l, hiddev_t *h) { l->hid = h; }

uint16_t hci_link_handle(const hci_link_t *l) { return l->handle; }
int hci_link_version_known(const hci_link_t *l) { return l->version_known; }
const char *hci_link_version_str(const hci_link_t *l) { return l->version; }

int hci_link_psm_up(const hci_link_t *l, uint16_t psm) {
    for (int i = 0; i < MAX_CH; i++)
        if (l->ch[i].psm == psm && l->ch[i].up) return 1;
    return 0;
}

static ch_t *ch_by_psm(hci_link_t *l, uint16_t psm) {
    for (int i = 0; i < MAX_CH; i++) if (l->ch[i].psm == psm) return &l->ch[i];
    return NULL;
}
static ch_t *ch_by_lcid(hci_link_t *l, uint16_t cid) {
    for (int i = 0; i < MAX_CH; i++) if (l->ch[i].local_cid == cid) return &l->ch[i];
    return NULL;
}
static ch_t *ch_alloc(hci_link_t *l, uint16_t psm) {
    for (int i = 0; i < MAX_CH; i++)
        if (!l->ch[i].psm) {
            memset(&l->ch[i], 0, sizeof(ch_t));
            l->ch[i].psm = psm;
            l->ch[i].local_cid = l->next_cid++;
            return &l->ch[i];
        }
    return NULL;
}
static void ch_try_up(hci_link_t *l, ch_t *c) {
    if (c->conf_in && c->conf_out && !c->up) {
        c->up = 1;
        if (l->hid) hiddev_on_connected(l->hid, c->psm);
    }
}

/* ---- TX helpers ---- */
static int send_raw(hci_link_t *l, const uint8_t *buf, size_t len) {
    return (int)l->io.write(l->io.ctx, buf, len);
}

int hci_link_cmd_reset(hci_link_t *l) {
    uint8_t p[8] = { 0x01, 0x03, 0x0C, 0x00 };
    return send_raw(l, p, 4);
}

int hci_link_cmd_read_local_version(hci_link_t *l) {
    uint8_t p[8] = { 0x01, 0x01, 0x10, 0x00 };
    return send_raw(l, p, 4);
}

int hci_link_acl_send(hci_link_t *l, uint16_t cid, const uint8_t *data, size_t len) {
    if (!l->handle_valid) return -1;
    uint8_t buf[600];
    if (5 + 4 + len > sizeof(buf)) return -1;
    buf[0] = 0x02;
    buf[1] = (uint8_t)(l->handle & 0xFF);
    buf[2] = (uint8_t)((l->handle >> 8) & 0x0F) | 0x20; /* PB=10 first non-flushable */
    uint16_t l2len = (uint16_t)(4 + len);
    uint16_t dlen = (uint16_t)(4 + l2len);
    buf[3] = (uint8_t)(dlen & 0xFF);
    buf[4] = (uint8_t)(dlen >> 8);
    buf[5] = (uint8_t)(l2len & 0xFF);
    buf[6] = (uint8_t)(l2len >> 8);
    buf[7] = (uint8_t)(cid & 0xFF);
    buf[8] = (uint8_t)(cid >> 8);
    memcpy(buf + 9, data, len);
    return send_raw(l, buf, 9 + len);
}

static int sig_send(hci_link_t *l, uint8_t code, uint8_t ident, const uint8_t *payload, size_t plen) {
    uint8_t buf[64];
    if (4 + plen > sizeof(buf)) return -1;
    buf[0] = code; buf[1] = ident;
    buf[2] = (uint8_t)(plen & 0xFF); buf[3] = (uint8_t)(plen >> 8);
    if (plen) memcpy(buf + 4, payload, plen);
    return hci_link_acl_send(l, L2CAP_CID_SIGNALING, buf, 4 + plen);
}

int hci_link_l2cap_connreq(hci_link_t *l, uint16_t psm) {
    ch_t *c = ch_alloc(l, psm);
    if (!c) return -1;
    uint8_t pl[4];
    pl[0] = (uint8_t)(psm & 0xFF); pl[1] = (uint8_t)(psm >> 8);
    pl[2] = (uint8_t)(c->local_cid & 0xFF); pl[3] = (uint8_t)(c->local_cid >> 8);
    return sig_send(l, L2CAP_CONN_REQ, l->next_ident++, pl, 4);
}

/* ---- RX ---- */
static void on_cmd_complete(hci_link_t *l, const uint8_t *p, size_t n) {
    /* p = Command Complete parameters: num(1) opcode(2) status(1) return-params... */
    if (n < 5) return;
    uint16_t opcode = (uint16_t)(p[1] | (p[2] << 8));
    if (opcode == HCI_OP_READ_LOCAL_VER && p[3] == 0 && n >= 12) {
        uint8_t hci_ver = p[4];
        __attribute__((unused)) uint16_t hci_rev = (uint16_t)(p[5] | (p[6] << 8));
        uint8_t lmp_ver = p[7];
        uint16_t man = (uint16_t)(p[8] | (p[9] << 8));
        uint16_t lmp_sub = (uint16_t)(p[10] | (p[11] << 8));
        const char *mfr = "unknown";
        if (man == 0x000F) mfr = "Broadcom";
        else if (man == 0x0131) mfr = "Cypress";
        else if (man == 0x000A) mfr = "CSR/Qualcomm";
        else if (man == 0x0002) mfr = "Nokia";
        snprintf(l->version, sizeof(l->version),
                 "HCI %u.%u LMP %u man=0x%04X (%s) sub=0x%04X",
                 hci_ver >> 4, hci_ver & 0xF, lmp_ver, man, mfr, lmp_sub);
        l->version_known = 1;
    }
}

static void on_signal(hci_link_t *l, const uint8_t *d, size_t n) {
    size_t off = 0;
    while (off + 4 <= n) {
        uint8_t code = d[off], ident = d[off + 1];
        uint16_t slen = (uint16_t)(d[off + 2] | (d[off + 3] << 8));
        if (off + 4 + slen > n) break;
        const uint8_t *sp = d + off + 4;

        switch (code) {
            case L2CAP_CONN_RSP: {
                if (slen < 8) break;
                uint16_t scid = (uint16_t)(sp[2] | (sp[3] << 8)); /* our local cid */
                uint16_t result = (uint16_t)(sp[6] | (sp[7] << 8));
                ch_t *c = ch_by_lcid(l, scid);
                if (c && result == 0) {
                    c->remote_cid = (uint16_t)(sp[0] | (sp[1] << 8));
                    /* send our own (empty) config request */
                    uint8_t pl[4];
                    pl[0] = (uint8_t)(c->remote_cid & 0xFF); pl[1] = (uint8_t)(c->remote_cid >> 8);
                    pl[2] = 0; pl[3] = 0; /* flags */
                    sig_send(l, L2CAP_CONF_REQ, l->next_ident++, pl, 4);
                } else if (c && result != 0) {
                    c->psm = 0; /* free slot on refusal */
                }
                break;
            }
            case L2CAP_CONF_REQ: {
                if (slen < 4) break;
                uint16_t dcid = (uint16_t)(sp[0] | (sp[1] << 8)); /* their cid to reach us = our local */
                ch_t *c = ch_by_lcid(l, dcid);
                if (c) {
                    uint8_t pl[8];
                    pl[0] = (uint8_t)(c->remote_cid & 0xFF); pl[1] = (uint8_t)(c->remote_cid >> 8);
                    pl[2] = 0; pl[3] = 0;   /* flags */
                    pl[4] = 0; pl[5] = 0;   /* result = success */
                    /* echo option bytes (usually MTU) — accepted as-is */
                    size_t opt = slen - 4 > 4 ? slen - 4 : 0;
                    if (4 + 4 + opt > sizeof(pl)) opt = 0;
                    if (opt) memcpy(pl + 6, sp + 4, opt);
                    sig_send(l, L2CAP_CONF_RSP, ident, pl, 6 + opt);
                    c->conf_in = 1;
                    ch_try_up(l, c);
                }
                break;
            }
            case L2CAP_CONF_RSP: {
                if (slen < 6) break;
                uint16_t scid = (uint16_t)(sp[0] | (sp[1] << 8));
                uint16_t result = (uint16_t)(sp[4] | (sp[5] << 8));
                ch_t *c = ch_by_lcid(l, scid);
                if (c && result == 0) { c->conf_out = 1; ch_try_up(l, c); }
                break;
            }
            case L2CAP_DISC_REQ: {
                if (slen < 4) break;
                uint8_t pl[4];
                pl[0] = sp[2]; pl[1] = sp[3]; pl[2] = sp[0]; pl[3] = sp[1];
                sig_send(l, L2CAP_DISC_RSP, ident, pl, 4);
                ch_t *c = ch_by_lcid(l, (uint16_t)(sp[0] | (sp[1] << 8)));
                if (c) {
                    uint16_t psm = c->psm;
                    memset(c, 0, sizeof(*c));
                    if (l->hid) hiddev_on_disconnected(l->hid, psm);
                }
                break;
            }
            default:
                break;
        }
        off += 4 + slen;
    }
}

void hci_link_on_frame(hci_link_t *l, const hci_frame_t *f) {
    switch (f->type) {
        case 0x04: { /* EVT — code is in f->handle (see hci_reader), payload = params */
            uint8_t code = (uint8_t)f->handle;
            const uint8_t *p = f->data;
            size_t n = f->len;
            if (code == HCI_EVT_CMD_COMPLETE) on_cmd_complete(l, p, n);
            else if (code == HCI_EVT_CONN_COMPLETE && n >= 3 && p[0] == 0)
                { l->handle = (uint16_t)(p[1] | (p[2] << 8)); l->handle_valid = 1; }
            else if (code == HCI_EVT_DISCONN_COMPLETE)
                hci_link_on_disconnected(l);
            break;
        }
        case 0x02: { /* ACL */
            if (f->len < 4) return;
            uint16_t dlen = (uint16_t)(f->data[0] | (f->data[1] << 8));
            uint16_t cid  = (uint16_t)(f->data[2] | (f->data[3] << 8));
            const uint8_t *payload = f->data + 4;
            if (4 + dlen > f->len) return;
            if (cid == L2CAP_CID_SIGNALING) on_signal(l, payload, dlen);
            else {
                ch_t *c = ch_by_lcid(l, cid);
                if (c && c->up && l->hid) hiddev_on_data(l->hid, c->psm, payload, dlen);
            }
            break;
        }
        default:
            break;
    }
}

void hci_link_on_disconnected(hci_link_t *l) {
    l->handle_valid = 0;
    memset(l->ch, 0, sizeof(l->ch));
    if (l->hid) hiddev_on_disconnected(l->hid, 0x0011);
}

/* hiddev transport adapter: route sends over ACL by PSM */
static int hl_listen(void *ctx, uint16_t psm) { (void)ctx; (void)psm; return 0; }
static int hl_send(void *ctx, uint16_t psm, const uint8_t *d, size_t len) {
    hci_link_t *l = (hci_link_t *)ctx;
    ch_t *c = ch_by_psm(l, psm);
    if (!c || !c->up) return -1;
    return hci_link_acl_send(l, c->remote_cid, d, len);
}
static void hl_state(void *ctx, int ns, int os) { (void)ctx; (void)ns; (void)os; }

hiddev_transport_t *hci_link_hid_transport(hci_link_t *l) {
    l->hidt.ctx = l;
    l->hidt.listen = hl_listen;
    l->hidt.send = hl_send;
    l->hidt.on_state = hl_state;
    return &l->hidt;
}
