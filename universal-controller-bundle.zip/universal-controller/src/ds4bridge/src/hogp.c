#include "ds4bridge/hogp.h"
#include <string.h>

/* Joy-Con-shaped placeholder gamepad map: 2 axes (X/Y left stick), hat,
   14 buttons. Byte-exact Joy-Con report map = Phase-3 capture task. */
const uint8_t hogp_joycon_report_map[] = {
    0x05, 0x01,             /* Usage Page (Generic Desktop) */
    0x09, 0x05,             /* Usage (Gamepad)              */
    0xA1, 0x01,             /* Collection (Application)     */
    0x85, 0x01,             /*   Report ID (1)              */
    0x09, 0x30, 0x09, 0x31, /*   Usage X, Y                 */
    0x15, 0x81, 0x25, 0x7F, /*   Logical -127..127          */
    0x75, 0x08, 0x95, 0x02,
    0x81, 0x02,             /*   Input (Data,Var,Abs)       */
    0x09, 0x39,             /*   Hat switch                 */
    0x15, 0x00, 0x25, 0x07,
    0x75, 0x04, 0x95, 0x01,
    0x81, 0x42,             /*   Input (Null state)         */
    0x75, 0x04, 0x95, 0x01,
    0x81, 0x01,             /*   padding                    */
    0x05, 0x09,             /*   Usage Page (Button)        */
    0x19, 0x01, 0x29, 0x0E,
    0x15, 0x00, 0x25, 0x01,
    0x75, 0x01, 0x95, 0x0E,
    0x81, 0x02,             /*   14 buttons                 */
    0x75, 0x01, 0x95, 0x02,
    0x81, 0x01,             /*   padding                    */
    0xC0,                   /* End Collection               */
};
const size_t hogp_joycon_report_map_len = sizeof(hogp_joycon_report_map);

static const uint8_t v_name[] = "Joy-Con (L)";      /* UNKNOWN-verify exact name */
static const uint8_t v_appearance[] = { 0xC4, 0x03 }; /* 0x03C4 gamepad (LE)     */
static const uint8_t v_pnp[7] = { 2, 0x7E, 0x05, 0x06, 0x20, 0x01, 0x00 };
static const uint8_t v_hidinfo[4] = { 0x01, 0x01, 0x00, 0x02 }; /* bcdHID 1.01, flags */
static const uint8_t v_protomode[1] = { 0x01 };     /* report protocol */
static const uint8_t v_battery[1] = { 0x64 };       /* 100% */
static const uint8_t v_reportref[2] = { 0x01, 0x01 }; /* Input, Report ID 1 */

static const hogp_att_t db[] = {
    /* --- GAP (0x1800) --- */
    { 0x0001, 0x2800, NULL, 0 },                    /* include (value unused in this table form) */
    { 0x0004, 0x2A00, v_name, sizeof(v_name) - 1 },
    { 0x0006, 0x2A01, v_appearance, sizeof(v_appearance) },
    /* --- Device Information (0x180A) --- */
    { 0x000A, 0x2800, NULL, 0 },
    { 0x000C, 0x2A50, v_pnp, sizeof(v_pnp) },
    /* --- Battery (0x180F) --- */
    { 0x0010, 0x2800, NULL, 0 },
    { 0x0012, 0x2A19, v_battery, sizeof(v_battery) },
    /* --- HID (0x1812) --- */
    { 0x0016, 0x2800, NULL, 0 },
    { 0x0018, 0x2A4A, v_hidinfo, sizeof(v_hidinfo) },
    { 0x001B, 0x2A4B, hogp_joycon_report_map, hogp_joycon_report_map_len },
    { 0x001E, 0x2A4C, NULL, 0 },                    /* HID Control Point (WNR) */
    { 0x0020, 0x2A4E, v_protomode, sizeof(v_protomode) },
    { 0x0022, 0x2A4D, NULL, 0 },                    /* Report (notify) */
    { 0x0024, 0x2908, v_reportref, sizeof(v_reportref) }, /* Report Reference desc */
};

const hogp_att_t *hogp_joycon_db(size_t *count) {
    if (count) *count = sizeof(db) / sizeof(db[0]);
    return db;
}

void hogp_pnp_bytes(uint8_t out[7]) {
    memcpy(out, v_pnp, 7);
}
