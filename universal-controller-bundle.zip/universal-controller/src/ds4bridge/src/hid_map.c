#include <string.h>
#include "ds4bridge/hid_map.h"

/* DS4-shaped gamepad report map:
   - axes X, Y (left stick), Z, Rz (right stick) 8-bit, center 0x80
   - hat switch with null state
   - 14 buttons
   This is a valid generic gamepad descriptor shaped like the DS4 v1 layout;
   the byte-exact DS4 clone is pending a live capture (Phase-3 task P3-2). */
const uint8_t ds4_gamepad_report_map[] = {
    0x05, 0x01,             /* Usage Page (Generic Desktop)      */
    0x09, 0x05,             /* Usage (Gamepad)                   */
    0xA1, 0x01,             /* Collection (Application)          */
    0x85, 0x11,             /*   Report ID (17 = DS4 0x11)       */
    0x09, 0x30,             /*   Usage (X)                       */
    0x09, 0x31,             /*   Usage (Y)                       */
    0x09, 0x32,             /*   Usage (Z)                       */
    0x09, 0x35,             /*   Usage (Rz)                      */
    0x15, 0x00,             /*   Logical Minimum (0)             */
    0x25, 0xFF,             /*   Logical Maximum (255)           */
    0x35, 0x00,             /*   Physical Minimum (0)            */
    0x45, 0x00,             /*   Physical Maximum (0)            */
    0x75, 0x08,             /*   Report Size (8)                 */
    0x95, 0x04,             /*   Report Count (4)                */
    0x81, 0x02,             /*   Input (Data, Var, Abs)          */
    0x09, 0x39,             /*   Usage (Hat switch)              */
    0x15, 0x00,             /*   Logical Minimum (0)             */
    0x25, 0x07,             /*   Logical Maximum (7)             */
    0x35, 0x00,             /*   Physical Minimum (0)            */
    0x46, 0x3B, 0x01,       /*   Physical Maximum (315)          */
    0x65, 0x14,             /*   Unit (Eng Rot: Degree)          */
    0x75, 0x04,             /*   Report Size (4)                 */
    0x95, 0x01,             /*   Report Count (1)                */
    0x81, 0x42,             /*   Input (Data, Var, Abs, NullState)*/
    0x65, 0x00,             /*   Unit (None)                     */
    0x75, 0x04,             /*   Report Size (4)                 */
    0x95, 0x01,             /*   Report Count (1)                */
    0x81, 0x01,             /*   Input (Const, Arr, Abs) pad     */
    0x05, 0x09,             /*   Usage Page (Button)             */
    0x19, 0x01,             /*   Usage Minimum (1)               */
    0x29, 0x0E,             /*   Usage Maximum (14)              */
    0x15, 0x00,             /*   Logical Minimum (0)             */
    0x25, 0x01,             /*   Logical Maximum (1)             */
    0x75, 0x01,             /*   Report Size (1)                 */
    0x95, 0x0E,             /*   Report Count (14)               */
    0x81, 0x02,             /*   Input (Data, Var, Abs)          */
    0x75, 0x01,             /*   Report Size (1)                 */
    0x95, 0x02,             /*   Report Count (2)                */
    0x81, 0x01,             /*   Input (Const) pad to byte       */
    0xC0,                   /* End Collection                    */
};
const size_t ds4_gamepad_report_map_len = sizeof(ds4_gamepad_report_map);

/* ---- minimal HID item-stream validator ---- */
typedef struct { int collections; int hasGamepad; int hasButtonPage; } vctx;

static const uint8_t *v_items(const uint8_t *p, const uint8_t *end, vctx *v) {
    while (p < end) {
        uint8_t b = *p++;
        uint8_t tag = (uint8_t)(b & 0xFC);
        uint8_t size = (uint8_t)(b & 0x03);
        if (size == 3) size = 4; /* long item not used; treat 3 as 4 per spec short-form n/a */
        if (p + size > end) return NULL;
        switch (tag) {
            case 0xA0: v->collections++; break;      /* Collection        */
            case 0xC0: v->collections--; break;      /* End Collection    */
            case 0x84: /* Report ID */ break;
            case 0x04: v->hasButtonPage = 1; break;  /* Usage Page 0x09: b=0x05 -> tag 0x04 */
            default: break;
        }
        /* Usage item: track Gamepad usage 0x05 on Generic Desktop page */
        if (tag == 0x08 && size == 1 && p[0] == 0x05) {
            /* usage byte equals 0x05 (Gamepad) — only meaningful on GenDesktop page */
            if (v->hasGamepad == 0) v->hasGamepad = 1;
        }
        /* simpler & robust: main-item Usage (0x08/0x18/0x28) with value 0x05 */
        if ((tag == 0x08) && size == 1 && p[0] == 0x05) { /* handled above */ }
        p += size;
        if (v->collections < 0) return NULL;
    }
    return p;
}

int hid_validate_report_map(const uint8_t *map, size_t len) {
    if (!map || len == 0 || len > 4096) return -1;
    vctx v; memset(&v, 0, sizeof(v));
    if (!v_items(map, map + len, &v)) return -1;
    if (v.collections != 0) return -1;
    /* Gamepad usage detection: search for the two-byte Usage (0x09,0x05) */
    int has_pad = 0, has_btn_page = 0;
    for (size_t i = 0; i + 1 < len; i++) {
        if (map[i] == 0x09 && map[i + 1] == 0x05) has_pad = 1;   /* Usage (Gamepad) */
        if (map[i] == 0x05 && map[i + 1] == 0x09) has_btn_page = 1; /* Usage Page (Button) */
    }
    if (!has_pad || !has_btn_page) return -1;
    (void)v.hasGamepad; (void)v.hasButtonPage;
    return 0;
}
