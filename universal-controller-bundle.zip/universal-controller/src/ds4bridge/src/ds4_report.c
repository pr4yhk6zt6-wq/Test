#include "ds4bridge/ds4_report.h"
#include "ds4bridge/ic_packet.h"

/* DS4 v1 Bluetooth input report 0x11 (49-byte, CRC-disabled form).
   Layout per public reverse-engineering documentation (GIMX wiki +
   dsremap docs + controllers.fandom — see docs/11-evidence-register.md
   E9/E10/E11): over BT the report is
     [0]  report ID 0x11
     [1]  flags (bit7 EnableHID, bit6 EnableCRC) — 0xC0/0xC4 seen live;
          we send 0x80 (HID enabled, CRC disabled) — UNVERIFIED detail
     [2]  unknown / 0x00
     [3]  report counter
     [4]  LX [5] LY [6] RX [7] RY     (0..255, 0x80 center)
     [8]  hat<<4 | bit0 SQUARE bit1 CROSS bit2 CIRCLE bit3 TRIANGLE
     [9]  bit0 L1 bit1 R1 bit2 L2btn bit3 R2btn bit4 SHARE bit5 OPTIONS bit6 L3 bit7 R3
     [10] bit0 PS bit1 TPAD
     [11] L2 analog [12] R2 analog
     [13..14] timestamp (LE)
     [15] battery
     [16..48] motion/touchpad — zero-filled (a real DS4 sends IMU/touch data)
   NOTE: whether iPhone B's DS4 driver accepts the 49-byte CRC-disabled form
   (vs the 78-byte CRC-enabled form) is UNVERIFIED — Phase-3 must test both. */
void ds4_build_input_report_0x11(const ICInputPacket *in, uint8_t out[DS4_BT_REPORT_LEN]) {
    static uint8_t counter;
    memset(out, 0, DS4_BT_REPORT_LEN);
    out[0] = 0x11;
    out[1] = 0x80; /* EnableHID, no CRC — UNVERIFIED against live capture */
    out[2] = 0x00;
    out[3] = counter++;

    int8_t lx = in ? in->lx : 0, ly = in ? in->ly : 0;
    int8_t rx = in ? in->rx : 0, ry = in ? in->ry : 0;
    out[4] = (uint8_t)(128 + lx);
    out[5] = (uint8_t)(128 + ly);
    out[6] = (uint8_t)(128 + rx);
    out[7] = (uint8_t)(128 + ry);

    uint8_t bA = in ? in->buttonsA : 0, bB = in ? in->buttonsB : 0;
    uint8_t b8 = 0, b9 = 0;
    if (bA & IC_BTN_X) b8 |= 0x01;              /* SQUARE   */
    if (bA & IC_BTN_A) b8 |= 0x02;              /* CROSS    */
    if (bA & IC_BTN_B) b8 |= 0x04;              /* CIRCLE   */
    if (bA & IC_BTN_Y) b8 |= 0x08;              /* TRIANGLE */
    uint8_t hat = in ? in->hat : IC_HAT_NEUTRAL;
    if (hat > 7) hat = 8;
    b8 |= (uint8_t)(hat << 4);

    if (bA & IC_BTN_L1)  b9 |= 0x01;
    if (bA & IC_BTN_R1)  b9 |= 0x02;
    if (in && in->l2 > 127) b9 |= 0x04;
    if (in && in->r2 > 127) b9 |= 0x08;
    if (bA & IC_BTN_VIEW) b9 |= 0x10;           /* SHARE    */
    if (bA & IC_BTN_MENU) b9 |= 0x20;           /* OPTIONS  */
    if (bB & IC_BTN_LS)  b9 |= 0x40;
    if (bB & IC_BTN_RS)  b9 |= 0x80;

    out[8] = b8;
    out[9] = b9;
    out[10] = 0x00; /* PS/TPad off */
    out[11] = in ? in->l2 : 0;
    out[12] = in ? in->r2 : 0;
    uint16_t ts = in ? (uint16_t)(in->t_ms & 0xFFFF) : 0;
    out[13] = (uint8_t)(ts & 0xFF);
    out[14] = (uint8_t)(ts >> 8);
    out[15] = 0x05; /* battery: charged-ish */
}

void ds4_build_neutral_report(uint8_t out[DS4_BT_REPORT_LEN]) {
    ICInputPacket p;
    memset(&p, 0, sizeof(p));
    p.hat = IC_HAT_NEUTRAL;
    ds4_build_input_report_0x11(&p, out);
}
