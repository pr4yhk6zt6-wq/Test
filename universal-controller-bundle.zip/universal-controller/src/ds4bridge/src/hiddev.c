#include "ds4bridge/hiddev.h"
#include "ds4bridge/ds4_report.h"
#include <stdlib.h>

struct hiddev {
    hiddev_transport_t t;
    int state;
    int controlUp, interruptUp;
    uint32_t lastReportMs, lastInputMs;
    uint32_t reportIntervalMs;
    uint32_t reportsSent, bytesSent;
    ICInputPacket input;
    int haveInput;
    uint8_t protocolMode; /* 0 = boot, 1 = report */
};

hiddev_t *hiddev_new(const hiddev_transport_t *t) {
    hiddev_t *h = (hiddev_t *)calloc(1, sizeof(*h));
    if (!h) return NULL;
    h->t = *t;
    h->state = HIDDEV_IDLE;
    h->reportIntervalMs = 8; /* ~120 Hz */
    h->protocolMode = 1;
    if (h->t.listen) {
        h->t.listen(h->t.ctx, HID_PSM_CONTROL);
        h->t.listen(h->t.ctx, HID_PSM_INTERRUPT);
    }
    return h;
}

void hiddev_free(hiddev_t *h) { free(h); }

static void set_state(hiddev_t *h, int s) {
    if (h->state == s) return;
    int old = h->state;
    h->state = s;
    if (h->t.on_state) h->t.on_state(h->t.ctx, s, old);
}

void hiddev_on_connected(hiddev_t *h, uint16_t psm) {
    if (psm == HID_PSM_CONTROL) h->controlUp = 1;
    if (psm == HID_PSM_INTERRUPT) h->interruptUp = 1;
    if (h->controlUp && !h->interruptUp) set_state(h, HIDDEV_CONTROL_UP);
    if (h->controlUp && h->interruptUp) set_state(h, HIDDEV_CONNECTED);
}

void hiddev_on_disconnected(hiddev_t *h, uint16_t psm) {
    if (psm == HID_PSM_CONTROL) { h->controlUp = 0; h->interruptUp = 0; }
    if (psm == HID_PSM_INTERRUPT) h->interruptUp = 0;
    if (!h->controlUp) set_state(h, HIDDEV_IDLE);
    else set_state(h, HIDDEV_CONTROL_UP);
}

void hiddev_on_data(hiddev_t *h, uint16_t psm, const uint8_t *data, size_t len) {
    if (psm != HID_PSM_CONTROL || len == 0) {
        /* inbound interrupt-channel data (e.g. host output/rumble report): accepted, ignored */
        return;
    }
    uint8_t trans = (uint8_t)(data[0] >> 4);
    uint8_t param = (uint8_t)(data[0] & 0x0F);
    uint8_t hs[1];
    switch (trans) {
        case HID_TRANS_GET_REPORT:
            if (param == HID_PARAM_INPUT && len >= 1) {
                uint8_t rep[DS4_BT_REPORT_LEN + 1];
                rep[0] = (uint8_t)((HID_TRANS_DATA << 4) | HID_PARAM_INPUT); /* 0xA1 */
                ds4_build_input_report_0x11(h->haveInput ? &h->input : NULL, rep + 1);
                h->bytesSent += (uint32_t)h->t.send(h->t.ctx, HID_PSM_CONTROL, rep, sizeof(rep));
            } else {
                hs[0] = (uint8_t)((HID_TRANS_HANDSHAKE << 4) | 0x3); /* unsupported */
                h->t.send(h->t.ctx, HID_PSM_CONTROL, hs, 1);
            }
            break;
        case HID_TRANS_SET_REPORT:
            hs[0] = (uint8_t)((HID_TRANS_HANDSHAKE << 4) | 0x0); /* successful */
            h->t.send(h->t.ctx, HID_PSM_CONTROL, hs, 1);
            break;
        case HID_TRANS_GET_PROTOCOL:
            hs[0] = (uint8_t)((HID_TRANS_CONTROL << 4) | (h->protocolMode & 1));
            h->t.send(h->t.ctx, HID_PSM_CONTROL, hs, 1);
            break;
        case HID_TRANS_SET_PROTOCOL:
            h->protocolMode = param & 1;
            hs[0] = (uint8_t)((HID_TRANS_HANDSHAKE << 4) | 0x0);
            h->t.send(h->t.ctx, HID_PSM_CONTROL, hs, 1);
            break;
        case HID_TRANS_CONTROL:
            /* param 0 = HOLD, others (RESET etc.) — handshake successful */
            hs[0] = (uint8_t)((HID_TRANS_HANDSHAKE << 4) | 0x0);
            h->t.send(h->t.ctx, HID_PSM_CONTROL, hs, 1);
            break;
        default:
            hs[0] = (uint8_t)((HID_TRANS_HANDSHAKE << 4) | 0x3);
            h->t.send(h->t.ctx, HID_PSM_CONTROL, hs, 1);
            break;
    }
}

void hiddev_set_input(hiddev_t *h, const ICInputPacket *p) {
    if (!p || ic_packet_validate(p) != 0) return;
    h->input = *p;
    h->haveInput = 1;
    h->lastInputMs = p->t_ms;
}

void hiddev_set_report_interval(hiddev_t *h, uint32_t ms) {
    if (ms >= 1 && ms <= 100) h->reportIntervalMs = ms;
}

void hiddev_tick(hiddev_t *h, uint32_t now_ms) {
    if (h->state != HIDDEV_CONNECTED && h->state != HIDDEV_REPORTING && h->state != HIDDEV_STALE) return;
    if ((uint32_t)(now_ms - h->lastReportMs) < h->reportIntervalMs) return;

    int stale = h->haveInput && ((uint32_t)(now_ms - h->lastInputMs) > IC_STALE_MS);
    set_state(h, stale ? HIDDEV_STALE : HIDDEV_REPORTING);

    uint8_t frame[DS4_BT_REPORT_LEN + 1];
    frame[0] = (uint8_t)((HID_TRANS_DATA << 4) | HID_PARAM_INPUT); /* 0xA1 */
    ds4_build_input_report_0x11(stale ? NULL : &h->input, frame + 1);
    int n = h->t.send(h->t.ctx, HID_PSM_INTERRUPT, frame, sizeof(frame));
    if (n > 0) { h->reportsSent++; h->bytesSent += (uint32_t)n; }
    h->lastReportMs = now_ms;
}

int hiddev_state(hiddev_t *h) { return h->state; }
uint32_t hiddev_reports_sent(hiddev_t *h) { return h->reportsSent; }
uint32_t hiddev_bytes_sent(hiddev_t *h) { return h->bytesSent; }
