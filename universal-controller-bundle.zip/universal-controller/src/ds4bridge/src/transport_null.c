/* transport_null.c — in-memory transport for unit tests. VERIFIED (host tests).
   Records everything hiddev sends so tests can assert on frames. */
#include "ds4bridge/hiddev.h"
#include <string.h>
#include <stdio.h>
#include "ds4bridge/transport_null.h"


static int nl_listen(void *c, uint16_t psm) {
    null_ctx *n = (null_ctx *)c;
    if (n->nlisten < 8) n->psms[n->nlisten++] = psm;
    return 0;
}
static int nl_send(void *c, uint16_t psm, const uint8_t *d, size_t len) {
    null_ctx *n = (null_ctx *)c;
    if (n->len + 2 + len > sizeof(n->buf)) return -1;
    n->buf[n->len++] = (uint8_t)(psm >> 8);
    n->buf[n->len++] = (uint8_t)(psm & 0xFF);
    memcpy(n->buf + n->len, d, len);
    n->len += len;
    return (int)len;
}
static void nl_state(void *c, int ns, int os) {
    null_ctx *n = (null_ctx *)c;
    n->stateCalls++; n->lastState = ns; n->prevState = os;
}

const hiddev_transport_t *hiddev_transport_null(null_ctx *ctx) {
    static hiddev_transport_t t;
    memset(ctx, 0, sizeof(*ctx));
    t.ctx = ctx; t.listen = nl_listen; t.send = nl_send; t.on_state = nl_state;
    return &t;
}


/* helpers for tests */
size_t null_len(null_ctx *n) { return n->len; }
void null_reset(null_ctx *n) { n->len = 0; }
int null_find_frame(null_ctx *n, uint16_t psm, const uint8_t **frame, size_t flen) {
    size_t i = 0;
    while (i + 2 <= n->len) {
        uint16_t fp = (uint16_t)((n->buf[i] << 8) | n->buf[i + 1]);
        if (fp == psm) {
            *frame = n->buf + i + 2;
            (void)flen;
            return 1;
        }
        i += 2; /* trivial scan; tests null_reset between phases */
    }
    return 0;
}
int null_listened(null_ctx *n, uint16_t psm) {
    for (int i = 0; i < n->nlisten; i++) if (n->psms[i] == psm) return 1;
    return 0;
}
void null_host_connect(hiddev_t *h, uint16_t psm) { hiddev_on_connected(h, psm); }
