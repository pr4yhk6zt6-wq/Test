#include "ds4bridge/hci_transport.h"
#include <stdlib.h>
#include <string.h>

/* ---- incremental stream framer ---- */
struct hci_reader {
    uint8_t buf[1024];
    size_t  len;
    int     err;
};

hci_reader_t *hci_reader_new(void) {
    return (hci_reader_t *)calloc(1, sizeof(hci_reader_t));
}
void hci_reader_free(hci_reader_t *r) { free(r); }

static size_t hdr_len_for(uint8_t type) {
    switch (type) {
        case 0x01: return 4;  /* type + opcode2 + plen1  (hdr incl. type) */
        case 0x02: return 5;  /* type + handle2 + dlen2          */
        case 0x04: return 3;  /* type + code1 + plen1            */
        default:   return 0;
    }
}

int hci_reader_feed(hci_reader_t *r, const uint8_t *buf, size_t len, hci_frame_t *f) {
    if (!r || r->err) return -1;
    while (len--) {
        if (r->len >= sizeof(r->buf)) { r->err = 1; return -1; }
        r->buf[r->len++] = *buf++;

        if (r->len == 1 && hdr_len_for(r->buf[0]) == 0) {
            r->err = 1; /* bad packet type */
            return -1;
        }
        size_t need = hdr_len_for(r->buf[0]);
        if (r->len < need) continue;

        size_t plen = 0;
        switch (r->buf[0]) {
            case 0x01: plen = r->buf[3]; break;
            case 0x02: plen = (size_t)r->buf[3] | ((size_t)r->buf[4] << 8); break;
            case 0x04: plen = r->buf[2]; break;
        }
        if (need + plen > sizeof(r->buf)) { r->err = 1; return -1; }
        if (r->len < need + plen) continue;

        f->type   = r->buf[0];
        if (r->buf[0] == 0x04)      f->handle = r->buf[1];                    /* EVT: event code */
        else if (r->buf[0] == 0x01) f->handle = (uint16_t)(r->buf[1] | (r->buf[2] << 8)); /* CMD: opcode */
        else                        f->handle = (uint16_t)(r->buf[1] | (r->buf[2] << 8)); /* ACL: handle|flags */
        f->len    = (uint16_t)plen;
        f->data   = r->buf + need;

        size_t total = need + plen;
        memmove(r->buf, r->buf + total, r->len - total);
        r->len -= total;
        return 1;
    }
    return 0;
}

/* ---- TCP backend ---- */
typedef struct {
    int fd;
    const char *host;
    uint16_t port;
} tcp_ctx;

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <errno.h>

static int tcp_open(void *c) {
    tcp_ctx *t = (tcp_ctx *)c;
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return -1;
    struct sockaddr_in a;
    memset(&a, 0, sizeof(a));
    a.sin_family = AF_INET;
    a.sin_port = htons(t->port);
    if (inet_pton(AF_INET, t->host, &a.sin_addr) != 1 ||
        connect(fd, (struct sockaddr *)&a, sizeof(a)) != 0) {
        close(fd);
        return -1;
    }
    t->fd = fd;
    return 0;
}
static void tcp_close(void *c) {
    tcp_ctx *t = (tcp_ctx *)c;
    if (t->fd >= 0) close(t->fd);
    t->fd = -1;
}
static ssize_t tcp_write(void *c, const uint8_t *buf, size_t len) {
    tcp_ctx *t = (tcp_ctx *)c;
    return send(t->fd, buf, len, 0);
}
static ssize_t tcp_read(void *c, uint8_t *buf, size_t cap) {
    tcp_ctx *t = (tcp_ctx *)c;
    return recv(t->fd, buf, cap, 0);
}

hci_io_t *hci_io_tcp(const char *host, uint16_t port) {
    tcp_ctx *t = (tcp_ctx *)calloc(1, sizeof(*t));
    t->fd = -1;
    t->host = host;
    t->port = port;
    hci_io_t *io = (hci_io_t *)calloc(1, sizeof(*io));
    io->ctx = t;
    io->open = tcp_open;
    io->close = tcp_close;
    io->write = tcp_write;
    io->read = tcp_read;
    return io;
}
