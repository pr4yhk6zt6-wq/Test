#include "ds4bridge/ic_packet.h"

uint16_t ic_crc16(const uint8_t *data, size_t len) {
    uint16_t crc = 0xFFFF;
    for (size_t i = 0; i < len; i++) {
        crc ^= (uint16_t)((uint16_t)data[i] << 8);
        for (int b = 0; b < 8; b++)
            crc = (crc & 0x8000) ? (uint16_t)((crc << 1) ^ 0x1021) : (uint16_t)(crc << 1);
    }
    return crc;
}

int ic_packet_validate(const ICInputPacket *p) {
    if (!p) return -1;
    if (p->magic != IC_MAGIC) return -1;
    if (p->version != IC_VERSION) return -1;
    uint16_t crc = ic_crc16((const uint8_t *)p, offsetof(ICInputPacket, crc));
    if (crc != p->crc) return -1;
    if (p->hat > 8) return -1;
    return 0;
}
