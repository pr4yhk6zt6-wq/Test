/* hci_io_uart.c — direct-serial HCI transport (the G3 device-side io).
   Opens a tty (on iPhone A: /dev/uart.bluetooth), configures raw termios,
   exposes hci_io_t read/write for hci_reader/hci_link.

   EVIDENCE CONTEXT (G1, 2026-09-27): node exists on iPhone A with mode 666;
   open() from a TS app returned EBUSY (bluetoothd holds it). With the
   jailbreak's root, stopping bluetoothd should release it — this transport
   is what runs afterwards.

   Also exported: hci_io_uart_fd(fd) — adopt an ALREADY-OPEN fd (tests use a
   socketpair; future embedding can pass a BlueTool-proxied fd). If the fd is
   not a tty (ENOTTY) termios setup is skipped, which keeps tests + exotic
   backends working. */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <ds4bridge/hci_transport.h>

typedef struct {
    int fd;
    int open_err;   /* 0 = fine, else errno from factory open */
    char path[128];
} uart_ctx;

static int uart_open(void *c) {
    uart_ctx *u = (uart_ctx *)c;
    if (u->fd >= 0) return 0;
    errno = u->open_err;
    return -1;
}

static void uart_close(void *c) {
    uart_ctx *u = (uart_ctx *)c;
    if (u->fd >= 0) { close(u->fd); u->fd = -1; }
}

static ssize_t uart_write(void *c, const uint8_t *buf, size_t len) {
    uart_ctx *u = (uart_ctx *)c;
    size_t off = 0;
    while (off < len) {
        ssize_t n = write(u->fd, buf + off, len - off);
        if (n < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        off += (size_t)n;
    }
    return (ssize_t)len;
}

static ssize_t uart_read(void *c, uint8_t *buf, size_t cap) {
    uart_ctx *u = (uart_ctx *)c;
    for (;;) {
        ssize_t n = read(u->fd, buf, cap);
        if (n < 0 && errno == EINTR) continue;
        return n;
    }
}

static int configure_raw(int fd, int baud) {
    struct termios t;
    if (tcgetattr(fd, &t) != 0) {
        if (errno == ENOTTY) return 0;  /* non-tty (tests/embedded) — skip */
        return -1;
    }
    cfmakeraw(&t);
    t.c_cflag |= CLOCAL | CREAD;
#ifdef CCTS_OFLOW
    t.c_cflag &= ~CCTS_OFLOW;   /* BSD/iOS: no HW flow control */
#endif
    t.c_cc[VMIN] = 1;
    t.c_cc[VTIME] = 0;
    speed_t s = B115200;
    if (baud == 9600) s = B9600;
    else if (baud == 57600) s = B57600;
    else if (baud == 115200) s = B115200;
    else if (baud == 230400) s = B230400;
    else if (baud == 460800) s = B460800;
    else if (baud == 921600) s = B921600;
    else if (baud == 1000000) s = B1000000;
    else if (baud == 2000000) s = B2000000;
    else if (baud == 3000000) s = B3000000;
    cfsetispeed(&t, s);
    cfsetospeed(&t, s);
    if (tcsetattr(fd, TCSANOW, &t) != 0) return -1;
    tcflush(fd, TCIOFLUSH);
    return 0;
}

hci_io_t *hci_io_uart_fd(int fd, const char *label) {
    uart_ctx *u = (uart_ctx *)calloc(1, sizeof(*u));
    if (!u) return NULL;
    u->fd = fd;
    u->open_err = 0;
    snprintf(u->path, sizeof(u->path), "%s", label ? label : "fd");
    hci_io_t *io = (hci_io_t *)calloc(1, sizeof(*io));
    if (!io) { free(u); return NULL; }
    io->ctx   = u;
    io->open  = uart_open;
    io->close = uart_close;
    io->write = uart_write;
    io->read  = uart_read;
    return io;
}

hci_io_t *hci_io_uart(const char *path, int baud) {
    int fd = open(path, O_RDWR | O_NOCTTY);
    if (fd < 0) {
        int e = errno;
        uart_ctx *u = (uart_ctx *)calloc(1, sizeof(*u));
        if (!u) return NULL;
        u->fd = -1;
        u->open_err = e;
        snprintf(u->path, sizeof(u->path), "%s", path);
        hci_io_t *io = (hci_io_t *)calloc(1, sizeof(*io));
        if (!io) { free(u); return NULL; }
        io->ctx = u;
        io->open = uart_open;
        io->close = uart_close;
        io->write = uart_write;
        io->read = uart_read;
        return io;
    }
    if (configure_raw(fd, baud) != 0) {
        int e = errno;
        close(fd);
        errno = e;
        return NULL;
    }
    return hci_io_uart_fd(fd, path);
}
