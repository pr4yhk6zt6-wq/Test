/* ds4bridge unit tests — run on host (Linux x86_64) as BUILD/LOGIC verification.
   Environment label: EXTERNAL (host), not on-device. */
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "ds4bridge/ic_packet.h"
#include "ds4bridge/hid_map.h"
#include "ds4bridge/ds4_report.h"
#include "ds4bridge/sdp.h"
#include "ds4bridge/sdp_server.h"
#include "ds4bridge/hogp.h"
#include "ds4bridge/hiddev.h"

#include "ds4bridge/transport_null.h"

static int fails;
#define CHECK(cond, name) do { \
    if (cond) printf("  PASS %s\n", name); \
    else { printf("  FAIL %s\n", name); fails++; } } while (0)

static ICInputPacket mkpkt(int8_t lx, int8_t ly, uint8_t btn, uint32_t t) {
    ICInputPacket p; memset(&p, 0, sizeof(p));
    p.magic = IC_MAGIC; p.version = IC_VERSION;
    p.lx = lx; p.ly = ly; p.rx = 0; p.ry = 0;
    p.buttonsA = btn; p.hat = IC_HAT_NEUTRAL;
    p.seq16 = 42; p.t_ms = t;
    p.crc = ic_crc16((const uint8_t *)&p, offsetof(ICInputPacket, crc));
    return p;
}

int main(void) {
    printf("ds4bridge unit tests (host x86_64, external environment)\n");

    /* 1. CRC-16/CCITT-FALSE known vector "123456789" -> 0x29B1 */
    CHECK(ic_crc16((const uint8_t *)"123456789", 9) == 0x29B1, "crc16 known vector");

    /* 2. packet validate */
    ICInputPacket p = mkpkt(10, -20, IC_BTN_A | IC_BTN_MENU, 1000);
    CHECK(ic_packet_validate(&p) == 0, "packet validate ok");
    ICInputPacket bad = p; bad.crc ^= 1;
    CHECK(ic_packet_validate(&bad) == -1, "packet validate rejects bad crc");
    ICInputPacket bad2 = p; bad2.magic = 0x1234;
    CHECK(ic_packet_validate(&bad2) == -1, "packet validate rejects bad magic");

    /* 3. struct size stable across builds */
    CHECK(sizeof(ICInputPacket) == 25, "wire struct is 25 bytes");
    CHECK(sizeof(ICAckPacket) == 10, "ack struct is 10 bytes");

    /* 4. report map validation */
    CHECK(hid_validate_report_map(ds4_gamepad_report_map, ds4_gamepad_report_map_len) == 0,
          "ds4-shaped report map validates");
    uint8_t broken[] = {0xA1, 0x01, 0xC0}; /* unbalanced */
    CHECK(hid_validate_report_map(broken, sizeof(broken)) == -1,
          "unbalanced map rejected");

    /* 5. DS4 report packing */
    uint8_t rep[DS4_BT_REPORT_LEN];
    ICInputPacket act = mkpkt(0, 0, 0, 0);
    ds4_build_input_report_0x11(&act, rep);
    CHECK(rep[0] == 0x11 && DS4_BT_REPORT_LEN == 49, "report id + length");
    CHECK(rep[1] == 0x80, "EnableHID flag (CRC disabled form)");
    CHECK(rep[4] == 0x80 && rep[5] == 0x80 && rep[6] == 0x80 && rep[7] == 0x80,
          "centered sticks -> 0x80 at [4..7] (GIMX/dsremap layout)");
    CHECK((rep[8] >> 4) == 8, "neutral hat -> 8");
    ICInputPacket left = mkpkt(-127, 127, IC_BTN_A, 0); /* stick left, up */
    ds4_build_input_report_0x11(&left, rep);
    CHECK(rep[4] == 0x01, "stick left -> LX=1 at [4]");
    CHECK(rep[5] == 0xFF, "stick up -> LY=255 at [5]");
    CHECK((rep[8] & 0x02) != 0, "button A -> CROSS bit");
    ICInputPacket trig = mkpkt(0, 0, 0, 0); trig.l2 = 255; trig.r2 = 128;
    ds4_build_input_report_0x11(&trig, rep);
    CHECK(rep[11] == 255 && rep[12] == 128, "analog L2/R2 bytes at [11]/[12]");
    CHECK((rep[9] & 0x0C) == 0x0C, "deep L2/R2 -> trigger buttons at [9]");
    uint8_t neut[DS4_BT_REPORT_LEN];
    ds4_build_neutral_report(neut);
    CHECK(neut[4] == 0x80 && neut[8] == 0x80 && neut[9] == 0, "neutral report");

    /* 6. SDP record */
    uint8_t sdp[2048];
    size_t slen = sdp_build_hid_gamepad_record(sdp, sizeof(sdp));
    CHECK(slen > 100, "sdp record builds");
    CHECK(sdp_validate_record(sdp, slen) == 0, "sdp record validates + carries map");
    const uint8_t *v; size_t vl;
    CHECK(sdp_find_attr(sdp, slen, 0x0004, &v, &vl) == 0, "ProtocolDescriptorList present");
    /* PSM 17 (0x0011) inside proto list, PSM 19 (0x0013) in additional list */
    int psm17 = 0, psm19 = 0;
    for (size_t i = 0; i + 1 < slen; i++) {
        if (sdp[i] == 0x00 && sdp[i + 1] == 0x11) psm17 = 1;
        if (sdp[i] == 0x00 && sdp[i + 1] == 0x13) psm19 = 1;
    }
    CHECK(psm17 && psm19, "control/interrupt PSMs present");
    uint8_t pnp[256];
    size_t plen = sdp_build_pnp_record(pnp, sizeof(pnp));
    CHECK(plen > 20, "pnp record builds");
    CHECK(sdp_find_attr(pnp, plen, 0x0201, &v, &vl) == 0 && vl == 3 && v[0] == 0x09 && v[1] == 0x05 && v[2] == 0x4C,
          "PnP VendorID 0x054C");
    CHECK(sdp_find_attr(sdp, slen, 0x9999, &v, &vl) != 0, "absent attr not found");

    /* 7. HID device state machine */
    null_ctx n;
    hiddev_t *h = hiddev_new(hiddev_transport_null(&n));
    CHECK(null_listened(&n, 0x0011) && null_listened(&n, 0x0013),
          "listens on control+interrupt PSMs");
    CHECK(hiddev_state(h) == HIDDEV_IDLE, "starts IDLE");
    null_host_connect(h, 0x0011);
    CHECK(hiddev_state(h) == HIDDEV_CONTROL_UP, "control up");
    null_host_connect(h, 0x0013);
    CHECK(hiddev_state(h) == HIDDEV_CONNECTED, "interrupt up -> CONNECTED");

    ICInputPacket in = mkpkt(50, 0, IC_BTN_R1, 5000);
    hiddev_set_input(h, &in);
    null_reset(&n);
    hiddev_tick(h, 5008);
    const uint8_t *f = NULL;
    CHECK(null_find_frame(&n, 0x0013, &f, 0) == 1, "report sent on interrupt psm");
    if (f) {
        CHECK(f[0] == 0xA1 && f[1] == 0x11, "DATA|INPUT frame, report 0x11");
        CHECK(f[5] == (uint8_t)(0x80 + 50) && f[6] == 0x80, "stick bytes in frame ([4..7] layout)");
    }
    CHECK(hiddev_state(h) == HIDDEV_REPORTING, "state REPORTING");

    /* stale input -> neutralized reports */
    uint32_t t = 5008;
    for (int i = 0; i < 40; i++) { t += 8; hiddev_tick(h, t); }
    CHECK(hiddev_state(h) == HIDDEV_STALE, "stale after 250ms without input");
    null_reset(&n);
    hiddev_tick(h, t + 8);
    f = NULL;
    CHECK(null_find_frame(&n, 0x0013, &f, 0) == 1, "stale still emits keepalive report");
    if (f) CHECK(f[5] == 0x80 && (f[9] >> 4) == 8, "stale report is neutral");

    /* GET_REPORT answered on control */
    null_reset(&n);
    uint8_t gr[1] = { (uint8_t)((0x4 << 4) | 0x1) };
    hiddev_on_data(h, 0x0011, gr, 1);
    f = NULL;
    CHECK(null_find_frame(&n, 0x0011, &f, 0) == 1, "GET_REPORT answered on control psm");
    if (f) CHECK(f[0] == 0xA1 && f[1] == 0x11, "answer is DATA|INPUT 0x11");

    /* SET_PROTOCOL handshake */
    null_reset(&n);
    uint8_t sp[1] = { (uint8_t)((0x7 << 4) | 0x1) };
    hiddev_on_data(h, 0x0011, sp, 1);
    f = NULL;
    CHECK(null_find_frame(&n, 0x0011, &f, 0) == 1 && f && f[0] == 0x00,
          "SET_PROTOCOL -> handshake successful (0x00)");

    /* disconnect handling */
    hiddev_on_disconnected(h, 0x0011);
    CHECK(hiddev_state(h) == HIDDEV_IDLE, "control drop -> IDLE");

    /* invalid packets rejected: bad-crc must NOT overwrite the last good input */
    ICInputPacket good = mkpkt(20, 0, 0, t + 400); /* fresh timestamp */
    ICInputPacket badp = good; badp.crc ^= 0x5A;
    hiddev_set_input(h, &good);
    hiddev_set_input(h, &badp);
    null_reset(&n);
    hiddev_tick(h, t + 408);
    f = NULL;
    if (null_find_frame(&n, 0x0013, &f, 0) == 1 && f)
        CHECK(f[5] == (uint8_t)(0x80 + 20), "bad-crc packet ignored, good input kept");

    hiddev_free(h);

    /* 8. SDP responder (ServiceSearchAttribute with continuation) */
    {
        uint8_t sdp[2048];
        size_t slen = sdp_build_hid_gamepad_record(sdp, sizeof(sdp));
        sdp_server_t *sv = sdp_server_new();
        sdp_server_set_record(sv, sdp, slen);

        /* request: pattern UUID16 0x1124, max 0xFFFF, range 0x0000-0xFFFF */
        uint8_t req[64], rsp[1024];
        size_t rl = 0;
        req[rl++] = 0x06; req[rl++] = 0x00; req[rl++] = 0x01; /* tid 1 */
        /* pattern: DES(3){ UUID16 0x1124 } */
        uint8_t body[32]; size_t bl = 0;
        body[bl++] = 0x35; body[bl++] = 0x03; body[bl++] = 0x19; body[bl++] = 0x11; body[bl++] = 0x24;
        body[bl++] = 0xFF; body[bl++] = 0xFF;                      /* max */
        body[bl++] = 0x35; body[bl++] = 0x06;                      /* DES(6) */
        body[bl++] = 0x09; body[bl++] = 0x00; body[bl++] = 0x00;   /* min 0x0000 */
        body[bl++] = 0x09; body[bl++] = 0xFF; body[bl++] = 0xFF;   /* max 0xFFFF */
        body[bl++] = 0x00;                                          /* cont len 0 */
        req[rl++] = (uint8_t)(bl >> 8); req[rl++] = (uint8_t)(bl & 0xFF);
        memcpy(req + rl, body, bl); rl += bl;

        size_t n = sdp_server_handle(sv, req, rl, rsp, sizeof(rsp));
        CHECK(n > 10 && rsp[0] == 0x07, "SSA response PDU 0x07");
        size_t total = sdp_server_results_len(sv);
        uint8_t *acc = (uint8_t *)malloc(total + 2048);
        size_t acc_n = 0;
        memcpy(acc, rsp + 7, ((size_t)rsp[5] << 8) | rsp[6]);
        acc_n = ((size_t)rsp[5] << 8) | rsp[6];
        CHECK(rsp[n - 1] == 0x00, "no continuation when max=0xFFFF");
        /* verify record attrs present in one-shot result */
        int has_map_attr = 0;
        for (size_t i = 0; i + 3 < acc_n; i++)
            if (acc[i] == 0x09 && acc[i+1] == 0x02 && acc[i+2] == 0x06) has_map_attr = 1;
        CHECK(has_map_attr, "result contains attr 0x0206");

        /* continuation: max = 40 bytes per response (rebuild request each round) */
        {
            uint8_t base[32]; size_t bb = 0;
            base[bb++] = 0x35; base[bb++] = 0x03; base[bb++] = 0x19; base[bb++] = 0x11; base[bb++] = 0x24;
            base[bb++] = 0x00; base[bb++] = 0x28; /* max 40 */
            base[bb++] = 0x35; base[bb++] = 0x06;
            base[bb++] = 0x09; base[bb++] = 0x00; base[bb++] = 0x00;
            base[bb++] = 0x09; base[bb++] = 0xFF; base[bb++] = 0xFF;
            acc_n = 0;
            int rounds = 0, cont_ok = 1;
            uint8_t clen = 0, coff[2] = { 0, 0 };
            for (;;) {
                size_t rl2 = 0;
                req[rl2++] = 0x06; req[rl2++] = 0x00; req[rl2++] = 0x02;
                uint16_t np = (uint16_t)(bb + 1 + clen);
                req[rl2++] = (uint8_t)(np >> 8); req[rl2++] = (uint8_t)np;
                memcpy(req + rl2, base, bb); rl2 += bb;
                req[rl2++] = clen;
                if (clen) { req[rl2++] = coff[0]; req[rl2++] = coff[1]; }
                n = sdp_server_handle(sv, req, rl2, rsp, sizeof(rsp));
                if (!n || rsp[0] != 0x07) { cont_ok = 0; break; }
                size_t cnt = ((size_t)rsp[5] << 8) | rsp[6];
                memcpy(acc + acc_n, rsp + 7, cnt);
                acc_n += cnt;
                if (rsp[n - 1] == 0) break;           /* no continuation -> done */
                clen = rsp[n - 3];                     /* cont section present */
                if (clen != 2) { cont_ok = 0; break; }
                coff[0] = rsp[n - 2]; coff[1] = rsp[n - 1];
                if (++rounds > 100) { cont_ok = 0; break; }
            }
            CHECK(cont_ok, "continuation loop terminates");
            CHECK(acc_n == total, "chunked reassembly == one-shot length");
            CHECK(memcmp(acc, sdp_server_results(sv), total) == 0, "chunked reassembly == one-shot bytes");
        }

        /* malformed request -> error PDU */
        uint8_t badreq[8] = { 0x06, 0x00, 0x03, 0x00, 0x02, 0xFF, 0xFF, 0x00 };
        n = sdp_server_handle(sv, badreq, sizeof(badreq), rsp, sizeof(rsp));
        CHECK(n >= 7 && rsp[0] == 0x01, "malformed SSA -> error PDU");
        sdp_server_free(sv);
    }

    /* 9. HOGP (Joy-Con-shaped BLE identity) */
    {
        size_t n_att = 0;
        const hogp_att_t *dbp = hogp_joycon_db(&n_att);
        CHECK(n_att >= 10, "HOGP db has entries");
        int monotonic = 1;
        for (size_t i = 1; i < n_att; i++)
            if (dbp[i].handle <= dbp[i-1].handle) monotonic = 0;
        CHECK(monotonic, "handles strictly increasing");
        CHECK(hid_validate_report_map(hogp_joycon_report_map, hogp_joycon_report_map_len) == 0,
              "joycon-shaped report map validates");
        uint8_t pnp[7];
        hogp_pnp_bytes(pnp);
        CHECK(pnp[0] == 2 && pnp[1] == 0x7E && pnp[2] == 0x05, "PnP: USB source + VID 0x057E");
        int found_appearance = 0, found_map = 0;
        for (size_t i = 0; i < n_att; i++) {
            if (dbp[i].uuid16 == 0x2A01 && dbp[i].vlen == 2 && dbp[i].value[0] == 0xC4 && dbp[i].value[1] == 0x03)
                found_appearance = 1;
            if (dbp[i].uuid16 == 0x2A4B && dbp[i].vlen == hogp_joycon_report_map_len &&
                memcmp(dbp[i].value, hogp_joycon_report_map, dbp[i].vlen) == 0)
                found_map = 1;
        }
        CHECK(found_appearance, "appearance 0x03C4 gamepad present");
        CHECK(found_map, "report map served at 2A4B");
    }

    printf("\n%s (%d failures)\n", fails ? "SOME TESTS FAILED" : "ALL TESTS PASSED", fails);
    return fails ? 1 : 0;
}
