#define _DEFAULT_SOURCE
/* HCI/L2CAP engine tests: (1) in-process MOCK Bluetooth controller exercises
   the full device-role sequence (reset -> version -> ConnReq/ConfReq on
   PSM 17+19 -> HID reports flowing as ACL frames); (2) TCP framer robustness
   (byte-split stream reassembly). All host-run (Linux x86_64). */
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/socket.h>
#include "ds4bridge/hci_link.h"
#include "ds4bridge/hci_transport.h"
#include "ds4bridge/transport_null.h"
#include "ds4bridge/ic_packet.h"
#include "ds4bridge/ds4_report.h"

static int fails;
#define CHECK(cond, name) do { \
    if (cond) printf("  PASS %s\n", name); \
    else { printf("  FAIL %s\n", name); fails++; } } while (0)

/* ================= mock controller ================= */
typedef struct {
    uint8_t out[64 * 1024];
    size_t  out_len;
    uint8_t to_host[64 * 1024];
    size_t  host_len;
    uint16_t conn_handle;
    uint16_t psm17_dcid, psm19_dcid;
    uint16_t psm17_scid, psm19_scid;   /* DUT's local cids */
    int      got_report;
    uint8_t  last_report[64];
    size_t   last_report_len;
} mock_ctl;

static void mock_emit(mock_ctl *m, const uint8_t *pkt, size_t len) {
    memcpy(m->to_host + m->host_len, pkt, len);
    m->host_len += len;
}
static void mock_evt_cc_version(mock_ctl *m) {
    uint8_t e[15] = {
        0x04, 0x0E, 12,           /* EVT, Command Complete */
        0x01, 0x01, 0x10, 0x00,   /* num=1, opcode 0x1001, status 0 */
        0x09, 0x00, 0x00,         /* hci_ver 9, hci_rev */
        0x09, 0x0F, 0x00,         /* lmp_ver 9, manufacturer 0x000F (Broadcom) */
        0x00, 0x22                /* lmp_subversion */
    };
    mock_emit(m, e, sizeof(e));
}

/* mock parses what the DUT writes into its queue */
static ssize_t mock_write(void *c, const uint8_t *buf, size_t len) {
    mock_ctl *m = (mock_ctl *)c;
    memcpy(m->out + m->out_len, buf, len);
    m->out_len += len;

    if (buf[0] == 0x01) { /* command */
        uint16_t opcode = (uint16_t)(buf[1] | (buf[2] << 8));
        if (opcode == 0x0C03) { /* reset */
            uint8_t e[7] = { 0x04, 0x0E, 4, 0x01, 0x03, 0x0C, 0x00 };
            mock_emit(m, e, sizeof(e));
        } else if (opcode == 0x1001) {
            mock_evt_cc_version(m);
        }
    } else if (buf[0] == 0x02) { /* ACL */
        uint16_t dlen = (uint16_t)(buf[3] | (buf[4] << 8));
        const uint8_t *pl = buf + 5;
        if (dlen >= 4) {
            uint16_t l2len = (uint16_t)(pl[0] | (pl[1] << 8));
            uint16_t cid   = (uint16_t)(pl[2] | (pl[3] << 8));
            const uint8_t *d = pl + 4;
            if (cid == 1 && l2len >= 4) {
                uint8_t code = d[0], ident = d[1];
                if (code == 0x02) { /* ConnReq: item hdr(4) then psm(2) scid(2) */
                    uint16_t psm  = (uint16_t)(d[4] | (d[5] << 8));
                    uint16_t scid = (uint16_t)(d[6] | (d[7] << 8));
                    uint16_t dcid = (psm == 17) ? 0x0041 : 0x0042;
                    if (psm == 17) { m->psm17_dcid = dcid; m->psm17_scid = scid; }
                    else           { m->psm19_dcid = dcid; m->psm19_scid = scid; }
                    uint8_t rsp[12] = { 0x03, ident, 8, 0,
                        (uint8_t)(dcid & 0xFF), (uint8_t)(dcid >> 8),
                        (uint8_t)(scid & 0xFF), (uint8_t)(scid >> 8),
                        0, 0, 0, 0 };                       /* result=0, status=0 */
                    uint8_t frame[21];
                    frame[0] = 0x02;
                    frame[1] = 0x10; frame[2] = 0x00;
                    frame[3] = 16;   frame[4] = 0;          /* dlen = 4 + l2len */
                    frame[5] = 12;   frame[6] = 0;          /* l2cap len = 12 */
                    frame[7] = 0x01; frame[8] = 0x00;
                    memcpy(frame + 9, rsp, 12);
                    mock_emit(m, frame, 21);                /* 5 + 4 + 12 */
                    /* controller sends its own ConfReq */
                    uint8_t crq[12] = { 0x04, ident, 4, 0,
                        (uint8_t)(scid & 0xFF), (uint8_t)(scid >> 8), 0, 0 };
                    uint8_t f2[17];
                    f2[0] = 0x02; f2[1] = 0x10; f2[2] = 0x00;
                    f2[3] = 12; f2[4] = 0;                  /* dlen = 4 + 8 */
                    f2[5] = 8;  f2[6] = 0;                  /* l2cap len = 8 */
                    f2[7] = 0x01; f2[8] = 0x00;
                    memcpy(f2 + 9, crq, 8);
                    mock_emit(m, f2, 17);                   /* 5 + 4 + 8 */
                } else if (code == 0x04) { /* ConfReq -> ConfRsp success */
                    uint16_t dcid = (uint16_t)(d[4] | (d[5] << 8)); /* payload: dcid(2) flags(2) */
                    /* ConfRsp SCID = the channel endpoint on the REQUESTER (DUT's local cid) */
                    uint16_t scid = (dcid == m->psm17_dcid) ? m->psm17_scid : m->psm19_scid;
                    uint8_t rsp[10] = { 0x05, ident, 6, 0,
                        (uint8_t)(scid & 0xFF), (uint8_t)(scid >> 8),
                        0, 0, 0, 0 };                       /* flags=0, result=0 */
                    uint8_t frame[19];
                    frame[0] = 0x02; frame[1] = 0x10; frame[2] = 0x00;
                    frame[3] = 14; frame[4] = 0;            /* dlen = 4 + 10 */
                    frame[5] = 10; frame[6] = 0;            /* l2cap len = 10 */
                    frame[7] = 0x01; frame[8] = 0x00;
                    memcpy(frame + 9, rsp, 10);
                    mock_emit(m, frame, 19);                /* 5 + 4 + 10 */
                }
            } else if (cid == m->psm19_dcid && l2len >= 5) {
                /* data the DUT pushed to the interrupt channel (l2len includes the 4-byte L2CAP header) */
                size_t dlen2 = (size_t)l2len - 4;
                m->got_report = 1;
                m->last_report_len = dlen2;
                if (dlen2 <= sizeof(m->last_report)) memcpy(m->last_report, d, dlen2);
            }
        }
    }
    return (ssize_t)len;
}
static ssize_t mock_read(void *c, uint8_t *buf, size_t cap) { (void)c; (void)buf; (void)cap; return -1; }
static int  mock_open(void *c) { (void)c; return 0; }
static void mock_close(void *c) { (void)c; }

/* feed everything the mock queued for the host through a reader */
static int pump(mock_ctl *m, hci_reader_t *rd, hci_link_t *link) {
    hci_frame_t f;
    size_t off = 0;
    int frames = 0;
    /* feed ONE byte at a time: hci_reader_feed returns on frame completion
       without consuming the rest of the chunk, so chunked feeding would lose bytes */
    while (off < m->host_len) {
        int r = hci_reader_feed(rd, m->to_host + off, 1, &f);
        off += 1;
        if (r == 1) { hci_link_on_frame(link, &f); frames++; }
        else if (r < 0) { printf("  ! reader error at off=%zu (byte %02X)\n", off, m->to_host[off-1]); return -1; }
    }
    m->host_len = 0;
    return frames;
}

void test_hci_engine(void) {
    printf("hci/l2cap device-role engine (mock controller)\n");
    mock_ctl m; memset(&m, 0, sizeof(m));
    m.conn_handle = 0x0010;

    hci_io_t io = { &m, mock_open, mock_close, mock_write, mock_read };
    hci_link_t *link = hci_link_new(&io);
    CHECK(link != NULL, "link allocates");

    hiddev_t *h = hiddev_new(hci_link_hid_transport(link));
    hci_link_bind_hid(link, h);

    hci_reader_t *rd = hci_reader_new();

    /* establish ACL handle (platform side did it) */
    uint8_t conn_evt[14] = { 0x04, 0x03, 11,
        0x00,                                  /* status OK */
        0x10, 0x00,                            /* handle 0x0010 */
        0x50, 0x11, 0x22, 0x33, 0x44, 0x55,    /* bdaddr */
        0x01, 0x00 };                          /* link type, encryption */
    hci_frame_t f;
    CHECK(hci_reader_feed(rd, conn_evt, sizeof(conn_evt), &f) == 1 && f.handle == 0x03,
          "conn-complete framed");
    hci_link_on_frame(link, &f);
    CHECK(hci_link_handle(link) == 0x0010, "connection handle captured");

    hci_link_cmd_reset(link);
    pump(&m, rd, link);
    CHECK(m.out_len >= 4 && m.out[1] == 0x03 && m.out[2] == 0x0C, "reset command sent");

    hci_link_cmd_read_local_version(link);
    pump(&m, rd, link);
    CHECK(hci_link_version_known(link) && strstr(hci_link_version_str(link), "Broadcom"),
          "local version parsed (mock Broadcom)");

    hci_link_l2cap_connreq(link, 17);
    pump(&m, rd, link);
    CHECK(hci_link_psm_up(link, 17), "PSM 17 channel up after ConnRsp+ConfRsp");

    hci_link_l2cap_connreq(link, 19);
    pump(&m, rd, link);
    CHECK(hci_link_psm_up(link, 19), "PSM 19 channel up");
    CHECK(hiddev_state(h) == HIDDEV_CONNECTED, "hiddev reached CONNECTED via mock");

    /* push input -> must appear as ACL data toward mock's interrupt cid */
    ICInputPacket in; memset(&in, 0, sizeof(in));
    in.magic = IC_MAGIC; in.version = IC_VERSION;
    in.lx = 33; in.hat = IC_HAT_NEUTRAL; in.seq16 = 7; in.t_ms = 1234;
    in.crc = ic_crc16((const uint8_t *)&in, offsetof(ICInputPacket, crc));
    hiddev_set_input(h, &in);
    hiddev_tick(h, 1240);
    CHECK(m.got_report == 1, "HID report emitted as ACL to interrupt channel");
    if (!(m.last_report_len == DS4_BT_REPORT_LEN + 1 &&
          m.last_report[0] == 0xA1 && m.last_report[1] == 0x11 &&
          m.last_report[5] == (uint8_t)(0x80 + 33))) {
        printf("  ! len=%zu bytes:", m.last_report_len);
        for (size_t i = 0; i < m.last_report_len && i < 16; i++) printf(" %02X", m.last_report[i]);
        printf("\n");
    }
    CHECK(m.last_report_len == DS4_BT_REPORT_LEN + 1 &&
          m.last_report[0] == 0xA1 && m.last_report[1] == 0x11 &&
          m.last_report[5] == (uint8_t)(0x80 + 33),
          "report frame bytes correct (0xA1 0x11, LX at [5])");

    hci_reader_free(rd);
    hiddev_free(h);
    hci_link_free(link);
}

/* ================= TCP framer robustness ================= */
static uint16_t g_port;
static int g_srv_fd = -1, g_write_fd = -1;
static pthread_mutex_t g_mu = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t g_cv = PTHREAD_COND_INITIALIZER;

static void *tcp_server_thread(void *arg) {
    (void)arg;
    int s = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in a; memset(&a, 0, sizeof(a));
    a.sin_family = AF_INET;
    a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    a.sin_port = 0;
    bind(s, (struct sockaddr *)&a, sizeof(a));
    socklen_t al = sizeof(a);
    getsockname(s, (struct sockaddr *)&a, &al);
    g_port = ntohs(a.sin_port);
    listen(s, 1);
    pthread_mutex_lock(&g_mu);
    pthread_cond_broadcast(&g_cv);
    pthread_mutex_unlock(&g_mu);
    g_write_fd = accept(s, NULL, NULL);
    /* one Command Complete evt, written byte-by-byte to stress the framer */
    uint8_t evt[15] = { 0x04, 0x0E, 12, 0x01, 0x01, 0x10, 0x00,
                        0x09, 0x00, 0x00, 0x09, 0x0F, 0x00, 0x00, 0x22 };
    for (size_t i = 0; i < sizeof(evt); i++) {
        ssize_t r = send(g_write_fd, evt + i, 1, 0);
        if (r != 1) break;
        usleep(1000);
    }
    return NULL;
}

void test_tcp_framer(void) {
    printf("hci_tcp bridge + framer (loopback)\n");
    pthread_t th;
    pthread_create(&th, NULL, tcp_server_thread, NULL);
    pthread_mutex_lock(&g_mu);
    while (!g_port) pthread_cond_wait(&g_cv, &g_mu);
    pthread_mutex_unlock(&g_mu);

    hci_io_t *io = hci_io_tcp("127.0.0.1", g_port);
    CHECK(io && io->open(io->ctx) == 0, "tcp connect to bridge port");

    hci_reader_t *rd = hci_reader_new();
    hci_frame_t f;
    int got = 0;
    uint8_t buf[64];
    for (int i = 0; i < 200 && !got; i++) {
        ssize_t r = io->read(io->ctx, buf, sizeof(buf));
        if (r > 0 && hci_reader_feed(rd, buf, (size_t)r, &f) == 1) got = 1;
        else usleep(2000);
    }
    CHECK(got == 1, "frame reassembled from byte-split stream");
    if (got) {
        CHECK(f.type == 0x04 && f.handle == 0x0E && f.len == 12, "evt code + plen intact");
        CHECK(f.data[0] == 0x01, "num-handles byte");
        uint16_t opcode = (uint16_t)(f.data[1] | (f.data[2] << 8));
        CHECK(opcode == 0x1001, "opcode readable");
    }
    hci_reader_free(rd);
    io->close(io->ctx);
    free(io->ctx);
    free(io);
    close(g_write_fd);
    close(g_srv_fd);
    pthread_join(th, NULL);
}

/* ============ uart io over socketpair (fake tty) ============ */
static int g_fake_fd = -1;
static void *uart_writer_thread(void *arg) {
    (void)arg;
    /* feed one Command Complete (Read Local Version, Broadcom) byte-by-byte */
    uint8_t evt[15] = { 0x04, 0x0E, 12, 0x01, 0x01, 0x10, 0x00,
                        0x09, 0x00, 0x00, 0x09, 0x0F, 0x00, 0x00, 0x22 };
    for (size_t i = 0; i < sizeof(evt); i++) {
        ssize_t r = write(g_fake_fd, evt + i, 1);
        if (r != 1) break;
        usleep(1000);
    }
    return NULL;
}

void test_uart_io(void) {
    printf("hci_io_uart (socketpair fake-tty)\n");
    int sv[2];
    CHECK(socketpair(AF_UNIX, SOCK_STREAM, 0, sv) == 0, "socketpair created");
    g_fake_fd = sv[1];

    hci_io_t *io = hci_io_uart_fd(sv[0], "fake-uart");
    CHECK(io != NULL && io->open(io->ctx) == 0, "uart io adopted fd");

    pthread_t th;
    pthread_create(&th, NULL, uart_writer_thread, NULL);
    hci_reader_t *rd = hci_reader_new();
    hci_frame_t f;
    int got = 0;
    for (int i = 0; i < 300 && !got; i++) {
        uint8_t b[8];
        ssize_t r = io->read(io->ctx, b, sizeof(b));
        if (r > 0 && hci_reader_feed(rd, b, (size_t)r, &f) == 1) got = 1;
        else usleep(2000);
    }
    CHECK(got == 1 && f.type == 0x04 && f.handle == 0x0E, "event reassembled from uart io");
    pthread_join(th, NULL);

    /* engine writes must reach the other end byte-exact */
    uint8_t cmd[4] = { 0x01, 0x03, 0x0C, 0x00 };
    CHECK(io->write(io->ctx, cmd, 4) == 4, "write HCI reset via uart io");
    uint8_t echo[8] = {0};
    ssize_t r = recv(sv[1], echo, sizeof(echo), 0);
    CHECK(r == 4 && echo[0] == 0x01 && echo[2] == 0x0C, "bytes intact on the wire");

    hci_reader_free(rd);
    io->close(io->ctx);
    free(io->ctx);
    free(io);
    close(sv[0]);
    close(sv[1]);
}

int main(void) {
    test_hci_engine();
    test_tcp_framer();
    test_uart_io();
    printf("\n%s (%d failures)\n", fails ? "SOME TESTS FAILED" : "ALL TESTS PASSED", fails);
    return fails ? 1 : 0;
}
