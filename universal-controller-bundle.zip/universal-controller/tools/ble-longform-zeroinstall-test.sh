#!/bin/sh
# ble-longform-zeroinstall-test.sh — E21 pre-test using ONLY App Store tools
# on iPhone A. Installs NOTHING of ours. Purpose: get a first signal whether
# the long-form (128-bit) 0x1812 spelling passes where the short form (E20)
# was refused — before spending a ProbeBLE install.
#
# NOTE: store tools may normalize/refuse HID UUIDs in their own UI. A refusal
# inside the TOOL is app-level, NOT OS-level evidence. Only an OS-level
# refusal (service adds, advertisement works, peer sees 0x1812) is decisive.
# The clean instrument is ProbeBLE.ipa.
cat <<'DOC'
E21 zero-install pre-test (iPhone A only, ~10 min)
==================================================

Prep: App Store on iPhone A. Turn Bluetooth ON in Settings.

STEP 1 — nRF Connect for Mobile (free) [or LightBlue]
  1. Open nRF Connect > "Server" tab (GATT Server config).
  2. Add service with UUID typed EXACTLY as the long form:
       00001812-0000-1000-8000-00805F9B34FB
     Record: does it ADD or refuse?
       - refuse here = TOOL-level, still informative only if the error text
         is Apple's "UUID not allowed" surfaced through the tool.
  3. If added: add characteristic
       00002A4B-0000-1000-8000-00805F9B34FB  (Read) with any small value,
     then start the server + advertise.
  4. Second device or same-phone scanner: is 0x1812 in the advertisement?

STEP 2 — Bluetouch (existence-proof app, keyboard/touchpad, cheap/free)
  1. Install Bluetouch on A, start its BLE keyboard mode.
  2. On iPhone B (STOCK, untouched): Settings > Bluetooth — does a keyboard
     entry appear? Can B pair it? (Pairing with B's stock UI is allowed; we
     install nothing on B.)
     - B pairs + typing reaches B  => Apple-central BLE-HID host path WORKS
       on iOS 27 -> huge positive signal for the BLE route.
     - B never lists it => central-side filtering (matches X4: Mac couldn't
       see the iPad) -> BLE route to B is likely dead regardless of A-side.

STEP 3 — report back
  Paste: which steps ran, exact errors (screenshot or text), what B showed.
DOC
