#!/bin/sh
# hw-test-checklist.sh — guided hardware test protocol for the REAL devices.
# Run this ON iPhone A (any terminal) and follow the prompts; fill answers into
# docs/08-test-plan.md record tables (rule 24). Nothing here modifies iPhone B.
# STATUS: NOT RUN — no hardware in the build sandbox.
cat <<'EOF'
=== ControllerA hardware test checklist (guided) ===
Device-under-test A: iPhone, iOS 15.8.8, jailbroken, TrollStore
Companion B: stock iPhone, iOS 27 — NEVER modified. B-side actions are limited
to normal user operations (Settings > Bluetooth pairing, opening games).

Fill every result into docs/08-test-plan.md. Mark UNTESTED for skipped steps.

[T0] Run diagnostics
  1. sh aidiag-standalone.sh            -> save aidiag-report.txt
  2. (optional, rootless deb) /var/jb/usr/bin/idiag
  Record: model, model-id, build, jb type/version, rootless/rootful, BT chip.

[T1] App install (acceptance C)
  1. Open TrollStore on A -> install ControllerA.ipa -> launch.
  PASS = app launches, controller UI renders landscape.

[T2] Input pipeline self-test (no B involved)
  1. Open UDP settings (top-left "UDP") -> set any reachable host, e.g. a PC
     running src/ds4bridge/tools/udp_echo (lab instrument, NOT part of the
     shipped system).
  2. Move every control. PASS = status bar counts packets, rtt shown, and the
     echo tool reports replies (latency measurement, requirement 27).

[T3] BLE HID probe (on-device evidence for E6)
  1. Tap "BLE" in the app.
  2. EXPECTED (per external evidence): "HID service UUID 0x1812 BLOCKED
     (CBError 8)". If NOT blocked -> record as MAJOR finding (changes arch!).
  3. Probe 2 advertises a custom service; on B: Settings > Bluetooth — does
     "ControllerA" appear? Record yes/no (evidence for BLE visibility).

[T4] DS4 recognition control experiment on B (validates B-side path)
  1. Pair a REAL DualShock 4 (PS+Share) with B via Settings > Bluetooth.
  2. Open any GameController-aware game on B.
  PASS = controller works. This proves the B-side path we plan to emulate.

[T5] Optional decisive experiment for Phase 3 (needs an ESP32 dev board —
     external lab instrument, NOT part of the shipped system)
  1. Flash an ESP32 with a BT-Classic DS4 HID-device example (e.g. ESP-IDF
     hid_device / StryderUK BluetoothHID).
  2. Pair it with B. PASS if B exposes it as a GCController.
  -> If PASS: the DS4-emulation architecture is validated end-to-end on stock
     iOS 27, and the only remaining work is doing it from iPhone A's BT chip.

[T6+] Bluetooth Classic device-role experiments on A (Phase 3) — see
  docs/05-architecture.md Phase-3 gate list. Record every attempt in
  docs/09-failure-ledger.md with the required 6-line format.
EOF
