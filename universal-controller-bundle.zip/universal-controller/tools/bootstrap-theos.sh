#!/bin/bash
# bootstrap-theos.sh — reproducible Theos install for this sandbox.
# WHY: /home/user/.cache is NOT part of the workspace snapshot, so theos
# disappears between sessions/turns. Run this script to rebuild the exact
# toolchain (clang 11.1.0 via L1ghtmann llvm-project, iPhoneOS14.5.sdk,
# ldid 2.1.5-procursus) at $THEOS=/home/user/.cache/theos.
# Takes ~1-2 min on a warm network. Verified recipe (session 6b/6f).
set -e
# NOTE: the sandbox env presets THEOS=/home/user/theos (not snapshotted-safe).
# We hard-default to .cache/theos; pass THEOS_DIR to override.
export THEOS="${THEOS_DIR:-/home/user/.cache/theos}"

if [ -d "$THEOS/toolchain/linux/iphone/bin" ] && [ -x "$THEOS/bin/ldid" ] && [ -d "$THEOS/sdks/iPhoneOS14.5.sdk" ]; then
    echo "theos already present — nothing to do"
    exit 0
fi

mkdir -p "$THEOS"
# 1) theos itself
if [ ! -f "$THEOS/makefiles/common.mk" ]; then
    rm -rf /tmp/theos-clone
    git clone --depth 1 https://github.com/theos/theos.git /tmp/theos-clone
    # copy into $THEOS preserving whatever exists
    cp -a /tmp/theos-clone/. "$THEOS/"
    git -C "$THEOS" submodule update --init --recursive >/dev/null 2>&1 || true
    # theos ships sdks submodule placeholder; drop it so our SDK copy wins
    rm -rf "$THEOS/sdks"
fi
# 2) toolchain (non-swift, x86_64)
if [ ! -x "$THEOS/toolchain/linux/iphone/bin/clang" ]; then
    mkdir -p "$THEOS/toolchain"
    curl -sL https://github.com/L1ghtmann/llvm-project/releases/latest/download/iOSToolchain-x86_64.tar.xz -o /tmp/tc.tar.xz
    tar -xJf /tmp/tc.tar.xz -C "$THEOS/toolchain/"
fi
# 3) iOS 14.5 SDK (sparse clone = small)
if [ ! -d "$THEOS/sdks/iPhoneOS14.5.sdk" ]; then
    rm -rf /tmp/sdks-sp
    git clone --depth 1 --filter=blob:none --sparse https://github.com/theos/sdks.git /tmp/sdks-sp
    (cd /tmp/sdks-sp && git sparse-checkout set iPhoneOS14.5.sdk)
    mkdir -p "$THEOS/sdks"
    cp -r /tmp/sdks-sp/iPhoneOS14.5.sdk "$THEOS/sdks/"
fi
# 4) ldid
if [ ! -x "$THEOS/bin/ldid" ]; then
    curl -sL https://github.com/ProcursusTeam/ldid/releases/latest/download/ldid_linux_x86_64 -o "$THEOS/bin/ldid"
    chmod +x "$THEOS/bin/ldid"
fi

echo "toolchain: $("$THEOS/toolchain/linux/iphone/bin/clang" --version | head -1)"
"$THEOS/bin/ldid" 2>&1 | head -1 || true
ls "$THEOS/sdks/"
echo "theos bootstrap complete at $THEOS"
