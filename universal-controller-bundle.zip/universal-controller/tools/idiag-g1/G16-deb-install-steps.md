# คู่มือติดตั้ง .deb บน iPhone A (ละเอียดทีละขั้น) — สำหรับ G1.6

## ก่อนอื่น: ไฟล์ .deb ใน bundle มี 3 ตัว ต้องใช้แค่ 2

| ไฟล์ | คืออะไร | ต้องติดตั้งตอนนี้? |
|---|---|---|
| `com.research.idiag_0.4.0_iphoneos-arm64.deb` | เครื่องมือตรวจเครื่อง (อ่านอย่างเดียว) | ✅ ใช่ |
| `com.research.btiotest_0.1.0_iphoneos-arm64.deb` | เครื่องมือทดลองเปิดพอร์ต Bluetooth UART | ✅ ใช่ |
| `com.research.ds4bridged_0.2.0_iphoneos-arm64.deb` | daemon ตัวจริงของโปรเจกต์ (รอพิสูจน์พอร์ตก่อน แล้วค่อยใช้เวอร์ชันใหม่) | ❌ **ยังไม่ต้องติดตั้ง** |

อยู่ในโฟลเดอร์: `universal-controller/artifacts/`

---

## ขั้นที่ 1 — เอาไฟล์ 2 ตัวขึ้นเครื่อง iPhone A

### ทางเลือก 1: จากเครื่องคอม (ถ้าดาวน์โหลด bundle ไว้ที่คอม)
1. แตก zip (คลิกขวา > Extract All หรือดับเบิลคลิก)
2. เข้าโฟลเดอร์ `universal-controller/artifacts/`
3. ส่งไฟล์ 2 ตัวขึ้นเครื่อง iPhone A ได้ด้วยวิธีใดก็ได้:
   - ลากใส่ **iCloud Drive** (จากคอม) → บนโทรศัพท์เปิดแอป **Files > iCloud Drive** จะเจอ
   - หรือแนบเข้า **อีเมล/LINE/Telegram** ตัวเอง แล้วดาวน์โหลดบนโทรศัพท์
   - หรือเสียบสาย USB แล้วคัดลอกผ่าน iTunes > File Sharing (แอปใดก็ได้ที่มี File Sharing)

### ทางเลือก 2: ใช้ iPhone A อย่างเดียว (ไม่ต้องมีคอม)
1. เปิดลิงก์ bundle ใน Safari บน iPhone A → ดาวน์โหลด `universal-controller-bundle.zip`
2. เปิดแอป **Files** (ไฟล์ของ Apple) → โฟลเดอร์ **Downloads** → **แตะที่ไฟล์ zip หนึ่งครั้ง** → iOS จะแตกไฟล์ให้เป็นโฟลเดอร์ชื่อเดียวกัน
3. เข้าไปตามทาง: `universal-controller` > `artifacts` → จะเห็น .deb 3 ตัว

## ขั้นที่ 2 — เก็บไฟล์ไว้ที่เดียวในเครื่อง (แนะนำ)

เพื่อให้พาธตายตัว (ใช้ต่อใน terminal ได้ง่าย):
1. ในแอป Files: กดค้างไฟล์ `com.research.idiag_0.4.0...deb` > **Copy**
2. ไปที่ **On My iPhone** (บน iPhone ของฉัน) — ถ้าไม่มีโฟลเดอร์ว่าง ให้สร้างโฟลเดอร์ชื่อ `tools`
3. วาง (Paste) → ทำซ้ำกับ `com.research.btiotest_0.1.0...deb`

## ขั้นที่ 3 — ติดตั้งด้วย Filza (วิธีง่ายสุด)

1. เปิดแอป **Filza**
2. ไปที่โฟลเดอร์ที่วางไฟล์ไว้:
   - ใน Filza แถบด้านซ้าย/ล่างจะมี Favorites — เลือก **Applications** แล้วเลื่อนหา On My iPhone ไม่ได้โดยตรง ให้กดที่แถบพาธด้านบน พิมพ์พาธ: `/var/mobile/Documents/` (ถ้าคุณวางไว้ที่นั่น) หรือจำตำแหน่งจากแอป Files แล้วเดินทางตาม
   - เคล็ดลับ: ใน Filza สามารถกดปุ่มรูปแว่นขยาย/search แล้วพิมพ์ชื่อไฟล์ `btiotest` ให้ระบบหาให้ได้เลย
3. **แตะที่ไฟล์ .deb** → ขึ้นหน้ารายละเอียดแพ็กเกจ → มุมขวาบนกด **Install**
4. รอจบ (จะเห็นข้อความ install ไล่บรรทัด) → ถ้ามีปุ่ม **Respring** กดได้ (เครื่องมือแบบ command-line จริง ๆ ไม่ต้อง respring ก็ใช้ได้)
5. **ทำซ้ำกับอีกไฟล์**

### ตรวจว่าติดตั้งสำเร็จ
ใน Filza ไปที่พาธ `/var/jb/usr/bin/` (กดที่แถบพาธด้านบนพิมพ์เข้าไป) — ต้องเห็น:
- `idiag`
- `btiotest`

เห็นสองไฟล์นี้ = เสร็จขั้นติดตั้ง

## ขั้นที่ 3 (ทางเลือก B) — ติดตั้งด้วย terminal แทน

ถ้า Filza ติดตั้งไม่ได้/ไม่สะดวก:
1. เปิด **NewTerm 3** พิมพ์:
   ```
   sudo dpkg -i /var/mobile/Documents/com.research.idiag_0.4.0_iphoneos-arm64.deb /var/mobile/Documents/com.research.btiotest_0.1.0_iphoneos-arm64.deb
   ```
   (ปรับพาธตามที่วางไฟล์จริง; ถ้าถามรหัสผ่านพิมพ์ `alpine`)
2. ไม่มี error = ติดตั้งแล้ว (ตรวจเหมือนขั้นที่ 3 ได้: `ls /var/jb/usr/bin/idiag /var/jb/usr/bin/btiotest`)
3. หมายเหตุ: ถ้าติดตั้งซ้ำแล้วฟ้องว่ามีอยู่ ให้บังคับทับด้วย `sudo dpkg -i --force-reinstall <ไฟล์>`

---

## จบแล้ว → ไปต่อ runbook G1.6 (ไฟล์ G16-runbook-postjb.md)

สั้น ๆ: `sudo /var/jb/usr/bin/idiag` (ส่ง output ทั้งหมด) → บันไดทดลอง btiotest → BlueTool — รายละเอียดอยู่ในไฟล์ runbook หลัก
