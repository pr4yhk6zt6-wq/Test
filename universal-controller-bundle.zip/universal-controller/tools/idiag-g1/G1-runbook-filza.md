# G1 RUNBOOK — อัปเดต 2026-09-27: ผลจากหน้างาน = ไม่มี /var/jb

## ทางที่ใช้ตอนนี้ (หลัก): idiagTS.ipa — ไม่ต้องมี jailbreak เลย
ค้นพบว่าเครื่อง A ไม่มี /var/jb → แผน LaunchDaemon ใช้ไม่ได้ (ยัง)
เราเลยทำ **idiagTS.ipa** (v0.1.0) — แอปตรวจการทำงานแบบเดียวกับ idiag แต่ติดผ่าน
TrollStore ได้เลย (เหมือน ProbeBLE) ไม่ต้องพิมพ์คำสั่ง ไม่ต้องมี jb

### ขั้นตอน
1. เอา `artifacts/idiagTS.ipa` ขึ้นเครื่อง A (วิธีเดิมกับ ProbeBLE.ipa)
2. เปิดแอป **TrollStore** → ติดตั้ง idiagTS.ipa
3. เปิดแอป idiagTS → กด **RUN AUDIT** → กด **COPY REPORT** → วางข้อความมาที่แชท
   (รายงานถูกเซฟที่ /var/mobile/Documents/idiag-ts-report.txt ด้วย)
4. เก็บด้วย: ตอบด้วยว่า iPhone A รุ่นอะไร (Settings > General > About > Model Name)
   และมีแอป jailbreak ตัวไหนในเครื่อง (ชื่อแอป เช่น Dopamine/palera1n/unc0ver)?

### สิ่งที่ idiagTS จะบอก
- รุ่นเครื่อง + ชิป + เป็น checkm8 ได้ไหม (แปลว่า palera1n ใช้ได้ไหม)
- สถานะ jailbreak จริง (/var/jb, /.procursus, substrate ฯลฯ)
- /dev/uart.bluetooth มีไหม + **ลอง open() จริง** (ถ้าเปิดได้จากแอป TS = G3 ทางลัด!)
- BlueTool / bluetoothd อยู่ไหม + IOKit ชื่อชิป Bluetooth (ถ้าอ่านได้)

---

# (แผนเดิม — ใช้เมื่อยืนยันว่ามี jailbreak แล้ว)
# G1 RUNBOOK — รัน idiag audit บน iPhone A ด้วย Filza ล้วน (ไม่ต้องพิมพ์คำสั่ง, ไม่ติดตั้งแอปเราใหม่)

เป้าหมาย: ได้ไฟล์รายงาน `idiag-report.txt` (บอกชิป Bluetooth, ประเภท jailbreak,
TrollStore, /dev/uart.bluetooth, BlueTool firmware tokens) ส่งกลับมาที่แชท

สิ่งที่ต้องมี: Filza (มีอยู่แล้ว), แอป jailbreak ของคุณ (Dopamine หรือ palera1n)
สิ่งที่เพิ่มเข้าเครื่อง A: ไฟล์ idiag (diagnostic เดียว) + ไฟล์ plist ตัวเดียว —
**ทั้งหมดเป็นการเพิ่มไฟล์ ไม่แก้ไขไฟล์ระบบเดิมเลย** และ idiag อ่านอย่างเดียว (read-only)

ไฟล์ที่ใช้ (อยู่ใน bundle): `tools/idiag-g1/LaunchDaemons/com.research.idiag-g1.plist`
และ `artifacts/com.research.idiag_0.4.0_iphoneos-arm64.deb`

---

## ขั้นที่ 1 — ติดตั้ง idiag (เอา .deb เข้าเครื่องก่อน)
1. คัดลอกไฟล์ `com.research.idiag_0.4.0_iphoneos-arm64.deb` ไปไว้บนเครื่อง A
   (เช่นผ่าน AirDrop / ไฟล์แนบ / ดาวน์โหลด — วิธีเดียวกับที่เอา ProbeBLE.ipa เข้าเครื่อง)
2. เปิด **Filza** → ไปที่โฟลเดอร์ที่ไฟล์ .deb อยู่ (เช่น Downloads หรือ /var/mobile/Documents)
3. **แตะไฟล์ .deb** → กด **Install** → รอจบ → ถ้ามีปุ่ม Respring ให้ Respring

เช็คว่าสำเร็จ: ใน Filza ไปที่ `/var/jb/usr/bin/` ต้องเห็นไฟล์ `idiag`
(ถ้าไม่มีโฟลเดอร์ /var/jb เลย = เครื่องเป็น rootful → ดู "เคส C" ด้านล่าง)

## ขั้นที่ 2 — วางตัว Trigger (plist)
1. เอาไฟล์ `com.research.idiag-g1.plist` ขึ้นเครื่อง A เหมือนขั้นที่ 1
2. ใน Filza: คัดลอกไฟล์นี้ (กดค้าง → Copy) แล้วไปวางที่
   **`/var/jb/Library/LaunchDaemons/`** (วางให้ชื่อไฟล์เหมือนเดิม: com.research.idiag-g1.plist)

## ขั้นที่ 3 — ปลุกให้ทำงาน (Userspace Reboot)
1. เปิดแอป jailbreak ของคุณ (Dopamine / palera1n)
2. กด **Userspace Reboot** (อย่ากดปิดเครื่องเฉย ๆ นะ — ต้อง re-jailbreak ถ้าปิดเครื่องจริง)
3. รอเครื่องกลับมาสักครึ่งนาที — idiag จะถูกเรียกอัตโนมัติตอนบูต

## ขั้นที่ 4 — เก็บผล (ใน Filza อีกเช่นกัน)
ดู 2 ไฟล์นี้ (มีอย่างน้อยหนึ่งไฟล์ต้องเกิด):
- `/var/mobile/Library/idiag-report.txt`   ← รายงานหลัก (idiag เขียนเอง)
- `/var/mobile/Documents/idiag-out.txt`    ← ผล stdout (จาก plist)

ส่งกลับมา: กดค้างไฟล์ → Share/Copy แล้ววางข้อความมาที่แชท (หรือส่งเป็นไฟล์/ภาพหน้าจอ
ให้ครบทั้งไฟล์) **ส่งมาทั้งไฟล์ อย่าตัดทอน** เพราะทุก section มีความหมาย

รู้ว่าสำเร็จ: ไฟล์มีหัวข้อ `--- IOKit / Bluetooth chip ---` และ
`BlueTool firmware/chip tokens: (...)` — บรรทัดพวกนี้คือคำตอบ G1 ที่เราตามหา
(ถ้าบางบรรทัดขึ้น UNKNOWN ให้ส่งมาตามจริง — UNKNOWN ก็คือข้อมูลอย่างหนึ่ง)

## เคส C — ถ้าใน Filza ไม่มีโฟลเดอร์ /var/jb (แปลว่า rootful)
- แทนขั้นที่ 2: วาง plist ที่ `/Library/LaunchDaemons/` แทน
- ขั้นอื่นเหมือนเดิมทุกอย่าง

## เคส D — ถ้า Userspace Reboot แล้วไม่มีไฟล์เกิดขึ้นเลย
ทางเลือกสำรอง (ต้องติดตั้ง terminal จากตัวจัดการแพ็กเกจของ jailbreak):
1. ติดตั้ง **NewTerm 3** (หรือ NewTerm 2) จาก Sileo/Zebra/Installer
2. เปิด NewTerm พิมพ์: `sudo /var/jb/usr/bin/idiag`
   (ถ้าถามรหัสผ่าน: ลอง `alpine`)
3. รายงานจะถูกเขียนที่ `/var/mobile/Library/idiag-report.txt` เหมือนเดิม → ส่งกลับเหมือนขั้นที่ 4

## หลังยืนยันแล้วว่าข้อมูลครบ
ลบ `com.research.idiag-g1.plist` ทิ้งได้ (หรือค้างไว้ก่อน จนกว่าผมจะยืนยันว่า
ข้อมูลใช้ได้ — ถ้าขาดอะไรจะได้รันซ้ำโดยไม่ต้องตั้งใหม่)
