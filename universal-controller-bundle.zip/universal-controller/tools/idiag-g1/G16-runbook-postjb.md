# G1.6 RUNBOOK — ทดลองบนเครื่อง A หลังเจลเบรคสำเร็จ (มี root แล้ว)

สถานะที่ยืนยันแล้ว: เจลเบรคทำงานอยู่ (rootless, แบบ palera1n — ดูหมายเหตุชื่อด้านล่าง),
`/var/jb` มีจริง, `/dev/uart.bluetooth` มีจริง (โดน EBUSY เพราะ bluetoothd ถืออยู่),
BlueTool อยู่ที่ `/usr/sbin/BlueTool`

> **หมายเหตุชื่อเครื่องมือ**: ที่บอกว่า "Dopamine" — ตามหลักฐานใน report (`/var/jb/basebin = YES`)
> ตัวที่ลงคือตระกูล **palera1n** (Dopamine รันบน iOS 15.8.8 ไม่ได้ และไม่สร้าง basebin)
> ไม่เป็นปัญหาอะไร — แต่จำไว้ว่า: **ถ้าปิดเครื่องจริง (power off) ต้องเสียบคอมเพื่อเข้า jb ใหม่**
> ใช้ประจำวันให้กด Userspace Reboot จากแอป palera1n loader แทนการปิดเครื่อง
> และรหัสสล็อกต้องปิดต่อในสถานะ jb (กฎ iOS 15)

## ของที่ต้องเตรียม

ไฟล์ 2 ตัวจาก bundle (วิธีส่งเข้าเครื่องเดิม):
- `artifacts/com.research.idiag_0.4.0_iphoneos-arm64.deb`
- `artifacts/com.research.btiotest_0.1.0_iphoneos-arm64.deb`  ← ตัวใหม่ (เจาะทดสอบพอร์ต UART)

## ขั้นที่ 1 — ติดตั้ง terminal (ครั้งเดียว)

1. ถ้ายังไม่มี Sileo/Zebra: เปิดแอป loader ของ palera1n → ติดตั้ง **Sileo**
2. ใน Sileo ค้นหาและติดตั้ง: **NewTerm 3** (terminal บนเครื่อง) และ **Filza** (ถ้ายังไม่มี — สะดวกตอนติดตั้ง deb ด้วยการแตะ)

## ขั้นที่ 2 — ติดตั้งเครื่องมือ 2 ตัว

ทางเลือก A (Filza): เอาไฟล์ .deb ทั้งสองขึ้นเครื่อง → ใน Filza แตะไฟล์ → Install (ทำทีละไฟล์)
ทางเลือก B (NewTerm): หลังเอาไฟล์ไว้ที่ `/var/mobile/Documents/` แล้วพิมพ์:
```
sudo dpkg -i /var/mobile/Documents/com.research.idiag_0.4.0_iphoneos-arm64.deb /var/mobile/Documents/com.research.btiotest_0.1.0_iphoneos-arm64.deb
```
(ถ้าถามรหัสผ่าน: `alpine`)

## ขั้นที่ 3 — idiag เต็มในฐานะ root (ปิดคำถาม "ชิปอะไร")

```
sudo /var/jb/usr/bin/idiag
```
ส่ง output **ทั้งหมด** กลับมา — รอบนี้ส่วน IOKit ต้องอ่านได้แล้ว (ตอนไม่มี root ขึ้น UNKNOWN) → ได้ชื่อชิป Bluetooth จริง

## ขั้นที่ 4 — ทดลองชิงพอร์ต UART (หัวใจของ G1.6)

พิมพ์ตามลำดับ แล้ว**จด/คัดลอกผลแต่ละขั้น**:

```
sudo /var/jb/usr/bin/btiotest
```
→ คาดหมาย: EBUSY (ฐานเทียบ — bluetoothd ยังถืออยู่)

แล้วปลดพอร์ต ไล่จากเบาไปหนัก (หลังแต่ละขั้นรัน `sudo /var/jb/usr/bin/btiotest` ซ้ำ):
```
(ก) ปิด Bluetooth ใน Settings → sudo /var/jb/usr/bin/btiotest
(ข) sudo killall bluetoothd   → sudo /var/jb/usr/bin/btiotest
(ค) launchctl list | grep -i blue     ← ส่งผลบรรทัดนี้มาด้วยเสมอ
    sudo launchctl stop <ชื่อที่เห็น>  → sudo /var/jb/usr/bin/btiotest
```
ถ้ามีขั้นไหนได้ `open() OK` → รันทันที:
```
sudo /var/jb/usr/bin/btiotest -w
```
→ ถ้าขึ้น **"Command Complete EVENT — controller is ALIVE"** = ชิปตอบเราเป็น HCI จริ ง = G3 ผ่านประตูใหญ่แล้ว

## ขั้นที่ 5 — G2: BlueTool smoke (ทำหลังจากขั้น 4 แล้ว)

(เงื่อนไข: Bluetooth ต้องปิดอยู่ใน Settings — ตามที่เคยบันทึกไว้ E14)
```
sudo /usr/sbin/BlueTool
```
พอเข้า prompt ของมัน พิมพ์: `hci cmd 0x2018` แล้วส่งผลมา (ถ้ามันฟ้องพอร์ตไม่ว่าง = bluetoothd ยังถือ → กลับไปขั้น (ค) ก่อน)

## ขั้นสุดท้าย

เปิด Bluetooth กลับเป็น ON ตามเดิม แล้วส่งผลทุกขั้นมาให้ครบ (ข้อความ/ภาพหน้าจอก็ได้)

---

### ตีความผลล่วงหน้า
- ขั้นไหนได้ open OK + `-w` มี Command Complete → **G3 ทางตรงผ่าน** → ผมจะเขียน daemon (ds4bridged + hci_io_uart ที่เตรียมไว้แล้ว ทดสอบ sandbox 75/75) ให้แอปรับ input ผ่าน UDS แล้วยิงเป็น DS4 จริงออกทาง UART
- ถ้า EBUSY ยังไม่ยอมหลุดทั้งที่ kill/stop แล้ว → ส่ง output ของ `launchctl list | grep -i blue` มา ผมวิเคราะห์ต่อ (มีแผนสำรอง: BlueTool ทางลัด)
- ทุกอย่างอ่านอย่างเดียว/ชั่วคราว — killall bluetoothd ระบบจะดึงกลับมาเองหลังรีบูต userspace ไม่มีความเสียหายถาวร


---

## อัปเดตจากรอบแรก (2026-09-27): คำสั่งที่ถูกต้องแบบ "พิมพ์ตามได้เลย" ไม่มี <>

สิ่งที่เรียนรู้จากรอบแรก:
- บนเครื่องนี้ daemon ที่ถือพอร์ตอาจเป็น **BlueTool เอง** (เห็น com.apple.BlueTool รันเป็นเซอร์วิส PID 7462) ไม่ใช่แค่ bluetoothd
- ตัวอักษร < > ในคู่มือก่อนหน้าคือตัวแทน "ให้เอาชื่อจริงมาแทน" — ห้ามพิมพ์รวม < > ตาม

### ลำดับคำสั่งรอบสอง (พิมพ์ตามนี้ทั้งหมด, บรรทัดละคำสั่ง)
1. เปิดโหมดเครื่องบิน + ปิด Bluetooth ใน Settings ก่อน (กัน daemon โดนปลุกใหม่)
2. ดูชื่อ process จริง:
   sudo ps axww | grep -i blue
   (ส่ง output บรรทัดนี้มาให้ด้วย — เราจะรู้ชื่อ process ที่ killall หาไม่เจอ)
3. หยุดสองเซอร์วิส (ชื่อนี้ตรงจาก launchctl ของเครื่องคุณเอง):
   sudo launchctl stop com.apple.bluetoothd
   sudo launchctl stop com.apple.BlueTool
4. ลองพอร์ตทันที:
   sudo /var/jb/usr/bin/btiotest -w
5. ถ้ายัง EBUSY ให้ bootout (ถอนจาก launchd ชั่วคราว):
   sudo launchctl bootout system/com.apple.bluetoothd
   sudo launchctl bootout system/com.apple.BlueTool
   sudo /var/jb/usr/bin/btiotest -w
6. ทางเลือกเสริมถ้ามีเครื่องมือ: sudo lsof /dev/uart.bluetooth  (บอกว่าใครถือพอร์ต)

### ถ้าได้ "open() OK"
- ถ้ามีข้อความ "Command Complete EVENT — controller is ALIVE" = ชิปตอบ HCI แล้ว
  -> อย่าทำอะไรต่อในเทอมินัล เก็บหน้าจอส่งมาได้เลย นั่นคือผลที่ทั้งโปรเจกต์รอ

### เสร็จแล้วกู้คืนทุกอย่างด้วยคำสั่งเดียว
Userspace Reboot จากแอป Dopamine (เปิด Bluetooth กลับ ON ได้) — daemon ทุกตัวกลับมาเอง

### เคสขอบ: ถ้า launchctl ฟ้องว่าหา service ไม่เจอ
เพราะ domain ไม่ตรง — ลอง:
   sudo launchctl print system/com.apple.bluetoothd | head -5
แล้วส่งผลมา (เราจะปรับคำสั่งให้ตรง domain)


---

## รอบ 3 (2026-09-27): btiotest v0.2.0 — ยิง Reset ไล่ 12 คอมโบ baud/flow

ทำไม: รอบสองเปิดพอร์ตได้แล้ว (open OK) แต่ v0.1.0 ไม่ได้ตั้งค่า baud — ชิป BCM4350 ที่
BlueTool ตั้งไว้น่าจะอยู่คลาส 3M baud + HW flow ข้อมูลเลยไปเป็นสัญญาณรบกวน
v0.2.0 จะไล่ทดสอบ 115200 / 921600 / 1M / 2M / 3M / 4M × (flow on/off) แล้วรอ
Command Complete ที่แต่ละค่า — ตัวที่ตอบคือ config จริงของเครื่องนี้

### คำสั่งรอบ 3 (พิมพ์ตาม, บรรทัดละคำสั่ง)
1. อัปเดตเครื่องมือ (ไฟล์ใหม่ com.research.btiotest_0.2.0 ขึ้นเครื่องก่อน วางที่ Documents เหมือนเดิม):
   sudo dpkg -i /var/mobile/Documents/com.research.btiotest_0.2.0_iphoneos-arm64.deb
2. sudo launchctl bootout system/com.apple.bluetoothd
3. sudo launchctl bootout system/com.apple.BlueTool
4. sudo /var/jb/usr/bin/btiotest -w

### ผลที่จะเห็น
- ไล่ทีละคอมโบ ~1.5 วินาที รวมไม่เกิน ~30 วิ
- **ถ้าเห็น ">>> COMMAND COMPLETE at baud=... — controller ALIVE <<<"** → จับภาพหน้าจอ
  ให้ครบทุกบรรทัด นั่นคือคำตอบสุดท้ายของ G3 (บอกด้วยว่า baud/flow คืออะไร)
- ถ้าครบ 12 คอมโบแล้วยังเงียบ → ส่ง output ทั้งหมดมา (บางคอมโบอาจขึ้น "write=-1 ... CTS held"
  ก็คือข้อมูล: แปลว่าชิปคุม flow อยู่)

### ปิดท้ายทุกครั้ง
Userspace Reboot จากแอป Dopamine (พอร์ตกลับสู่ระบบ + Bluetooth ใช้ได้ตามปกติ)


---

## รอบ 3b (2026-09-27): ติดตั้ง btiotest 0.2.0 ตัวจริง + ส่งภาพให้ครบ

สรุปรอบ 3: (ก) ติดตั้งผิดไฟล์ — ได้ ds4bridged_0.2.0 (ไฟล์ที่สาม) แทนที่ btiotest_0.2.0
ชื่อไฟล์สองตัวลงท้าย _0.2.0 เหมือนกัน เลือกด้วยคำว่า **btiotest** ในชื่อไฟล์เท่านั้น
ds4bridged ที่ติดพลาดไปไม่เป็นไร (ไม่ทำงานเอง ไม่แตะ Bluetooth ปล่อยไว้ได้)
(ข) sudo ต้องเรียก launchctl แบบเต็มพาธ: sudo /var/jb/bin/launchctl
(แต่รอบนี้ไม่ต้อง bootout ซ้ำ — ของรอบก่อนยังอยู่: "No such process" = ถอนแล้ว)

### คำสั่งรอบ 3b
1. (เอาไฟล์ com.research.**btiotest**_0.2.0_iphoneos-arm64.deb ขึ้นเครื่อง วาง Documents)
   sudo dpkg -i /var/mobile/Documents/com.research.btiotest_0.2.0_iphoneos-arm64.deb
2. sudo /var/jb/usr/bin/btiotest -w
3. รอ ~30 วิ ให้มันไล่ครบ 12 คอมโบ

### สิ่งที่ต้องส่งกลับ (สำคัญมาก)
- ภาพต้องครบ **จนถึงบรรทัด "close OK"** — สองรอบที่ผ่านมาภาพตัดพอดีหลัง
  "wrote HCI Reset" ซึ่งเป็นบรรทัดที่ผมต้องเห็น (ชิปตอบ hex หรือเงียบ)
- ถ้าเห็น ">>> COMMAND COMPLETE at baud=... <<<" → ภาพนั้นคือคำตอบของ G3 ทั้งหมด
- ถ้า 12 คอมโบเงียบหมด → ส่งทั้งหมดมา (แต่ละบรรทัดบอกสถานะ flow ของชิปให้ผมด้วย)

### จบแล้ว
Userspace Reboot (แอป Dopamine) — ทุกอย่างกลับปกติ


---

# รอบ 4 (2026-09-27): BTKit.ipa — แบบกดปุ่มล้วน ไม่ต้องพิมพ์อีกแล้ว

ทำเป็นแอปให้แล้ว: **artifacts/BTKit.ipa v0.1.0** (แอป + ตัว helper สิทธิ์ root ในตัว)

### ขั้นตอนทั้งหมด
1. เอาไฟล์ `BTKit.ipa` ขึ้นเครื่อง A (วิธีเดิม) → ติดตั้งผ่าน **TrollStore**
2. เปิดแอป **BTKit** → จะเห็นปุ่มใหญ่ 4 ปุ่ม + กล่อง log
3. กด **1 STOP DAEMONS** → รอข้อความจบ (จะมีบรรทัด open test ด้วย)
   - ถ้าขึ้นขึ้นต้นว่า `bthelper v0.1.0 (euid=0 ...)` = ได้ root ถูกต้อง
   - ถ้าขึ้น `NO_ROOT` = setuid ไม่ผ่าน → บอกผม (มีแผนสำรองเป็นคำสั่ง 2 บรรทัดเดิม)
4. กด **2 UART SWEEP (~30s)** → แอปจะไล่ 12 คอมโบ baud/flow ให้เอง
   - **ถ้าเห็น ">>> COMMAND COMPLETE at baud=... <<<" พร้อมบรรทัด ">>> CONFIG baud=... hwflow=... <<<"** = คำตอบสุดท้ายของ G3 ได้แล้ว
5. กด **COPY LOG** → วางข้อความมาที่แชท (ไม่ต้องจับภาพหน้าจอ ข้อความครบกว่า)
6. กด **3 RESTORE BT** เพื่อคืน Bluetooth (ถ้าคืนไม่สำเร็จ: Userspace Reboot จากแอป Dopamine = เหมือนเดิมทุกอย่าง)

หมายเหตุ: log ทุกครั้งถูกเซฟที่ /var/mobile/Documents/btkit-log.txt ด้วย


## รอบ 5 (2026-09-27): BTKit v0.1.3 — ได้ root ผ่าน sudo ของ jailbreak เอง
เหตุผล: v0.1.2 ยืนยันว่า setuid ในโฟลเดอร์แอปไม่เด้งเป็น root (euid=501) — เราจึงใช้กลไก
ที่พิสูจน์แล้วบนเครื่องนี้: sudo ของ jailbreak (แอปพิมพ์รหัส alpine ให้เอง)
ขั้นตอน: ติดตั้ง BTKit.ipa ตัวใหม่ (0.1.3) ผ่าน TrollStore → กด 1 STOP → 2 SWEEP →
COPY LOG → 3 RESTORE (เหมือนเดิมทุกอย่าง)
สังเกต: บรรทัดแรกของผลต้องเป็น "bthelper v0.2.0 (euid=0 uid=0)" = ได้ root จริง
ถ้าเห็น [AUTH FAILED] = รหัส sudo ของเครื่องไม่ใช่ alpine → บอกผมได้เลย (ไม่ต้องบอกรหัส)


---

# รอบ 6 (2026-09-27): BTKit v0.1.4 — 2 ทางเลือก ไม่ต้องเปิดเผยรหัส

สิ่งที่รู้จากรอบ 5: sudo ทำงาน แต่รหัสเครื่องไม่ใช่ alpine (ห้ามส่งรหัสมาในแชท!)
v0.1.4 จึงมี 2 ทาง — เลือกอันเดียว:

## ทาง B (แนะนำ — ตั้งครั้งเดียว ไม่ต้องใช้รหัสอีกเลย): one-time setup 2 บรรทัด
เปิด NewTerm (คุณเป็น root อยู่แล้วตาม prompt `#` — ถ้าเป็น `%` ให้ขึ้นบรรทัดด้วย sudo):
```
sudo cp /private/var/containers/Bundle/Application/*/BTKit.app/bthelper /var/jb/usr/bin/bthelper
sudo chmod 6755 /var/jb/usr/bin/bthelper
```
(คัดลอกตัว helper ไปที่ปลอดภัยของ jailbreak ตรงนั้น setuid ทำงานจริง — หลักฐาน: sudo
ตัวเองก็เป็น setuid บนพาร์ติชันเดียวกัน) — *ทำซ้ำ 2 บรรทัดนี้ทุกครั้งที่อัปเดต BTKit*

## ทาง A (ง่ายสุดแต่ต้องพิมพ์รหัสทุกครั้งที่เปิดแอปใหม่)
เปิด BTKit → กรอกรหัส sudo ในช่องใหม่ด้านบน (รหัสอยู่ในหน่วยความจำแอปเท่านั้น —
ไม่บันทึก ไม่ส่งไปไหน ไม่เห็นใน log) → กดปุ่มตามปกติ

## แล้วดำเนินการต่อ (เหมือนเดิม)
กด 1 STOP → 2 UART SWEEP → COPY LOG ส่งมา → 3 RESTORE
บรรทัดเป้าหมาย: `bthelper v0.2.0 (euid=0 uid=0)` และ `>>> CONFIG baud=... hwflow=... <<<`


## รอบ 7 (2026-09-27): BTKit v0.1.6 — kill process ตรง (ไม่พึ่ง launchd)
ทำไม: รอบ 6 launchctl ถูกต้องแล้วแต่บอก "No such process" ทั้งคู่ ทั้งที่พอร์ตยัง EBUSY
= ตัวถือพอร์ตไม่ได้อยู่ในทะเบียนชื่อนั้น รอบนี้ helper ไล่มอง process ทั้งเครื่องเอง
(sysctl) แล้ว kill ทุกตัวที่ชื่อมี "bluet" (TERM ก่อน แล้ว KILL ที่ยังอยู่) แล้วค่อยทดสอบพอร์ต
ขั้นตอน: ติดตั้ง BTKit.ipa (0.1.6) → กรอกรหัส → 1 STOP (ดูบรรทัด kill(...) และ port test
ต้อง open() OK) → 2 UART SWEEP → COPY LOG → 3 RESTORE


## รอบ 8 (2026-09-27): BTKit v0.1.7 — ฟิลเตอร์ "blue" + เปิดโปงทุก process
ทำไม: รอบ 7 ยิง BlueTool ตายสำเร็จ (kill 9197) แต่ยัง EBUSY = เหลือผู้ถืออีกตัวที่ชื่อ
ไม่มี "bluet" — น่าจะคือ "blued" (ชื่อ daemon ของ iOS ไม่มีตัว t) รอบนี้ฟิลเตอร์ใหม่จับ
"blue" ทั้งตระกูล และถ้ายัง EBUSY จะพิมพ์รายชื่อ process ทั้งเครื่องออกมาใน log
ขั้นตอนเดิม: ติดตั้ง 0.1.7 → รหัส → 1 STOP → 2 SWEEP → COPY LOG → 3 RESTORE


## รอบ 9 (2026-09-27): BTKit v0.1.8 — เจอตัวการจริงแล้ว (btiotest ตัวค้างจาก terminal)
dump จากรอบก่อนเผยว่า **btiotest ตัวเก่า (PID 8784) จากรอบ terminal ยังค้างถือพอร์ตอยู่**
(ตัว v0.1.0 ติดลูปอ่านไม่รู้จบ) + มีตระกูล BT ข้างเคียงอีก (BTLEServer,
WirelessRadioManagerd, FindMy) — v0.1.8 ยิงเป็นขั้นบันไดในปุ่มเดียว:
tier1 (blue* + btiotest) → เทสพอร์ต → tier2 (BT-adjacent) → เทส → ถ้ายังไม่ว่างค่อย dump
ขั้นตอน: ติดตั้ง 0.1.8 → รหัส → 1 STOP → ต้องเห็น "PORT FREE — press 2 UART SWEEP now"
→ กด 2 ทันที → COPY LOG → 3 RESTORE (Userspace Reboot คืนทุกอย่างที่ kill ไป)


## รอบ 10 (2026-09-27): BTKit v0.1.9 — สูตรรอบ 2 คืนมา: Airplane Mode ก่อนเสมอ + probes
สิ่งที่รอบ 9 พิสูจน์: bootout สำเร็จ + ยิง bluetoothd/BlueTool/FindMy ครบ + ไม่เหลือ
ผู้ถือที่รู้จัก แต่ยัง EBUSY -> สมมติฐาน: แลตช์ค้างระดับไดรเวอร์จากการ kill เปล่า ๆ
(รอบ 2 ที่สำเร็จ "เปิด Airplane ก่อน" เสมอ)
ขั้นตอน:
1. ติดตั้ง BTKit 0.1.9 (แถบต้องขึ้น v0.1.9) — intro มี TIP Airplane แล้ว
2. Settings -> **Airplane Mode ON** -> รอ 5 วิ
3. แอป: กรอกรหัส -> **1 STOP** (มี probe อัตโนมัติ 4 รอบ ~15 วิ) -> รอจบ
4. เห็น "PORT FREE" -> **2 UART SWEEP** -> COPY LOG -> 3 RESTORE
   (ถ้า probes ล้มเหลวทั้ง 4: กดปิด-เปิด Airplane อีกครั้ง รอ 5 วิ แล้วกด 2 ตรง ๆ)
5. จบ: Airplane OFF (และ Userspace Reboot ถ้าต้องการคืน BT เต็ม)


## รอบ 11 (2026-09-27): BTKit v0.1.10 (built, ยังไม่ต้องลง) + เปิดทาง SSH เข้าเครื่อง A
v0.1.10 = v0.1.9 + lsof ระดับ kernel (self-test ก่อนเชื่อผล) — ชี้ชื่อผู้ถือพอร์ตตัวจริง
หรือรายงาน NONE = แลตช์ระดับไดรเวอร์
ทางลัดใหม่: ให้แชท ssh เข้าเครื่อง A ตรง ๆ (key-only, ไม่มีรหัสผ่านในแชท, แตะเฉพาะ
เครื่อง A, ปิด tunnel + ลบ sudoers ชั่วคราวเมื่อจบ)
ขั้นแรก: NewTerm -> `ssh -o BatchMode=yes localhost echo ok` -> ส่งผลมาในแชท
- "Permission denied" = มี SSH server แล้ว (ดี - ไปขั้นถัดไป)
- "Connection refused" = ยังไม่มี server -> ต้องติดตั้ง OpenSSH จาก Sileo ก่อน


## รอบ 12 (2026-09-27): แผน SSH 4 ขั้น (ฝั่ง agent พร้อม: egress OK, คีย์ ed25519 สร้างแล้ว)
1) เช็ค server: `ssh -o BatchMode=yes localhost echo ok`
   - "Permission denied..." = มี server แล้ว -> ขั้น 3
   - "Connection refused" = ขั้น 2 ก่อน
2) Sileo -> Search "OpenSSH Server" (openssh-server, Procursus) -> Install -> กลับขั้น 1
3) ลงคีย์สาธารณะของ agent (บรรทัดเดียว, ใส่รหัส sudo บนเครื่อง, ต้องเห็น KEY-OK):
   sudo sh -c 'mkdir -p /var/root/.ssh /var/mobile/.ssh && echo "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIPhHgd0g/OEzmk19s/2NCoryDnlwU7S37sh/Kudj1rvp arena-agent-temp" >> /var/root/.ssh/authorized_keys && echo "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIPhHgd0g/OEzmk19s/2NCoryDnlwU7S37sh/Kudj1rvp arena-agent-temp" >> /var/mobile/.ssh/authorized_keys && chmod -R go-rwx /var/root/.ssh /var/mobile/.ssh && echo KEY-OK'
4) เปิดสะพาน (ทิ้ง NewTerm ไว้ จอค้าง):
   ssh -o StrictHostKeyChecking=no -p 443 -R0:localhost:22 tcp@a.pinggy.io
   -> รอ ~10 วิ -> ถ่ายรูปจอส่งมา (หาบรรทัด tcp://...เอง)
จบ session: agent ลบคีย์ตัวเองผ่านสายเดียวกัน + user ปิด NewTerm = ทุกอย่างกลับเดิม


## รอบ 12b (2026-09-27): ย้าย SSH มาเป็นปุ่มใน BTKit v0.1.11 — ไม่ต้องพิมพ์สักคำ
1) TrollStore ติดตั้ง BTKit.ipa 0.1.11 (แถบต้องขึ้น v0.1.11)
2) กรอกรหัสในช่อง -> กด **4 SSH KEY (agent)**
   - ต้องเห็น: "sshd: present OK" + "key -> ... OK" + "ROOT-SSH-OK"
   - ถ้าขึ้น sshd NOT INSTALLED -> Sileo ติดตั้ง "OpenSSH Server" (แตะล้วน) -> กด 4 ซ้ำ
3) กด **5 BRIDGE (pinggy)** -> รอ ~15 วิ -> มองหาบรรทัด tcp://....pinggy.io:NNNN
4) **COPY LOG** ส่งในแชท -> agent เข้าเครื่องเองและวินิจฉัย EBUSY ต่อ
หมายเหตุ: กุญแจที่ลงคือ public key (ข้อมูลสาธารณะ) จบงาน agent ลบเองผ่านสายเดียวกัน


## รอบ 12c: คำสั่งติดตั้ง ssh แบบพิมพ์ (user ขอเอง)
```
sudo /var/jb/usr/bin/apt install -y openssh-server
```
- ถ้า "command not found": ลอง `sudo /var/jb/bin/apt install -y openssh-server`
- ถ้า "Unable to locate package": รัน `sudo /var/jb/usr/bin/apt update` ก่อนแล้วย้ำคำสั่งแรก
- จบแล้วกลับ BTKit: กด 4 (ต้องเห็น sshd: present OK + ROOT-SSH-OK) -> กด 5 -> COPY LOG


## รอบ 13 (2026-09-27): v0.1.12 — แก้บั๊กมองผิดที่ (ssh อยู่ใต้ /var/jb)
ติดตั้ง 0.1.12 ทับ -> กด 4 SSH KEY ต้องเห็น "ssh client: /var/jb/usr/bin/ssh" + ROOT-SSH-OK
(sshd ไม่ยอมรันแอปจะ kickstart ให้เอง) -> กด 5 BRIDGE -> COPY LOG ส่ง tcp:// มาในแชท


## รอบ 14 (2026-09-27): v0.1.13 — ปุ่ม 6 SSH FIX แก้กฎประตู sshd อัตโนมัติ
1) ติดตั้ง 0.1.13 (แถบ v0.1.13)
2) กด 4 SSH KEY -> กด 6 SSH FIX -> ต้องเห็น ROOT-SSH-OK (หรือ MOBILE-SSH-OK)
3) กด 5 BRIDGE -> COPY LOG ส่ง tcp:// มาใหม่ (ที่อยู่เดิมหมดอายุใน 60 นาที)
หมายเหตุ: sshfix สำรองไฟล์กฎเดิมเป็น .btkit.bak ทุกครั้ง ลบทิ้งคืนได้


## รอบ 15 (2026-09-27): v0.1.14 — sshfix v2 + พิสูจน์สายสะพานจากฝั่ง agent แล้ว
พิสูจน์แล้ว: agent -> pinggy -> sshd ของเครื่อง (ตอบ Permission denied = สายถึงจริง)
กติกาความปลอดภัยที่ user ตั้ง (ผูกไว้เป็นกฎถาวร): ห้ามเข้าถึงรูป/วิดีโอ/ข้อมูลส่วนตัว,
ห้ามทำข้อมูลหลุด, ห้ามทำเครื่องพัง — แตะเฉพาะ BT + ssh config + BTKit log, แก้อะไรต้องมี .bak
ขั้นตอน: ติดตั้ง 0.1.14 -> 4 -> 6 -> COPY LOG (log จะมี: config ก่อนแก้, plist ของ sshd,
และ "sshd เล่าเองว่าปฏิเสธกุญแจเพราะอะไร" จากโหมด debug พอร์ต 2222) -> 5 -> COPY LOG


## รอบ 16 (2026-09-27): v0.1.15 — ย้ายห้องสอบไปพอร์ต 2022 (2222 มีเจ้าของลึกลับ!) + ปลดกับดักทุกอย่าง
ขั้นตอนเดิม: ติดตั้ง 0.1.15 -> 4 -> 6 -> COPY LOG
log รอบนี้จะบอกครบ: ใครนั่งฟังพอร์ตไหน (netstat), กุญแจในไฟล์สมบูรณ์ไหม, config หลังแก้,
และคำสารภาพของ sshd จากพอร์ตทดสอบใหม่ 2022 ที่ปิดกับดักสิทธิ์ทุกตัว


## รอบ 17 (2026-09-27): v0.1.16 — sshd ของเราเองบน :22 (เลิกใช้ของ launchd)
พิสูจน์แล้วว่ากุญแจ agent ถูกยื่นแต่โดนปฏิเสธ -> สงสัย launchd จำกัดบริบท sshd
ปุ่ม 6 v4 = ปิด sshd เดิม + ปลุก sshd ของเราเอง (root เต็ม + log ทุกเหตุการณ์)
+ ทดสอบควบคุมด้วยกุญแจจริงบนเครื่อง (LOCAL-KEY-SSH-OK)
ขั้นตอน: ติดตั้ง 0.1.16 -> กรอกรหัส -> 4 -> 6 -> 5 -> COPY LOG ส่งมา
(ถ้าผมยังเข้าไม่ได้ จะบอกให้กด 6 ซ้ำ — หัว log จะโชว์ "คำสารภาพ" ของการล่าสุด)


## รอบ 17 (2026-09-27 คืนนี้): SSH สำเร็จ — agent ลง root บนเครื่อง A ได้เองทั้งหมด
- สาย: BTKit ปุ่ม 4 (คีย์) + sshd ของเราเอง (ปุ่ม 6 v4) + ปุ่ม 5 (pinggy) + agent จากแซนด์บ็อกซ์
- ความรู้ชิป: idle=19200/CTS=0 (ไฟดับเมื่อไม่มีคนถือพอร์ต), BlueTool ปลุกถึง 4-6M,
  EBUSY = ล็อกข้ามโหนด (uart./cu.), ปลุกด้วย GPIO function-power_enable ที่ uart1
- อุบัติเหตุ: ผู้ใช้เปิด BT ตอนแบต 1% + การทดลองค้างกลางพิธี -> spinner ค้าง ->
  RESTORE ครบ: หุ่นยนต์ถูกฆ่า, label เราถูกถอด+ลบ plist, stock enable+bootstrap ใหม่,
  bluetoothd ตัวใหม่รันอยู่, ชิป idle 19200, sshd เรายังเปิดเป็นประตู agent
- NEXT SESSION: ชาร์จก่อน -> ทดสอบ BT ปกติ -> ถ้า ok วนแผนยึดชิปใหม่ (label เป๊ะ stock +
  watchdog >=1M + โพรบ 6M/4M)


## รอบ 18 (2026-09-27): BTKit v0.1.17 — กล้อง CCTV ของ agent (user-requested)
1) ติดตั้ง 0.1.17 (แถบ v0.1.17)
2) กรอกรหัส -> 6 SSH FIX (ติดตั้ง CCTV + ประตูเปิดพร้อม ForceCommand)
3) 5 BRIDGE -> COPY LOG ส่ง tcp:// มาในแชท
4) ผมเข้าทำงาน — ทุกคำสั่ง+ผลลัพธ์ บันทึกที่ Documents/agent-activity.log
   อ่านสดได้: Filza เปิดไฟล์นั้น หรือกด 7 AGENT LOG ใน BTKit


## รอบ 18b: BTKit v0.1.18 — จอสด 1 วินาที
กด 7 = เปิดจอสด (log agent ไหลอัปเดตทุกวินาทีในแอป) / กดซ้ำ = ปิด
(ระบบบันทึกฝั่งเครื่องติดตั้งตอนกด 6 SSH FIX ครั้งแรกของเวอร์ชันนี้)


## รอบ 18c: BTKit v0.1.19 — ปุ่มเป็นแถบแนบขอบล่าง (จอโล่งขึ้น)
ปุ่ม 8 ตัวย่อเป็นชื่อสั้น เรียง 2 แถวล่างจอ: [1 STOP|2 SWEEP|3 RESTORE|4 KEY] / [5 BRIDGE|6 FIX|7 LIVE|COPY]
วิธีใช้เหมือนเดิมทุกอย่าง: รหัส -> 6 FIX -> 7 LIVE -> 5 BRIDGE -> COPY ส่ง tcp://


## รอบ 19 (2026-09-27 โมงดี): 🏆 ชิปพูดแล้ว — BCM4355C0
ตัวเชื่อมชนะ = up4 (fifo) -> BlueTool แท้ -> ชิป | ลำดับชนะ:
device -D -> power on -> wake on -> reset pulse -> (รอ) -> device -D -> hci reset
-> hci info (Broadcom/HCI4.2/0x6103) -> hci localName => **BCM4355C0**
ถัดไป: bcm -W (HCD firmware) -> bcm -b ความเร็วสูง -> SEIZE -> transport ตรง -> G3 -> จอยเกม


## รอบ 20 (2026-09-27): เฟิร์มแวร์ลงชิป + คำตัดสินสถาปัตยกรรม
- bcm -W สำเร็จ: ชิป = BCM4355C0 Elsa, addr 43:55:c0:..., 6M baud OK
- ชั้น termios ของไดรเวอร์ = หุ่นหลอก (ENOTTY) -> ทางตรงแบบเดิมไม่มีทางสำเร็จ
- สถาปัตยกรรมใหม่: ใช้ BlueTool เป็นสะพาน (hci cmd TX / stdout RX ผ่าน up4)
- ค้างไว้: สูตรปลุกชิปเมื่อง่วงลึก (ต้องหา recipe ที่เชื่อถือได้), spam -h
- คืนระบบ: bluetoothd+btup ถูก bootout ไว้ -> เปิด BT ปกติครั้งแรกต้องรีบูตเครื่อง 1 ครั้ง
  (หรือ bootstrap คืน: /var/jb/bin/launchctl bootstrap system
  /System/Library/LaunchDaemons/com.apple.bluetoothd.plist)
