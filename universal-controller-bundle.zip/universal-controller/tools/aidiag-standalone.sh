#!/bin/sh
# aidiag-standalone.sh — iPhone A capability audit WITHOUT any toolchain.
# Usage:  sh aidiag-standalone.sh          (full audit)
#         sh aidiag-standalone.sh crash    (collect latest ControllerA .ips crash log)
if [ "$1" = "crash" ]; then
  CR=/var/mobile/Library/Logs/CrashReporter
  echo "=== aidiag crash collector ==="
  ls -lt "$CR" 2>/dev/null | head -10 || echo "CrashReporter dir not readable"
  LATEST=$(ls -t "$CR"/ControllerA-*.ips 2>/dev/null | head -1)
  if [ -n "$LATEST" ]; then
    echo "--- newest ControllerA crash: $LATEST ---"
    head -80 "$LATEST"
    cp "$LATEST" "$(dirname "$0")/latest-controllera-crash.ips" 2>/dev/null       && echo "copy saved next to script: latest-controllera-crash.ips"
  else
    echo "no ControllerA-*.ips found (wait a minute after the crash; also check SpringBoard-*.ips)"
  fi
  exit 0
fi
# Copy to iPhone A (SSH / Filza / NewTerm) and run as root:  sh aidiag-standalone.sh
# Writes a report next to itself: aidiag-report.txt
# Everything it cannot determine prints UNKNOWN — per project rule 0.1 (no guessing).
{
echo "=== aidiag-standalone (shell) $(date -u '+%Y-%m-%dT%H:%M:%SZ') ==="
echo
echo "--- Hardware / OS ---"
echo "hw.machine            = $(sysctl -n hw.machine 2>/dev/null || echo UNKNOWN)"
echo "hw.model              = $(sysctl -n hw.model 2>/dev/null || echo UNKNOWN)"
echo "hw.ncpu               = $(sysctl -n hw.ncpu 2>/dev/null || echo UNKNOWN)"
echo "hw.memsize            = $(sysctl -n hw.memsize 2>/dev/null || echo UNKNOWN)"
echo "kern.osrelease        = $(sysctl -n kern.osrelease 2>/dev/null || echo UNKNOWN)"
echo "kern.osversion(build) = $(sysctl -n kern.osversion 2>/dev/null || echo UNKNOWN)"
echo "kern.osproductversion = $(sysctl -n kern.osproductversion 2>/dev/null || echo UNKNOWN)"
echo "kern.bootargs         = $(sysctl -n kern.bootargs 2>/dev/null || echo UNKNOWN)"
echo "uname                 = $(uname -a 2>/dev/null || echo UNKNOWN)"
echo "cpu arch (uname -m)   = $(uname -m 2>/dev/null || echo UNKNOWN)"
echo "arm64e check          = $(sysctl -n hw.cpusubtype 2>/dev/null || echo UNKNOWN) (2=ARM64E, 1=ARM64)"
echo
echo "--- Jailbreak markers ---"
[ -d /var/jb ] && echo "/var/jb                        = YES (rootless bootstrap: palera1n-rootless or Dopamine)" || echo "/var/jb                        = no"
[ -d /.procursus ] && echo "/.procursus                    = YES (rootful Procursus)" || echo "/.procursus                    = no"
[ -e /var/jb/.installed_dopamine ] && echo "/var/jb/.installed_dopamine    = YES (Dopamine)" || echo "/var/jb/.installed_dopamine    = no"
[ -e /var/jb/basebin ] && echo "/var/jb/basebin                = YES (palera1n basebin)" || echo "/var/jb/basebin                = no"
ls /var/jb/usr/bin/palera1n >/dev/null 2>&1 && echo "palera1n helper                = YES" || echo "palera1n helper                = no"
[ -d /usr/lib/TweakInject ] || [ -d /var/jb/usr/lib/TweakInject ] && echo "TweakInject (Substrate/ElleKit)= YES" || echo "TweakInject (Substrate/ElleKit)= no"
[ -d /usr/lib/substrate ] && echo "substrate dir                  = YES" || true
[ -e /usr/lib/libhooker.dylib ] || [ -e /var/jb/usr/lib/libhooker.dylib ] && echo "libhooker                      = YES" || echo "libhooker                      = no"
echo "id (user)             = $(id 2>/dev/null || echo UNKNOWN)"
echo
echo "--- Bootstrap / package manager ---"
for f in /var/jb/var/lib/dpkg/status /var/lib/dpkg/status; do
  if [ -f "$f" ]; then
    echo "dpkg status           = $f ($(grep -c '^Package:' "$f" 2>/dev/null || echo '?') packages)"
    grep -iE '^Package: (ellekit|substrate|libhooker|palera1n|dopamine|sileo|zebra|trollstore)' "$f" 2>/dev/null | sed 's/^/  notable: /'
  fi
done
[ -d /var/jb/Applications/Sileo.app ] && echo "Sileo                 = YES (/var/jb/Applications)" || true
[ -d /Applications/Sileo.app ] && echo "Sileo                 = YES (/Applications)" || true
echo
echo "--- TrollStore ---"
[ -f /var/mobile/Library/Preferences/com.opa334.trollstore.plist ] && echo "TrollStore prefs      = YES" || echo "TrollStore prefs      = no"
[ -d /Applications/TrollStore.app ] && echo "/Applications/TrollStore.app = YES" || true
[ -d /var/jb/Applications/TrollStore.app ] && echo "/var/jb/Applications/TrollStore.app = YES" || true
# scan installed app containers for TrollStore-related bundles (best effort)
if [ -d /var/containers/Bundle/Application ]; then
  find /var/containers/Bundle/Application -maxdepth 2 \( -name '*TrollStore*' -o -name '*TrollInstaller*' -o -name '*TrollMisaka*' \) 2>/dev/null | head -5 | sed 's/^/found: /'
fi
echo
echo "--- Bluetooth stack / chip ---"
[ -x /usr/libexec/blued ] || [ -f /usr/libexec/blued ] && echo "blued                 = YES" || echo "blued                 = $( [ -f /usr/sbin/blued ] && echo YES || echo UNKNOWN )"
ls /usr/sbin/BlueTool >/dev/null 2>&1 && echo "BlueTool              = YES" || echo "BlueTool              = no"
echo "IOKit bluetooth entries (needs root, best effort):"
ioreg -l 2>/dev/null | grep -ioE '"[^"]*(Bluetooth|BCM4[0-9a-zA-Z]*|BCMSerial)[^"]*"' | sort -u | head -15 || echo "  ioreg not available -> run com.research.idiag (deb) for IOKit walk"
echo
echo "--- BT chip / HCI surfaces (Phase-3 audit) ---"
ls -l /usr/sbin/BlueTool /usr/sbin/BlueTool.sbin 2>/dev/null || echo "BlueTool            = not found"
[ -e /dev/uart.bluetooth ] && echo "/dev/uart.bluetooth = YES" || echo "/dev/uart.bluetooth = no"
[ -e /dev/btreset ] && echo "/dev/btreset        = YES" || echo "/dev/btreset        = no"
[ -e /var/jb/usr/libexec/internalblued ] && echo "internalblued       = YES" || true
ls /dev 2>/dev/null | grep -iE 'bluetooth|uart' | head -10 | sed 's/^/  dev: /'
if [ -f /usr/sbin/BlueTool ]; then
  if command -v strings >/dev/null 2>&1; then
    echo "BlueTool firmware/chip tokens:"
    strings /usr/sbin/BlueTool 2>/dev/null | grep -aoE '(BCM|CYW)[0-9A-Za-z]+|[^ ]*\.hcd' | sort -u | head -8 | sed 's/^/  /'
  else
    echo "strings not available -> use idiag deb for chip-token scan"
  fi
fi
echo
echo "--- Daemons of interest ---"
launchctl list 2>/dev/null | grep -iE 'bluetooth|blued' | sed 's/^/  /' || echo "launchctl not accessible -> UNKNOWN"
echo
echo "=== END aidiag-standalone ==="
} > "$(dirname "$0")/aidiag-report.txt" 2>&1
cat "$(dirname "$0")/aidiag-report.txt"
