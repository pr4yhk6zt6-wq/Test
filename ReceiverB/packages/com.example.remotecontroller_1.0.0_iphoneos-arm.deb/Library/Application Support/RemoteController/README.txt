Remote Controller - ReceiverB

This DEB contains:
- Python fallback daemon: /usr/bin/remotecontrollerd.py (works without compilation, requires Python 3 on device)
- Wrapper: /usr/bin/remotecontrollerd (tries binary, falls back to python)
- LaunchDaemon: /Library/LaunchDaemons/com.example.remotecontrollerd.plist
- Tweak placeholder: /Library/MobileSubstrate/DynamicLibraries/RemoteController.dylib (needs compilation via Theos)

For full functionality, you need to compile the tweak:

On macOS/Linux with Theos:
  export THEOS=/path/to/theos
  cd ReceiverB
  make package
  dpkg -i packages/com.example.remotecontroller_*.deb

Or compile on-device with Theos installed on iPhone:
  Install Theos on device (via Sileo)
  Copy ReceiverB/Tweak/* to /var/mobile/RemoteController/
  cd /var/mobile/RemoteController && make package
  dpkg -i *.deb

The Python daemon alone will listen on TCP 9944 and Unix socket, but without the tweak,
games will not see virtual controller. Tweak is required for GCController injection.

See docs/ARCHITECTURE.md for details.

Tested via Simulator/receiver_simulator.py which proves protocol works.
